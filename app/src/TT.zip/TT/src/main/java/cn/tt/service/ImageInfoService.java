package cn.tt.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.tt.bean.Album;
import cn.tt.bean.ImgInfo;
import cn.tt.dao.AlbumMapper;
import cn.tt.dao.ImgInfoMapper;
import cn.tt.utils.MyProp;

@Service
public class ImageInfoService {
	private final int PIC_NUM = 4;
	@Autowired
	private ImgInfoMapper imgInfoMapper;
	@Autowired
	private AlbumMapper albumMapper;
	@Autowired
	private FileTradeService tradeService;
	@Autowired
	private FriendsService friendsService;
	
	public int addImgInfo(ImgInfo record){
		if ( record.getImgid() == null ){
			String id = UUID.randomUUID().toString();
			record.setImgid(id);
		}
		return imgInfoMapper.insert(record);
	}
	
	public ImgInfo getImg(String imgid) {
		return imgInfoMapper.selectByPrimaryKey(imgid);
	}
	
	public List<ImgInfo> getImgsByAlbum(String albumid){
		return imgInfoMapper.selectImgsByAlbum(albumid);
	}

	public List<String> getImgsByUser(String accountid){
		String prefix=MyProp.urlPrefix+"/image/albumimg?url=";
		List<String> res = new ArrayList<String>();
		List<Album> albums = albumMapper.selectAlbumsByUser(accountid);
		for( Album album : albums ){
			List<ImgInfo> tmp = imgInfoMapper.selectImgsByAlbum(album.getAlbumid());
			for( ImgInfo img: tmp ){
				res.add(prefix+img.getImgurl());
			}
		}
		return res;
	}
	
	public List<String> getFreeImgsByUser(String accountid, Integer num){
		String prefix=MyProp.urlPrefix+"/image/albumimg?url=";
		List<String> imgUrls = imgInfoMapper.selectFreeImgsByUser(accountid,0,num);
		List<String> res = new ArrayList<String>();
		if ( imgUrls != null && imgUrls.size() > 0 ){
			for ( String item: imgUrls ){
				res.add(prefix+item);
			}
		}
		return res;
	}

	public List<String> getChargeImgsByUser(String accountid, Integer num){
		String prefix=MyProp.urlPrefix+"/image/albumimg?url=";
		List<String> imgUrls = imgInfoMapper.selectChargeImgsByUser(accountid,0,num);
		List<String> res = new ArrayList<String>();
		if ( imgUrls != null && imgUrls.size() > 0 ){
			for ( String item: imgUrls ){
				res.add(prefix+item);
			}
		}
		return res;
	}
					
	public List<String> getVipfreeImgsByUser(String accountid,Integer num){
		String prefix=MyProp.urlPrefix+"/image/albumimg/image?url=";
		List<String> imgUrls = imgInfoMapper.selectVipfreeImgsByUser(accountid,0,num);
		List<String> res = new ArrayList<String>();
		if ( imgUrls != null && imgUrls.size() > 0 ){
			for ( String item: imgUrls ){
				res.add(prefix+item);
			}
		}
		return res;
	}

}
