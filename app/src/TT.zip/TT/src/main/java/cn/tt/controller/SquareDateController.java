package cn.tt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Msg;
import cn.tt.service.SquareDateService;
import cn.tt.utils.MyDateWrapper;
import cn.tt.utils.SquareDateWraper;
/*
 * 广场中有偿约会controller
 */
@Controller
@RequestMapping("/squaredate")
public class SquareDateController {
	@Autowired
	private SquareDateService squareDateService;
	
	//得到有偿约会列表
	@ResponseBody
	@RequestMapping(value="/publishdate")
	public Msg getDates(){
		List<SquareDateWraper> list = squareDateService.getDates();
		if(list == null)
			return Msg.fail();
		else
			return Msg.success().add("squaredates", list);
	}
	
	//得到约会消息，根据inviteid和receiveid的值得到的是自己发起或者报名的约会
	@ResponseBody
	@RequestMapping(value="/invitedate/{inviteid}/{receiveid}")
	public Msg getInvitedDates(@PathVariable("inviteid") String inviteid,
			@PathVariable("receiveid") String receiveid){
		List<MyDateWrapper> list = squareDateService.getInviteDates(inviteid,receiveid);
		if(list == null)
			return Msg.fail();
		else
			return Msg.success().add("squaredates", list);
	}
	
	//报名约会
	@ResponseBody
	@RequestMapping("/sign")
	public Msg signDate(@RequestParam("accountid") String accountid,
			@RequestParam("friendid") String friendid,
			@RequestParam("sincerity") int num,
			@RequestParam("did") int did){
		int i = squareDateService.signDate(accountid, friendid, num, did);
		if(i == -1)
			return Msg.fail();
		else
			return Msg.success();
	}
	
	//取消发起的约会
	@ResponseBody
	@RequestMapping("/cancel")
	public Msg cancelDate(@RequestParam("accountid") String accountid,
			@RequestParam("friendid") String friendid,
			@RequestParam("sincerity") int num,
			@RequestParam("did") int did){
		boolean i = squareDateService.cancalDate(accountid, friendid, num, did);
		if(!i)
			return Msg.fail();
		else
			return Msg.success();
	}
	
	//取消已经报名的约会
	@ResponseBody
	@RequestMapping("/cancelinvite")
	public Msg cancalReceiveDate(@RequestParam("accountid") String accountid,
			@RequestParam("friendid") String friendid,
			@RequestParam("sincerity") int num,
			@RequestParam("did") int did){
		boolean i = squareDateService.cancalReceiveDate(accountid, friendid, num, did);
		if(!i)
			return Msg.fail();
		else
			return Msg.success();
	}
}
