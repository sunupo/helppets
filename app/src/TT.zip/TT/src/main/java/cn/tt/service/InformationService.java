package cn.tt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Comment;
import cn.tt.bean.Dynamic;
import cn.tt.bean.Information;
import cn.tt.bean.InformationExample;
import cn.tt.bean.User_info;
import cn.tt.dao.CommentMapper;
import cn.tt.dao.DynamicMapper;
import cn.tt.dao.InformationMapper;
import cn.tt.dao.User_infoMapper;
import cn.tt.utils.InformationComment;
import cn.tt.utils.InformationWrapper;

@Service
public class InformationService {
	@Autowired
	private CommentMapper commentMapper;

	@Autowired
	private DynamicMapper dynamicMapper;
	
	@Autowired
	private User_infoMapper user_infoMapper;
	
	@Autowired
	private InformationMapper informationMapper;
	
	public List<InformationComment> getComments(String accountId,int offset,int limit){
		List<Comment> comments = commentMapper.getLimitComments(accountId, offset, limit);
		List<InformationComment> infoComments = new ArrayList<InformationComment>();
		for(Comment comment : comments){
			InformationComment info = new InformationComment();
			Dynamic dynamic = dynamicMapper.selectByPrimaryKey(comment.getDynaimcId());
			User_info user = user_infoMapper.selectByPrimaryKey(comment.getAccount());
			info.setComment(comment);
			info.setDynamic(dynamic);
			info.setUserinfo(user);
			infoComments.add(info);
		}
		return infoComments;
	}
	
	public List<InformationWrapper> getAllInformation(String accountId,int type,int offset, int limit){
		List<Information> informations = informationMapper.getLimitTypeInformation(accountId,type,offset,limit);
		List<InformationWrapper> wrappers = new ArrayList<InformationWrapper>();
		for(Information in : informations){
			InformationWrapper wrapper = new InformationWrapper();
			User_info user = user_infoMapper.selectByPrimaryKey(in.getActorid());
			wrapper.setUser_info(user);
			wrapper.setInformation(in);
			wrappers.add(wrapper);
		}
		return wrappers;
	}
	
	public List<InformationWrapper> getAllInformation(String accountId,int offset, int limit){
		List<Information> informations = informationMapper.getLimitInformation(accountId,offset,limit);
		List<InformationWrapper> wrappers = new ArrayList<InformationWrapper>();
		for(Information in : informations){
			InformationWrapper wrapper = new InformationWrapper();
			User_info user = user_infoMapper.selectByPrimaryKey(in.getActorid());
			wrapper.setUser_info(user);
			wrapper.setInformation(in);
			wrappers.add(wrapper);
		}
		return wrappers;
	}
}
