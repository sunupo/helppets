package cn.tt.bean;

import java.util.Date;

public class Comment {
    private String id;

    private String account;

    private String commentAccount;

    private String dynaimcId;

    private Date releasedate;

    private String content;

    private Integer support;

    private Integer unlike;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public String getCommentAccount() {
        return commentAccount;
    }

    public void setCommentAccount(String commentAccount) {
        this.commentAccount = commentAccount == null ? null : commentAccount.trim();
    }

    public String getDynaimcId() {
        return dynaimcId;
    }

    public void setDynaimcId(String dynaimcId) {
        this.dynaimcId = dynaimcId == null ? null : dynaimcId.trim();
    }

    public Date getReleasedate() {
        return releasedate;
    }

    public void setReleasedate(Date releasedate) {
        this.releasedate = releasedate;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getSupport() {
        return support;
    }

    public void setSupport(Integer support) {
        this.support = support;
    }

    public Integer getUnlike() {
        return unlike;
    }

    public void setUnlike(Integer unlike) {
        this.unlike = unlike;
    }
}