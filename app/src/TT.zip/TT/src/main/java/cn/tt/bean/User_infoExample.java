package cn.tt.bean;

import java.util.ArrayList;
import java.util.List;

public class User_infoExample {
	protected int offset;
    protected int limit;
    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public User_infoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAccountIdIsNull() {
            addCriterion("account_id is null");
            return (Criteria) this;
        }

        public Criteria andAccountIdIsNotNull() {
            addCriterion("account_id is not null");
            return (Criteria) this;
        }

        public Criteria andAccountIdEqualTo(String value) {
            addCriterion("account_id =", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotEqualTo(String value) {
            addCriterion("account_id <>", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThan(String value) {
            addCriterion("account_id >", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThanOrEqualTo(String value) {
            addCriterion("account_id >=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThan(String value) {
            addCriterion("account_id <", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThanOrEqualTo(String value) {
            addCriterion("account_id <=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLike(String value) {
            addCriterion("account_id like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotLike(String value) {
            addCriterion("account_id not like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdIn(List<String> values) {
            addCriterion("account_id in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotIn(List<String> values) {
            addCriterion("account_id not in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdBetween(String value1, String value2) {
            addCriterion("account_id between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotBetween(String value1, String value2) {
            addCriterion("account_id not between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andSexIsNull() {
            addCriterion("sex is null");
            return (Criteria) this;
        }

        public Criteria andSexIsNotNull() {
            addCriterion("sex is not null");
            return (Criteria) this;
        }

        public Criteria andSexEqualTo(Byte value) {
            addCriterion("sex =", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotEqualTo(Byte value) {
            addCriterion("sex <>", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThan(Byte value) {
            addCriterion("sex >", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThanOrEqualTo(Byte value) {
            addCriterion("sex >=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThan(Byte value) {
            addCriterion("sex <", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThanOrEqualTo(Byte value) {
            addCriterion("sex <=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexIn(List<Byte> values) {
            addCriterion("sex in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotIn(List<Byte> values) {
            addCriterion("sex not in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexBetween(Byte value1, Byte value2) {
            addCriterion("sex between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotBetween(Byte value1, Byte value2) {
            addCriterion("sex not between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andConstellationIsNull() {
            addCriterion("constellation is null");
            return (Criteria) this;
        }

        public Criteria andConstellationIsNotNull() {
            addCriterion("constellation is not null");
            return (Criteria) this;
        }

        public Criteria andConstellationEqualTo(String value) {
            addCriterion("constellation =", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationNotEqualTo(String value) {
            addCriterion("constellation <>", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationGreaterThan(String value) {
            addCriterion("constellation >", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationGreaterThanOrEqualTo(String value) {
            addCriterion("constellation >=", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationLessThan(String value) {
            addCriterion("constellation <", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationLessThanOrEqualTo(String value) {
            addCriterion("constellation <=", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationLike(String value) {
            addCriterion("constellation like", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationNotLike(String value) {
            addCriterion("constellation not like", value, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationIn(List<String> values) {
            addCriterion("constellation in", values, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationNotIn(List<String> values) {
            addCriterion("constellation not in", values, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationBetween(String value1, String value2) {
            addCriterion("constellation between", value1, value2, "constellation");
            return (Criteria) this;
        }

        public Criteria andConstellationNotBetween(String value1, String value2) {
            addCriterion("constellation not between", value1, value2, "constellation");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andCityIsNull() {
            addCriterion("city is null");
            return (Criteria) this;
        }

        public Criteria andCityIsNotNull() {
            addCriterion("city is not null");
            return (Criteria) this;
        }

        public Criteria andCityEqualTo(String value) {
            addCriterion("city =", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotEqualTo(String value) {
            addCriterion("city <>", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThan(String value) {
            addCriterion("city >", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThanOrEqualTo(String value) {
            addCriterion("city >=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThan(String value) {
            addCriterion("city <", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThanOrEqualTo(String value) {
            addCriterion("city <=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLike(String value) {
            addCriterion("city like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotLike(String value) {
            addCriterion("city not like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityIn(List<String> values) {
            addCriterion("city in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotIn(List<String> values) {
            addCriterion("city not in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityBetween(String value1, String value2) {
            addCriterion("city between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotBetween(String value1, String value2) {
            addCriterion("city not between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andHightIsNull() {
            addCriterion("hight is null");
            return (Criteria) this;
        }

        public Criteria andHightIsNotNull() {
            addCriterion("hight is not null");
            return (Criteria) this;
        }

        public Criteria andHightEqualTo(Integer value) {
            addCriterion("hight =", value, "hight");
            return (Criteria) this;
        }

        public Criteria andHightNotEqualTo(Integer value) {
            addCriterion("hight <>", value, "hight");
            return (Criteria) this;
        }

        public Criteria andHightGreaterThan(Integer value) {
            addCriterion("hight >", value, "hight");
            return (Criteria) this;
        }

        public Criteria andHightGreaterThanOrEqualTo(Integer value) {
            addCriterion("hight >=", value, "hight");
            return (Criteria) this;
        }

        public Criteria andHightLessThan(Integer value) {
            addCriterion("hight <", value, "hight");
            return (Criteria) this;
        }

        public Criteria andHightLessThanOrEqualTo(Integer value) {
            addCriterion("hight <=", value, "hight");
            return (Criteria) this;
        }

        public Criteria andHightIn(List<Integer> values) {
            addCriterion("hight in", values, "hight");
            return (Criteria) this;
        }

        public Criteria andHightNotIn(List<Integer> values) {
            addCriterion("hight not in", values, "hight");
            return (Criteria) this;
        }

        public Criteria andHightBetween(Integer value1, Integer value2) {
            addCriterion("hight between", value1, value2, "hight");
            return (Criteria) this;
        }

        public Criteria andHightNotBetween(Integer value1, Integer value2) {
            addCriterion("hight not between", value1, value2, "hight");
            return (Criteria) this;
        }

        public Criteria andWeightIsNull() {
            addCriterion("weight is null");
            return (Criteria) this;
        }

        public Criteria andWeightIsNotNull() {
            addCriterion("weight is not null");
            return (Criteria) this;
        }

        public Criteria andWeightEqualTo(Integer value) {
            addCriterion("weight =", value, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightNotEqualTo(Integer value) {
            addCriterion("weight <>", value, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightGreaterThan(Integer value) {
            addCriterion("weight >", value, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightGreaterThanOrEqualTo(Integer value) {
            addCriterion("weight >=", value, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightLessThan(Integer value) {
            addCriterion("weight <", value, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightLessThanOrEqualTo(Integer value) {
            addCriterion("weight <=", value, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightIn(List<Integer> values) {
            addCriterion("weight in", values, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightNotIn(List<Integer> values) {
            addCriterion("weight not in", values, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightBetween(Integer value1, Integer value2) {
            addCriterion("weight between", value1, value2, "weight");
            return (Criteria) this;
        }

        public Criteria andWeightNotBetween(Integer value1, Integer value2) {
            addCriterion("weight not between", value1, value2, "weight");
            return (Criteria) this;
        }

        public Criteria andQqIsNull() {
            addCriterion("qq is null");
            return (Criteria) this;
        }

        public Criteria andQqIsNotNull() {
            addCriterion("qq is not null");
            return (Criteria) this;
        }

        public Criteria andQqEqualTo(String value) {
            addCriterion("qq =", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotEqualTo(String value) {
            addCriterion("qq <>", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqGreaterThan(String value) {
            addCriterion("qq >", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqGreaterThanOrEqualTo(String value) {
            addCriterion("qq >=", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqLessThan(String value) {
            addCriterion("qq <", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqLessThanOrEqualTo(String value) {
            addCriterion("qq <=", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqLike(String value) {
            addCriterion("qq like", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotLike(String value) {
            addCriterion("qq not like", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqIn(List<String> values) {
            addCriterion("qq in", values, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotIn(List<String> values) {
            addCriterion("qq not in", values, "qq");
            return (Criteria) this;
        }

        public Criteria andQqBetween(String value1, String value2) {
            addCriterion("qq between", value1, value2, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotBetween(String value1, String value2) {
            addCriterion("qq not between", value1, value2, "qq");
            return (Criteria) this;
        }

        public Criteria andPhoneNumIsNull() {
            addCriterion("phone_num is null");
            return (Criteria) this;
        }

        public Criteria andPhoneNumIsNotNull() {
            addCriterion("phone_num is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneNumEqualTo(String value) {
            addCriterion("phone_num =", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotEqualTo(String value) {
            addCriterion("phone_num <>", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumGreaterThan(String value) {
            addCriterion("phone_num >", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumGreaterThanOrEqualTo(String value) {
            addCriterion("phone_num >=", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumLessThan(String value) {
            addCriterion("phone_num <", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumLessThanOrEqualTo(String value) {
            addCriterion("phone_num <=", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumLike(String value) {
            addCriterion("phone_num like", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotLike(String value) {
            addCriterion("phone_num not like", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumIn(List<String> values) {
            addCriterion("phone_num in", values, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotIn(List<String> values) {
            addCriterion("phone_num not in", values, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumBetween(String value1, String value2) {
            addCriterion("phone_num between", value1, value2, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotBetween(String value1, String value2) {
            addCriterion("phone_num not between", value1, value2, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andLikeSportsIsNull() {
            addCriterion("like_sports is null");
            return (Criteria) this;
        }

        public Criteria andLikeSportsIsNotNull() {
            addCriterion("like_sports is not null");
            return (Criteria) this;
        }

        public Criteria andLikeSportsEqualTo(String value) {
            addCriterion("like_sports =", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsNotEqualTo(String value) {
            addCriterion("like_sports <>", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsGreaterThan(String value) {
            addCriterion("like_sports >", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsGreaterThanOrEqualTo(String value) {
            addCriterion("like_sports >=", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsLessThan(String value) {
            addCriterion("like_sports <", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsLessThanOrEqualTo(String value) {
            addCriterion("like_sports <=", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsLike(String value) {
            addCriterion("like_sports like", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsNotLike(String value) {
            addCriterion("like_sports not like", value, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsIn(List<String> values) {
            addCriterion("like_sports in", values, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsNotIn(List<String> values) {
            addCriterion("like_sports not in", values, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsBetween(String value1, String value2) {
            addCriterion("like_sports between", value1, value2, "likeSports");
            return (Criteria) this;
        }

        public Criteria andLikeSportsNotBetween(String value1, String value2) {
            addCriterion("like_sports not between", value1, value2, "likeSports");
            return (Criteria) this;
        }

        public Criteria andSexInfoIsNull() {
            addCriterion("sex_info is null");
            return (Criteria) this;
        }

        public Criteria andSexInfoIsNotNull() {
            addCriterion("sex_info is not null");
            return (Criteria) this;
        }

        public Criteria andSexInfoEqualTo(String value) {
            addCriterion("sex_info =", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoNotEqualTo(String value) {
            addCriterion("sex_info <>", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoGreaterThan(String value) {
            addCriterion("sex_info >", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoGreaterThanOrEqualTo(String value) {
            addCriterion("sex_info >=", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoLessThan(String value) {
            addCriterion("sex_info <", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoLessThanOrEqualTo(String value) {
            addCriterion("sex_info <=", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoLike(String value) {
            addCriterion("sex_info like", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoNotLike(String value) {
            addCriterion("sex_info not like", value, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoIn(List<String> values) {
            addCriterion("sex_info in", values, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoNotIn(List<String> values) {
            addCriterion("sex_info not in", values, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoBetween(String value1, String value2) {
            addCriterion("sex_info between", value1, value2, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andSexInfoNotBetween(String value1, String value2) {
            addCriterion("sex_info not between", value1, value2, "sexInfo");
            return (Criteria) this;
        }

        public Criteria andMerriageIsNull() {
            addCriterion("merriage is null");
            return (Criteria) this;
        }

        public Criteria andMerriageIsNotNull() {
            addCriterion("merriage is not null");
            return (Criteria) this;
        }

        public Criteria andMerriageEqualTo(Byte value) {
            addCriterion("merriage =", value, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageNotEqualTo(Byte value) {
            addCriterion("merriage <>", value, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageGreaterThan(Byte value) {
            addCriterion("merriage >", value, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageGreaterThanOrEqualTo(Byte value) {
            addCriterion("merriage >=", value, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageLessThan(Byte value) {
            addCriterion("merriage <", value, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageLessThanOrEqualTo(Byte value) {
            addCriterion("merriage <=", value, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageIn(List<Byte> values) {
            addCriterion("merriage in", values, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageNotIn(List<Byte> values) {
            addCriterion("merriage not in", values, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageBetween(Byte value1, Byte value2) {
            addCriterion("merriage between", value1, value2, "merriage");
            return (Criteria) this;
        }

        public Criteria andMerriageNotBetween(Byte value1, Byte value2) {
            addCriterion("merriage not between", value1, value2, "merriage");
            return (Criteria) this;
        }

        public Criteria andFriendcountIsNull() {
            addCriterion("friendcount is null");
            return (Criteria) this;
        }

        public Criteria andFriendcountIsNotNull() {
            addCriterion("friendcount is not null");
            return (Criteria) this;
        }

        public Criteria andFriendcountEqualTo(Integer value) {
            addCriterion("friendcount =", value, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountNotEqualTo(Integer value) {
            addCriterion("friendcount <>", value, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountGreaterThan(Integer value) {
            addCriterion("friendcount >", value, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("friendcount >=", value, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountLessThan(Integer value) {
            addCriterion("friendcount <", value, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountLessThanOrEqualTo(Integer value) {
            addCriterion("friendcount <=", value, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountIn(List<Integer> values) {
            addCriterion("friendcount in", values, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountNotIn(List<Integer> values) {
            addCriterion("friendcount not in", values, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountBetween(Integer value1, Integer value2) {
            addCriterion("friendcount between", value1, value2, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFriendcountNotBetween(Integer value1, Integer value2) {
            addCriterion("friendcount not between", value1, value2, "friendcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountIsNull() {
            addCriterion("follwcount is null");
            return (Criteria) this;
        }

        public Criteria andFollwcountIsNotNull() {
            addCriterion("follwcount is not null");
            return (Criteria) this;
        }

        public Criteria andFollwcountEqualTo(Integer value) {
            addCriterion("follwcount =", value, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountNotEqualTo(Integer value) {
            addCriterion("follwcount <>", value, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountGreaterThan(Integer value) {
            addCriterion("follwcount >", value, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("follwcount >=", value, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountLessThan(Integer value) {
            addCriterion("follwcount <", value, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountLessThanOrEqualTo(Integer value) {
            addCriterion("follwcount <=", value, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountIn(List<Integer> values) {
            addCriterion("follwcount in", values, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountNotIn(List<Integer> values) {
            addCriterion("follwcount not in", values, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountBetween(Integer value1, Integer value2) {
            addCriterion("follwcount between", value1, value2, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFollwcountNotBetween(Integer value1, Integer value2) {
            addCriterion("follwcount not between", value1, value2, "follwcount");
            return (Criteria) this;
        }

        public Criteria andFanscountIsNull() {
            addCriterion("fanscount is null");
            return (Criteria) this;
        }

        public Criteria andFanscountIsNotNull() {
            addCriterion("fanscount is not null");
            return (Criteria) this;
        }

        public Criteria andFanscountEqualTo(Integer value) {
            addCriterion("fanscount =", value, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountNotEqualTo(Integer value) {
            addCriterion("fanscount <>", value, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountGreaterThan(Integer value) {
            addCriterion("fanscount >", value, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountGreaterThanOrEqualTo(Integer value) {
            addCriterion("fanscount >=", value, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountLessThan(Integer value) {
            addCriterion("fanscount <", value, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountLessThanOrEqualTo(Integer value) {
            addCriterion("fanscount <=", value, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountIn(List<Integer> values) {
            addCriterion("fanscount in", values, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountNotIn(List<Integer> values) {
            addCriterion("fanscount not in", values, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountBetween(Integer value1, Integer value2) {
            addCriterion("fanscount between", value1, value2, "fanscount");
            return (Criteria) this;
        }

        public Criteria andFanscountNotBetween(Integer value1, Integer value2) {
            addCriterion("fanscount not between", value1, value2, "fanscount");
            return (Criteria) this;
        }

        public Criteria andGiftcountIsNull() {
            addCriterion("giftcount is null");
            return (Criteria) this;
        }

        public Criteria andGiftcountIsNotNull() {
            addCriterion("giftcount is not null");
            return (Criteria) this;
        }

        public Criteria andGiftcountEqualTo(Integer value) {
            addCriterion("giftcount =", value, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountNotEqualTo(Integer value) {
            addCriterion("giftcount <>", value, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountGreaterThan(Integer value) {
            addCriterion("giftcount >", value, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("giftcount >=", value, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountLessThan(Integer value) {
            addCriterion("giftcount <", value, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountLessThanOrEqualTo(Integer value) {
            addCriterion("giftcount <=", value, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountIn(List<Integer> values) {
            addCriterion("giftcount in", values, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountNotIn(List<Integer> values) {
            addCriterion("giftcount not in", values, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountBetween(Integer value1, Integer value2) {
            addCriterion("giftcount between", value1, value2, "giftcount");
            return (Criteria) this;
        }

        public Criteria andGiftcountNotBetween(Integer value1, Integer value2) {
            addCriterion("giftcount not between", value1, value2, "giftcount");
            return (Criteria) this;
        }

        public Criteria andProfileIsNull() {
            addCriterion("profile is null");
            return (Criteria) this;
        }

        public Criteria andProfileIsNotNull() {
            addCriterion("profile is not null");
            return (Criteria) this;
        }

        public Criteria andProfileEqualTo(String value) {
            addCriterion("profile =", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileNotEqualTo(String value) {
            addCriterion("profile <>", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileGreaterThan(String value) {
            addCriterion("profile >", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileGreaterThanOrEqualTo(String value) {
            addCriterion("profile >=", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileLessThan(String value) {
            addCriterion("profile <", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileLessThanOrEqualTo(String value) {
            addCriterion("profile <=", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileLike(String value) {
            addCriterion("profile like", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileNotLike(String value) {
            addCriterion("profile not like", value, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileIn(List<String> values) {
            addCriterion("profile in", values, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileNotIn(List<String> values) {
            addCriterion("profile not in", values, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileBetween(String value1, String value2) {
            addCriterion("profile between", value1, value2, "profile");
            return (Criteria) this;
        }

        public Criteria andProfileNotBetween(String value1, String value2) {
            addCriterion("profile not between", value1, value2, "profile");
            return (Criteria) this;
        }

        public Criteria andTokenIsNull() {
            addCriterion("token is null");
            return (Criteria) this;
        }

        public Criteria andTokenIsNotNull() {
            addCriterion("token is not null");
            return (Criteria) this;
        }

        public Criteria andTokenEqualTo(String value) {
            addCriterion("token =", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotEqualTo(String value) {
            addCriterion("token <>", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenGreaterThan(String value) {
            addCriterion("token >", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenGreaterThanOrEqualTo(String value) {
            addCriterion("token >=", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLessThan(String value) {
            addCriterion("token <", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLessThanOrEqualTo(String value) {
            addCriterion("token <=", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLike(String value) {
            addCriterion("token like", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotLike(String value) {
            addCriterion("token not like", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenIn(List<String> values) {
            addCriterion("token in", values, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotIn(List<String> values) {
            addCriterion("token not in", values, "token");
            return (Criteria) this;
        }

        public Criteria andTokenBetween(String value1, String value2) {
            addCriterion("token between", value1, value2, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotBetween(String value1, String value2) {
            addCriterion("token not between", value1, value2, "token");
            return (Criteria) this;
        }

        public Criteria andRelationIsNull() {
            addCriterion("relation is null");
            return (Criteria) this;
        }

        public Criteria andRelationIsNotNull() {
            addCriterion("relation is not null");
            return (Criteria) this;
        }

        public Criteria andRelationEqualTo(String value) {
            addCriterion("relation =", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationNotEqualTo(String value) {
            addCriterion("relation <>", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationGreaterThan(String value) {
            addCriterion("relation >", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationGreaterThanOrEqualTo(String value) {
            addCriterion("relation >=", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationLessThan(String value) {
            addCriterion("relation <", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationLessThanOrEqualTo(String value) {
            addCriterion("relation <=", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationLike(String value) {
            addCriterion("relation like", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationNotLike(String value) {
            addCriterion("relation not like", value, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationIn(List<String> values) {
            addCriterion("relation in", values, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationNotIn(List<String> values) {
            addCriterion("relation not in", values, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationBetween(String value1, String value2) {
            addCriterion("relation between", value1, value2, "relation");
            return (Criteria) this;
        }

        public Criteria andRelationNotBetween(String value1, String value2) {
            addCriterion("relation not between", value1, value2, "relation");
            return (Criteria) this;
        }

        public Criteria andAgeIsNull() {
            addCriterion("age is null");
            return (Criteria) this;
        }

        public Criteria andAgeIsNotNull() {
            addCriterion("age is not null");
            return (Criteria) this;
        }

        public Criteria andAgeEqualTo(Integer value) {
            addCriterion("age =", value, "age");
            return (Criteria) this;
        }

        public Criteria andAgeNotEqualTo(Integer value) {
            addCriterion("age <>", value, "age");
            return (Criteria) this;
        }

        public Criteria andAgeGreaterThan(Integer value) {
            addCriterion("age >", value, "age");
            return (Criteria) this;
        }

        public Criteria andAgeGreaterThanOrEqualTo(Integer value) {
            addCriterion("age >=", value, "age");
            return (Criteria) this;
        }

        public Criteria andAgeLessThan(Integer value) {
            addCriterion("age <", value, "age");
            return (Criteria) this;
        }

        public Criteria andAgeLessThanOrEqualTo(Integer value) {
            addCriterion("age <=", value, "age");
            return (Criteria) this;
        }

        public Criteria andAgeIn(List<Integer> values) {
            addCriterion("age in", values, "age");
            return (Criteria) this;
        }

        public Criteria andAgeNotIn(List<Integer> values) {
            addCriterion("age not in", values, "age");
            return (Criteria) this;
        }

        public Criteria andAgeBetween(Integer value1, Integer value2) {
            addCriterion("age between", value1, value2, "age");
            return (Criteria) this;
        }

        public Criteria andAgeNotBetween(Integer value1, Integer value2) {
            addCriterion("age not between", value1, value2, "age");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}