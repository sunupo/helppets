package cn.tt.bean;

import java.util.Date;

public class Sign {
    private String accountId;

    private Date beginSign;

    private Date endSign;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId == null ? null : accountId.trim();
    }

    public Date getBeginSign() {
        return beginSign;
    }

    public void setBeginSign(Date beginSign) {
        this.beginSign = beginSign;
    }

    public Date getEndSign() {
        return endSign;
    }

    public void setEndSign(Date endSign) {
        this.endSign = endSign;
    }
}