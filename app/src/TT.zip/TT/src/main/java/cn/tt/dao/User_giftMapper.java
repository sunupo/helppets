package cn.tt.dao;

import cn.tt.bean.User_gift;
import cn.tt.bean.User_giftExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface User_giftMapper {
    long countByExample(User_giftExample example);

    int deleteByExample(User_giftExample example);

    int insert(User_gift record);

    int insertSelective(User_gift record);

    List<User_gift> selectByExample(User_giftExample example);

    int updateByExampleSelective(@Param("record") User_gift record, @Param("example") User_giftExample example);

    int updateByExample(@Param("record") User_gift record, @Param("example") User_giftExample example);
    
    @Select("select sum(count) from user_gift where account_id = #{accountId}")
    long sumByAccountid(String accountId);
}