package cn.tt.bean;

import java.util.List;

public class Dynamic {
    private String dId;

    private String accountId;

    private Integer dCategory;

    private String dReleasetime;

    private Integer support;

    private Integer unlike;

    private Integer gift;

    private Integer comment;

    private Integer share;

    private String dyima;

    private String dContent;
    
    private User_info user_info;
    private List<Comment> commentList;
    
    

	public List<Comment> getCommentList() {
		return commentList;
	}

	public void setCommentList(List<Comment> commentList) {
		this.commentList = commentList;
	}

	public User_info getUser_info() {
		return user_info;
	}

	public void setUser_info(User_info user_info) {
		this.user_info = user_info;
	}

    public String getdId() {
        return dId;
    }

    public void setdId(String dId) {
        this.dId = dId == null ? null : dId.trim();
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId == null ? null : accountId.trim();
    }

    public Integer getdCategory() {
        return dCategory;
    }

    public void setdCategory(Integer dCategory) {
        this.dCategory = dCategory;
    }

    public String getdReleasetime() {
        return dReleasetime;
    }

    public void setdReleasetime(String dReleasetime) {
        this.dReleasetime = dReleasetime == null ? null : dReleasetime.trim();
    }

    public Integer getSupport() {
        return support;
    }

    public void setSupport(Integer support) {
        this.support = support;
    }

    public Integer getUnlike() {
        return unlike;
    }

    public void setUnlike(Integer unlike) {
        this.unlike = unlike;
    }

    public Integer getGift() {
        return gift;
    }

    public void setGift(Integer gift) {
        this.gift = gift;
    }

    public Integer getComment() {
        return comment;
    }

    public void setComment(Integer comment) {
        this.comment = comment;
    }

    public Integer getShare() {
        return share;
    }

    public void setShare(Integer share) {
        this.share = share;
    }

    public String getDyima() {
        return dyima;
    }

    public void setDyima(String dyima) {
        this.dyima = dyima == null ? null : dyima.trim();
    }

    public String getdContent() {
        return dContent;
    }

    public void setdContent(String dContent) {
        this.dContent = dContent == null ? null : dContent.trim();
    }
}