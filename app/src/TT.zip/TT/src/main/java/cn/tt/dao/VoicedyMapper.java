package cn.tt.dao;

import cn.tt.bean.Voicedy;
import cn.tt.bean.VoicedyExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface VoicedyMapper {
    long countByExample(VoicedyExample example);

    int deleteByExample(VoicedyExample example);

    int deleteByPrimaryKey(String vId);

    int insert(Voicedy record);

    int insertSelective(Voicedy record);

    List<Voicedy> selectByExample(VoicedyExample example);
    
    List<Voicedy> selectVoicedy();
    
    List<Voicedy> selectVoicedybyUserId(String accountId);

    Voicedy selectByPrimaryKey(String vId);

    int updateByExampleSelective(@Param("record") Voicedy record, @Param("example") VoicedyExample example);

    int updateByExample(@Param("record") Voicedy record, @Param("example") VoicedyExample example);

    int updateByPrimaryKeySelective(Voicedy record);

    int updateByPrimaryKey(Voicedy record);
    
}