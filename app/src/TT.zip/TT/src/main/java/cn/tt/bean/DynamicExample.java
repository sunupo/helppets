package cn.tt.bean;

import java.util.ArrayList;
import java.util.List;

public class DynamicExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DynamicExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDIdIsNull() {
            addCriterion("d_id is null");
            return (Criteria) this;
        }

        public Criteria andDIdIsNotNull() {
            addCriterion("d_id is not null");
            return (Criteria) this;
        }

        public Criteria andDIdEqualTo(String value) {
            addCriterion("d_id =", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdNotEqualTo(String value) {
            addCriterion("d_id <>", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdGreaterThan(String value) {
            addCriterion("d_id >", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdGreaterThanOrEqualTo(String value) {
            addCriterion("d_id >=", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdLessThan(String value) {
            addCriterion("d_id <", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdLessThanOrEqualTo(String value) {
            addCriterion("d_id <=", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdLike(String value) {
            addCriterion("d_id like", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdNotLike(String value) {
            addCriterion("d_id not like", value, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdIn(List<String> values) {
            addCriterion("d_id in", values, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdNotIn(List<String> values) {
            addCriterion("d_id not in", values, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdBetween(String value1, String value2) {
            addCriterion("d_id between", value1, value2, "dId");
            return (Criteria) this;
        }

        public Criteria andDIdNotBetween(String value1, String value2) {
            addCriterion("d_id not between", value1, value2, "dId");
            return (Criteria) this;
        }

        public Criteria andAccountIdIsNull() {
            addCriterion("account_id is null");
            return (Criteria) this;
        }

        public Criteria andAccountIdIsNotNull() {
            addCriterion("account_id is not null");
            return (Criteria) this;
        }

        public Criteria andAccountIdEqualTo(String value) {
            addCriterion("account_id =", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotEqualTo(String value) {
            addCriterion("account_id <>", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThan(String value) {
            addCriterion("account_id >", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThanOrEqualTo(String value) {
            addCriterion("account_id >=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThan(String value) {
            addCriterion("account_id <", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThanOrEqualTo(String value) {
            addCriterion("account_id <=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLike(String value) {
            addCriterion("account_id like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotLike(String value) {
            addCriterion("account_id not like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdIn(List<String> values) {
            addCriterion("account_id in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotIn(List<String> values) {
            addCriterion("account_id not in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdBetween(String value1, String value2) {
            addCriterion("account_id between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotBetween(String value1, String value2) {
            addCriterion("account_id not between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andDCategoryIsNull() {
            addCriterion("d_category is null");
            return (Criteria) this;
        }

        public Criteria andDCategoryIsNotNull() {
            addCriterion("d_category is not null");
            return (Criteria) this;
        }

        public Criteria andDCategoryEqualTo(Integer value) {
            addCriterion("d_category =", value, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryNotEqualTo(Integer value) {
            addCriterion("d_category <>", value, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryGreaterThan(Integer value) {
            addCriterion("d_category >", value, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryGreaterThanOrEqualTo(Integer value) {
            addCriterion("d_category >=", value, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryLessThan(Integer value) {
            addCriterion("d_category <", value, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryLessThanOrEqualTo(Integer value) {
            addCriterion("d_category <=", value, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryIn(List<Integer> values) {
            addCriterion("d_category in", values, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryNotIn(List<Integer> values) {
            addCriterion("d_category not in", values, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryBetween(Integer value1, Integer value2) {
            addCriterion("d_category between", value1, value2, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDCategoryNotBetween(Integer value1, Integer value2) {
            addCriterion("d_category not between", value1, value2, "dCategory");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeIsNull() {
            addCriterion("d_releasetime is null");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeIsNotNull() {
            addCriterion("d_releasetime is not null");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeEqualTo(String value) {
            addCriterion("d_releasetime =", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeNotEqualTo(String value) {
            addCriterion("d_releasetime <>", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeGreaterThan(String value) {
            addCriterion("d_releasetime >", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeGreaterThanOrEqualTo(String value) {
            addCriterion("d_releasetime >=", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeLessThan(String value) {
            addCriterion("d_releasetime <", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeLessThanOrEqualTo(String value) {
            addCriterion("d_releasetime <=", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeLike(String value) {
            addCriterion("d_releasetime like", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeNotLike(String value) {
            addCriterion("d_releasetime not like", value, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeIn(List<String> values) {
            addCriterion("d_releasetime in", values, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeNotIn(List<String> values) {
            addCriterion("d_releasetime not in", values, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeBetween(String value1, String value2) {
            addCriterion("d_releasetime between", value1, value2, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andDReleasetimeNotBetween(String value1, String value2) {
            addCriterion("d_releasetime not between", value1, value2, "dReleasetime");
            return (Criteria) this;
        }

        public Criteria andSupportIsNull() {
            addCriterion("support is null");
            return (Criteria) this;
        }

        public Criteria andSupportIsNotNull() {
            addCriterion("support is not null");
            return (Criteria) this;
        }

        public Criteria andSupportEqualTo(Integer value) {
            addCriterion("support =", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotEqualTo(Integer value) {
            addCriterion("support <>", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportGreaterThan(Integer value) {
            addCriterion("support >", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportGreaterThanOrEqualTo(Integer value) {
            addCriterion("support >=", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportLessThan(Integer value) {
            addCriterion("support <", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportLessThanOrEqualTo(Integer value) {
            addCriterion("support <=", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportIn(List<Integer> values) {
            addCriterion("support in", values, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotIn(List<Integer> values) {
            addCriterion("support not in", values, "support");
            return (Criteria) this;
        }

        public Criteria andSupportBetween(Integer value1, Integer value2) {
            addCriterion("support between", value1, value2, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotBetween(Integer value1, Integer value2) {
            addCriterion("support not between", value1, value2, "support");
            return (Criteria) this;
        }

        public Criteria andUnlikeIsNull() {
            addCriterion("unlike is null");
            return (Criteria) this;
        }

        public Criteria andUnlikeIsNotNull() {
            addCriterion("unlike is not null");
            return (Criteria) this;
        }

        public Criteria andUnlikeEqualTo(Integer value) {
            addCriterion("unlike =", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotEqualTo(Integer value) {
            addCriterion("unlike <>", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeGreaterThan(Integer value) {
            addCriterion("unlike >", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeGreaterThanOrEqualTo(Integer value) {
            addCriterion("unlike >=", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeLessThan(Integer value) {
            addCriterion("unlike <", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeLessThanOrEqualTo(Integer value) {
            addCriterion("unlike <=", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeIn(List<Integer> values) {
            addCriterion("unlike in", values, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotIn(List<Integer> values) {
            addCriterion("unlike not in", values, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeBetween(Integer value1, Integer value2) {
            addCriterion("unlike between", value1, value2, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotBetween(Integer value1, Integer value2) {
            addCriterion("unlike not between", value1, value2, "unlike");
            return (Criteria) this;
        }

        public Criteria andGiftIsNull() {
            addCriterion("gift is null");
            return (Criteria) this;
        }

        public Criteria andGiftIsNotNull() {
            addCriterion("gift is not null");
            return (Criteria) this;
        }

        public Criteria andGiftEqualTo(Integer value) {
            addCriterion("gift =", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftNotEqualTo(Integer value) {
            addCriterion("gift <>", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftGreaterThan(Integer value) {
            addCriterion("gift >", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftGreaterThanOrEqualTo(Integer value) {
            addCriterion("gift >=", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftLessThan(Integer value) {
            addCriterion("gift <", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftLessThanOrEqualTo(Integer value) {
            addCriterion("gift <=", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftIn(List<Integer> values) {
            addCriterion("gift in", values, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftNotIn(List<Integer> values) {
            addCriterion("gift not in", values, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftBetween(Integer value1, Integer value2) {
            addCriterion("gift between", value1, value2, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftNotBetween(Integer value1, Integer value2) {
            addCriterion("gift not between", value1, value2, "gift");
            return (Criteria) this;
        }

        public Criteria andCommentIsNull() {
            addCriterion("comment is null");
            return (Criteria) this;
        }

        public Criteria andCommentIsNotNull() {
            addCriterion("comment is not null");
            return (Criteria) this;
        }

        public Criteria andCommentEqualTo(Integer value) {
            addCriterion("comment =", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotEqualTo(Integer value) {
            addCriterion("comment <>", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThan(Integer value) {
            addCriterion("comment >", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThanOrEqualTo(Integer value) {
            addCriterion("comment >=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThan(Integer value) {
            addCriterion("comment <", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThanOrEqualTo(Integer value) {
            addCriterion("comment <=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentIn(List<Integer> values) {
            addCriterion("comment in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotIn(List<Integer> values) {
            addCriterion("comment not in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentBetween(Integer value1, Integer value2) {
            addCriterion("comment between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotBetween(Integer value1, Integer value2) {
            addCriterion("comment not between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andShareIsNull() {
            addCriterion("share is null");
            return (Criteria) this;
        }

        public Criteria andShareIsNotNull() {
            addCriterion("share is not null");
            return (Criteria) this;
        }

        public Criteria andShareEqualTo(Integer value) {
            addCriterion("share =", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareNotEqualTo(Integer value) {
            addCriterion("share <>", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareGreaterThan(Integer value) {
            addCriterion("share >", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareGreaterThanOrEqualTo(Integer value) {
            addCriterion("share >=", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareLessThan(Integer value) {
            addCriterion("share <", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareLessThanOrEqualTo(Integer value) {
            addCriterion("share <=", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareIn(List<Integer> values) {
            addCriterion("share in", values, "share");
            return (Criteria) this;
        }

        public Criteria andShareNotIn(List<Integer> values) {
            addCriterion("share not in", values, "share");
            return (Criteria) this;
        }

        public Criteria andShareBetween(Integer value1, Integer value2) {
            addCriterion("share between", value1, value2, "share");
            return (Criteria) this;
        }

        public Criteria andShareNotBetween(Integer value1, Integer value2) {
            addCriterion("share not between", value1, value2, "share");
            return (Criteria) this;
        }

        public Criteria andDyimaIsNull() {
            addCriterion("dyima is null");
            return (Criteria) this;
        }

        public Criteria andDyimaIsNotNull() {
            addCriterion("dyima is not null");
            return (Criteria) this;
        }

        public Criteria andDyimaEqualTo(String value) {
            addCriterion("dyima =", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaNotEqualTo(String value) {
            addCriterion("dyima <>", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaGreaterThan(String value) {
            addCriterion("dyima >", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaGreaterThanOrEqualTo(String value) {
            addCriterion("dyima >=", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaLessThan(String value) {
            addCriterion("dyima <", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaLessThanOrEqualTo(String value) {
            addCriterion("dyima <=", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaLike(String value) {
            addCriterion("dyima like", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaNotLike(String value) {
            addCriterion("dyima not like", value, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaIn(List<String> values) {
            addCriterion("dyima in", values, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaNotIn(List<String> values) {
            addCriterion("dyima not in", values, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaBetween(String value1, String value2) {
            addCriterion("dyima between", value1, value2, "dyima");
            return (Criteria) this;
        }

        public Criteria andDyimaNotBetween(String value1, String value2) {
            addCriterion("dyima not between", value1, value2, "dyima");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}