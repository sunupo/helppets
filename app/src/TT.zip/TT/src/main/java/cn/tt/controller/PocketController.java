package cn.tt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Bill;
import cn.tt.bean.Gift;
import cn.tt.bean.Msg;
import cn.tt.bean.Wallet;
import cn.tt.service.PocketService;
import cn.tt.service.WalletService;
/*
 * 钱包controller
 */
@Controller
@RequestMapping("/pocket")
public class PocketController {
	 
	@Autowired
	private PocketService pocketService;
	
	//得到用户的账户信息
	@ResponseBody
	@RequestMapping("/home/{accountid}")
	public Msg getPocketInfo(@PathVariable("accountid") String accountid) {
		Wallet wallet = pocketService.getInfo(accountid);
		if (wallet != null)
			return Msg.success().add("wallet", wallet);
		else {
			return Msg.fail();
		}
	}
	
	//得到所有的电子礼物信息
	@ResponseBody
	@RequestMapping("/gift/allgifts")
	public Msg getAllGifts(){
		List<Gift> gifts = pocketService.allGifts();
		if (gifts != null)
			return Msg.success().add("gifts", gifts);
		else {
			return Msg.fail();
		}
	}
	
	//兑换礼物
	@ResponseBody
	@RequestMapping("/gift/exchange")
	public Msg exchange(@RequestParam("accountid") String accountid,
			@RequestParam("giftid") int giftid,
			@RequestParam("isintegeral") boolean isintegeral){
		boolean b = pocketService.exchange(accountid, giftid, isintegeral);
		if(b)
			return Msg.success();
		else
			return Msg.fail();
	}
	
	//礼物兑换成积分
	@ResponseBody
	@RequestMapping("/gift/exchangeforintegral")
	public Msg exchangeForIntegral(@RequestParam("accountid") String accountid,
			@RequestParam("giftid") int giftid,
			@RequestParam("num") int num,
			@RequestParam("isintegeral") boolean isintegeral){
		boolean b = pocketService.exchangeForIntegral(accountid, giftid, num, isintegeral);
		if(b)
			return Msg.success();
		else
			return Msg.fail();
	}
	
	//充值积分/诚意分
	@RequestMapping("/recharge")
	public void recharge(@RequestParam("accountid") String accountid,
			@RequestParam("num") int num,
			@RequestParam("isintegeral") boolean isintegeral){
		pocketService.recharge(accountid, num, isintegeral);

	}
	
	//得到账单列表
	@ResponseBody
	@RequestMapping("/bill/{accountid}")
	public Msg getBill(@PathVariable("accountid") String accountid){
		List<Bill> list = pocketService.getBill(accountid);
		if(list == null)
			return Msg.fail();
		else
			return Msg.success().add("bills", list);
	}
	
	//提现
	@ResponseBody
	@RequestMapping("/withdraw")
	public Msg withdraw(@RequestParam("accountid") String accountid,
			@RequestParam("num") int num,
			@RequestParam("username") String username){
		boolean b = pocketService.writeAlipay(accountid,username, num);
		if(b)
			return Msg.success();
		else
			return Msg.fail();
	}
	
	//聊天模块中，根据发送的需要扣分的信息数量来扣积分
	@ResponseBody
	@RequestMapping("/reduceChatIntegral")
	public Msg reduceChatIntegral(@RequestParam("accountid") String accountid,
			@RequestParam("num") int num){
		boolean b = pocketService.reduceChat(accountid,num);
		if(b)
			return Msg.success();
		else
			return Msg.fail();
	}
	
	//付费相册的扣费
	@ResponseBody
	@RequestMapping("/payforalbum")
	public Msg withdraw(@RequestParam("accountid") String accountid,
			@RequestParam("friendid") String friendid,
			@RequestParam("num") int num){
		int b = pocketService.payForAlbum(accountid,friendid,num);
		if(b != 0)
			return Msg.success();
		else
			return Msg.fail();
	}
}
