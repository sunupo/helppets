package cn.tt.bean;

import java.util.Date;

public class Wallet {
    private String accountId;

    private Integer integral;

    private Integer sincerity;

    private Integer signcount;

    private Integer rewardcount;

    private Integer chatcount;

    private Integer sharecount;

    private Byte vip;

    private Date expire;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId == null ? null : accountId.trim();
    }

    public Integer getIntegral() {
        return integral;
    }

    public void setIntegral(Integer integral) {
        this.integral = integral;
    }

    public Integer getSincerity() {
        return sincerity;
    }

    public void setSincerity(Integer sincerity) {
        this.sincerity = sincerity;
    }

    public Integer getSigncount() {
        return signcount;
    }

    public void setSigncount(Integer signcount) {
        this.signcount = signcount;
    }

    public Integer getRewardcount() {
        return rewardcount;
    }

    public void setRewardcount(Integer rewardcount) {
        this.rewardcount = rewardcount;
    }

    public Integer getChatcount() {
        return chatcount;
    }

    public void setChatcount(Integer chatcount) {
        this.chatcount = chatcount;
    }

    public Integer getSharecount() {
        return sharecount;
    }

    public void setSharecount(Integer sharecount) {
        this.sharecount = sharecount;
    }

    public Byte getVip() {
        return vip;
    }

    public void setVip(Byte vip) {
        this.vip = vip;
    }

    public Date getExpire() {
        return expire;
    }

    public void setExpire(Date expire) {
        this.expire = expire;
    }
}