package cn.tt.utils;

public class GiftHolder {
	private Integer gId;

    private Integer gCategory;

    private String gName;

    private String pictureurl;

    private Integer integral;

    private Integer sincererity;
    
    private Integer count;

	public Integer getgId() {
		return gId;
	}

	public void setgId(Integer gId) {
		this.gId = gId;
	}

	public Integer getgCategory() {
		return gCategory;
	}

	public void setgCategory(Integer gCategory) {
		this.gCategory = gCategory;
	}

	public String getgName() {
		return gName;
	}

	public void setgName(String gName) {
		this.gName = gName;
	}

	public String getPictureurl() {
		return pictureurl;
	}

	public void setPictureurl(String pictureurl) {
		this.pictureurl = pictureurl;
	}

	public Integer getIntegral() {
		return integral;
	}

	public void setIntegral(Integer integral) {
		this.integral = integral;
	}

	public Integer getSincererity() {
		return sincererity;
	}

	public void setSincererity(Integer sincererity) {
		this.sincererity = sincererity;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
    
    
}
