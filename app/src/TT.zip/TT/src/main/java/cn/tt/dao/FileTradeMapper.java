package cn.tt.dao;

import cn.tt.bean.FileTrade;
import cn.tt.bean.FileTradeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface FileTradeMapper {
    long countByExample(FileTradeExample example);

    int deleteByExample(FileTradeExample example);

    int deleteByPrimaryKey(String tradeid);

    int insert(FileTrade record);

    int insertSelective(FileTrade record);

    List<FileTrade> selectByExample(FileTradeExample example);

    FileTrade selectByPrimaryKey(String tradeid);

    int updateByExampleSelective(@Param("record") FileTrade record, @Param("example") FileTradeExample example);

    int updateByExample(@Param("record") FileTrade record, @Param("example") FileTradeExample example);

    int updateByPrimaryKeySelective(FileTrade record);

    int updateByPrimaryKey(FileTrade record);
    FileTrade selectUniqueTrade(FileTrade record);
    FileTrade selectAlbumTrade(FileTrade record);
}