package cn.tt.bean;

public class VoiComment {
    private String vcId;

    private String account;

    private String commnetAccount;

    private String voicedyId;

    private String content;

    private Integer support;

    private Integer unlike;

    public String getVcId() {
        return vcId;
    }

    public void setVcId(String vcId) {
        this.vcId = vcId == null ? null : vcId.trim();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public String getCommnetAccount() {
        return commnetAccount;
    }

    public void setCommnetAccount(String commnetAccount) {
        this.commnetAccount = commnetAccount == null ? null : commnetAccount.trim();
    }

    public String getVoicedyId() {
        return voicedyId;
    }

    public void setVoicedyId(String voicedyId) {
        this.voicedyId = voicedyId == null ? null : voicedyId.trim();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getSupport() {
        return support;
    }

    public void setSupport(Integer support) {
        this.support = support;
    }

    public Integer getUnlike() {
        return unlike;
    }

    public void setUnlike(Integer unlike) {
        this.unlike = unlike;
    }
}