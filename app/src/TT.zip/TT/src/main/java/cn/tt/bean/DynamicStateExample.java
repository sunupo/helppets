package cn.tt.bean;

import java.util.ArrayList;
import java.util.List;

public class DynamicStateExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DynamicStateExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andStateidIsNull() {
            addCriterion("stateid is null");
            return (Criteria) this;
        }

        public Criteria andStateidIsNotNull() {
            addCriterion("stateid is not null");
            return (Criteria) this;
        }

        public Criteria andStateidEqualTo(String value) {
            addCriterion("stateid =", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidNotEqualTo(String value) {
            addCriterion("stateid <>", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidGreaterThan(String value) {
            addCriterion("stateid >", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidGreaterThanOrEqualTo(String value) {
            addCriterion("stateid >=", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidLessThan(String value) {
            addCriterion("stateid <", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidLessThanOrEqualTo(String value) {
            addCriterion("stateid <=", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidLike(String value) {
            addCriterion("stateid like", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidNotLike(String value) {
            addCriterion("stateid not like", value, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidIn(List<String> values) {
            addCriterion("stateid in", values, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidNotIn(List<String> values) {
            addCriterion("stateid not in", values, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidBetween(String value1, String value2) {
            addCriterion("stateid between", value1, value2, "stateid");
            return (Criteria) this;
        }

        public Criteria andStateidNotBetween(String value1, String value2) {
            addCriterion("stateid not between", value1, value2, "stateid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNull() {
            addCriterion("dynamicid is null");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNotNull() {
            addCriterion("dynamicid is not null");
            return (Criteria) this;
        }

        public Criteria andDynamicidEqualTo(String value) {
            addCriterion("dynamicid =", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotEqualTo(String value) {
            addCriterion("dynamicid <>", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThan(String value) {
            addCriterion("dynamicid >", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThanOrEqualTo(String value) {
            addCriterion("dynamicid >=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThan(String value) {
            addCriterion("dynamicid <", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThanOrEqualTo(String value) {
            addCriterion("dynamicid <=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLike(String value) {
            addCriterion("dynamicid like", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotLike(String value) {
            addCriterion("dynamicid not like", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIn(List<String> values) {
            addCriterion("dynamicid in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotIn(List<String> values) {
            addCriterion("dynamicid not in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidBetween(String value1, String value2) {
            addCriterion("dynamicid between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotBetween(String value1, String value2) {
            addCriterion("dynamicid not between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNull() {
            addCriterion("accountid is null");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNotNull() {
            addCriterion("accountid is not null");
            return (Criteria) this;
        }

        public Criteria andAccountidEqualTo(String value) {
            addCriterion("accountid =", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotEqualTo(String value) {
            addCriterion("accountid <>", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThan(String value) {
            addCriterion("accountid >", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThanOrEqualTo(String value) {
            addCriterion("accountid >=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThan(String value) {
            addCriterion("accountid <", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThanOrEqualTo(String value) {
            addCriterion("accountid <=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLike(String value) {
            addCriterion("accountid like", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotLike(String value) {
            addCriterion("accountid not like", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidIn(List<String> values) {
            addCriterion("accountid in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotIn(List<String> values) {
            addCriterion("accountid not in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidBetween(String value1, String value2) {
            addCriterion("accountid between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotBetween(String value1, String value2) {
            addCriterion("accountid not between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeIsNull() {
            addCriterion("dynamic_type is null");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeIsNotNull() {
            addCriterion("dynamic_type is not null");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeEqualTo(Integer value) {
            addCriterion("dynamic_type =", value, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeNotEqualTo(Integer value) {
            addCriterion("dynamic_type <>", value, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeGreaterThan(Integer value) {
            addCriterion("dynamic_type >", value, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("dynamic_type >=", value, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeLessThan(Integer value) {
            addCriterion("dynamic_type <", value, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeLessThanOrEqualTo(Integer value) {
            addCriterion("dynamic_type <=", value, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeIn(List<Integer> values) {
            addCriterion("dynamic_type in", values, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeNotIn(List<Integer> values) {
            addCriterion("dynamic_type not in", values, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeBetween(Integer value1, Integer value2) {
            addCriterion("dynamic_type between", value1, value2, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andDynamicTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("dynamic_type not between", value1, value2, "dynamicType");
            return (Criteria) this;
        }

        public Criteria andSupportIsNull() {
            addCriterion("support is null");
            return (Criteria) this;
        }

        public Criteria andSupportIsNotNull() {
            addCriterion("support is not null");
            return (Criteria) this;
        }

        public Criteria andSupportEqualTo(Integer value) {
            addCriterion("support =", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotEqualTo(Integer value) {
            addCriterion("support <>", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportGreaterThan(Integer value) {
            addCriterion("support >", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportGreaterThanOrEqualTo(Integer value) {
            addCriterion("support >=", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportLessThan(Integer value) {
            addCriterion("support <", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportLessThanOrEqualTo(Integer value) {
            addCriterion("support <=", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportIn(List<Integer> values) {
            addCriterion("support in", values, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotIn(List<Integer> values) {
            addCriterion("support not in", values, "support");
            return (Criteria) this;
        }

        public Criteria andSupportBetween(Integer value1, Integer value2) {
            addCriterion("support between", value1, value2, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotBetween(Integer value1, Integer value2) {
            addCriterion("support not between", value1, value2, "support");
            return (Criteria) this;
        }

        public Criteria andUnlikeIsNull() {
            addCriterion("unlike is null");
            return (Criteria) this;
        }

        public Criteria andUnlikeIsNotNull() {
            addCriterion("unlike is not null");
            return (Criteria) this;
        }

        public Criteria andUnlikeEqualTo(Integer value) {
            addCriterion("unlike =", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotEqualTo(Integer value) {
            addCriterion("unlike <>", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeGreaterThan(Integer value) {
            addCriterion("unlike >", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeGreaterThanOrEqualTo(Integer value) {
            addCriterion("unlike >=", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeLessThan(Integer value) {
            addCriterion("unlike <", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeLessThanOrEqualTo(Integer value) {
            addCriterion("unlike <=", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeIn(List<Integer> values) {
            addCriterion("unlike in", values, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotIn(List<Integer> values) {
            addCriterion("unlike not in", values, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeBetween(Integer value1, Integer value2) {
            addCriterion("unlike between", value1, value2, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotBetween(Integer value1, Integer value2) {
            addCriterion("unlike not between", value1, value2, "unlike");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}