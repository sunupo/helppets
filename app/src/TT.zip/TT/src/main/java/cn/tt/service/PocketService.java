package cn.tt.service;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Bill;
import cn.tt.bean.BillExample;
import cn.tt.bean.Gift;
import cn.tt.bean.GiftExample;
import cn.tt.bean.Wallet;
import cn.tt.dao.BillMapper;
import cn.tt.dao.GiftMapper;
import cn.tt.dao.WalletMapper;
import cn.tt.utils.GiftHolder;
import cn.tt.utils.MyProp;

@Service
public class PocketService {
	private String location = MyProp.baseAlipayUrl+"\\alipay.txt";
	private String location_bak = MyProp.baseAlipayUrl+"\\alipay_bak.txt";
	@Autowired
	private WalletMapper walletMapper;

	@Autowired
	private GiftMapper giftMapper;

	@Autowired
	private User_giftService user_giftService;

	@Autowired
	private BillMapper billMapper;
	

	public Wallet getInfo(String accountId) {
		return walletMapper.selectByPrimaryKey(accountId);
	}

	public List<Gift> allGifts() {
		GiftExample example = new GiftExample();
		return giftMapper.selectByExample(example);
	}

	public boolean exchange(String accountid, int giftid, boolean isIntegeral) {
		Wallet wallet = walletMapper.selectByPrimaryKey(accountid);
		int num = 0;
		Gift gift = giftMapper.selectByPrimaryKey(giftid);
		if (isIntegeral) {
			if (wallet.getIntegral() >= gift.getIntegral()) {
				user_giftService.addGift(accountid, giftid, "-1", accountid);
				wallet.setIntegral(wallet.getIntegral() - gift.getIntegral());
				walletMapper.updateByPrimaryKey(wallet);
				//用积分兑换礼物category为3
				addBill(accountid,-gift.getIntegral(),3);
				return true;
			}

		} else {
			if (wallet.getSincerity() > gift.getSincererity()) {
				user_giftService.addGift(accountid, giftid, "-1", accountid);
				wallet.setSincerity(wallet.getSincerity() - gift.getSincererity());
				walletMapper.updateByPrimaryKey(wallet);
				return true;
			}
		}
		return false;
	}

	public boolean exchangeForIntegral(String accountid, int giftid, int num, boolean isIntegeral) {
		Wallet wallet = walletMapper.selectByPrimaryKey(accountid);
		int all = 0;
		// 如果是兑换全部
		if (giftid == -1 && num == -1) {
			List<GiftHolder> gifts = user_giftService.getGifts(accountid);
			if (isIntegeral) {
				for (GiftHolder gift : gifts) {
					all += gift.getIntegral() * gift.getCount();
				}
				wallet.setIntegral(wallet.getIntegral() + all);
				walletMapper.updateByPrimaryKey(wallet);
				//兑换礼物获得category为1
				addBill(accountid,all,1);
			} else {
				for (GiftHolder gift : gifts) {
					all += gift.getSincererity() * gift.getCount();
				}
				wallet.setSincerity(wallet.getSincerity() + all);
				walletMapper.updateByPrimaryKey(wallet);
			}
			int d = user_giftService.deleteAllGifts(accountid);
			return d > 0?true:false;
		} else {
			Gift gift = giftMapper.selectByPrimaryKey(giftid);
			if (isIntegeral) {
				all = gift.getIntegral() * num;
				user_giftService.removeGiftFromExchange(accountid, giftid, num);
				wallet.setIntegral(wallet.getIntegral() + all);
				walletMapper.updateByPrimaryKey(wallet);
				addBill(accountid,all,1);
				return true;
			} else {
				all = gift.getSincererity() * num;
				if (wallet.getSincerity() > gift.getSincererity()) {
					user_giftService.removeGiftFromExchange(accountid, giftid, num);
					wallet.setSincerity(wallet.getSincerity() + all);
					walletMapper.updateByPrimaryKey(wallet);
					return true;
				}
			}
			return false;
		}

		
	}

	public void recharge(String accountid, int num, boolean isintegeral) {
		Wallet wallet = walletMapper.selectByPrimaryKey(accountid);
		if (isintegeral) {
			int n = wallet.getIntegral();
			wallet.setIntegral(n + num);
			walletMapper.updateByPrimaryKey(wallet);
			//充值获得category为0
			addBill(accountid,num,0);
		} else {
			int n = wallet.getSincerity();
			wallet.setSincerity(n + num);
			walletMapper.updateByPrimaryKey(wallet);
		}
	}
	
	public int addBill(String accountid,int num,int category){
		Bill bill = new Bill();
		bill.setAccountId(accountid);
		bill.setCategory(category);
		bill.setIncome(num);
		bill.setDate(new Date());
		return billMapper.insert(bill);
	}

	public List<Bill> getBill(String accountid) {
		BillExample example = new BillExample();
		example.createCriteria().andAccountIdEqualTo(accountid);
		return billMapper.selectByExample(example);
	}
	
	public boolean writeAlipay(String accountid, String alipay, int count){
		//一元1000积分
		int i = WithDrawForMoney(accountid, count);
		if(i <= 0)
			return false;
		Double newCount = count/MyProp.IntegralTime;
		BufferedWriter out = null;     
		BufferedWriter out_bak = null;   
        try {     
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(location, true)));     
            out.write("账号:"+alipay + "   提现金额:" +newCount + "\r\n");
            out_bak = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(location_bak, true)));     
            out_bak.write("账号:"+alipay + "   提现金额:" +newCount + "\r\n");
        } catch (Exception e) {     
            e.printStackTrace();  
            return false;
        } finally {     
            try {     
                if(out != null){  
                    out.close();     
                } 
                if(out_bak != null){  
                	out_bak.close();     
                }  
            } catch (IOException e) {     
                e.printStackTrace();     
            }     
        } 
        return true;
	}
	
	public int WithDrawForMoney(String accountid,int count){
		Wallet wallet = walletMapper.selectByPrimaryKey(accountid);
		wallet.setIntegral(wallet.getIntegral()- count);
		return walletMapper.updateByPrimaryKey(wallet);
	}
	
	public boolean reduceChat(String accountid,int num){
		Wallet wallet = walletMapper.selectByPrimaryKey(accountid);
		int oldNum = wallet.getIntegral();
		if(num > oldNum)
			return false;
		wallet.setIntegral(oldNum-num);
		walletMapper.updateByPrimaryKey(wallet);
		return true;
	}
	
	public int payForAlbum(String accountid,String friendid,int num){
		Wallet wallet = walletMapper.selectByPrimaryKey(accountid);
		if(wallet.getIntegral() < num)
			return 0;
		Wallet friendidWallet = walletMapper.selectByPrimaryKey(friendid);
		wallet.setIntegral(wallet.getIntegral()- num);
		friendidWallet.setIntegral(friendidWallet.getIntegral()+ num);
		return walletMapper.updateByPrimaryKey(wallet) & walletMapper.updateByPrimaryKey(friendidWallet);
	}
}
