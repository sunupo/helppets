package cn.tt.utils;

public class Constants {
	public static final int DYNAMIC_TYPE_PICTURE = 1;
	public static final int DYNAMIC_TYPE_VOICE = 2;
	public static final int DYNAMIC_TYPE_VIDEO = 3;
}
