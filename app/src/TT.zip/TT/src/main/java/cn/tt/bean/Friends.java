package cn.tt.bean;

public class Friends extends FriendsKey {

	private Integer frienditem;

    private Integer type;

    public Integer getFrienditem() {
        return frienditem;
    }

    public void setFrienditem(Integer frienditem) {
        this.frienditem = frienditem;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
    @Override
	public String toString() {
		return "Friends [frienditem=" + frienditem + ", type=" + type + "]";
	}
   
}