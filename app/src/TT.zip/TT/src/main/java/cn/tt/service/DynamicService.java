package cn.tt.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Comment;
import cn.tt.bean.Dynamic;
import cn.tt.bean.User_info;
import cn.tt.bean.Voicedy;
import cn.tt.bean.view.CommentVO;
import cn.tt.bean.view.DynamicVO;
import cn.tt.dao.CommentMapper;
import cn.tt.dao.DynamicMapper;

@Service
public class DynamicService {

	@Autowired
	private UserService userService;
	@Autowired
	private DynamicMapper dynamicMapper;
	@Autowired
	private CommentMapper commentMapper;

	public Dynamic getDynamic(String dynamicId) {
		return dynamicMapper.selectByPrimaryKey(dynamicId);

	}
	
	/**
	 * ��ȡָ���û������ж�̬
	 * @param accountID
	 * @return
	 */
	public List<Dynamic> getAllDynamicByID(String accountID) {
		return dynamicMapper.selectDynamicbyUserId(accountID);
	}
	

	public List<Dynamic> getAllDynamic() {
		return dynamicMapper.selectDynamic();

	}

	public List<Comment> getAllComment() {
		return commentMapper.selectAllComment();
	}
	
	/**
	 *����û���id��ȡ���û������ж�̬���
	 * Ҫ�õ��ľ�����ݷ�װ��DynamicVO����*/
	public List<DynamicVO> getAllDyVOByUserID(String accountId) {
		List<DynamicVO> dybamicVOList = new ArrayList<DynamicVO>();
		List<Dynamic> dynamics = dynamicMapper.selectDynamicbyUserId(accountId);

		for (int i = 0; i < dynamics.size(); i++) {
			Dynamic dynamic = dynamics.get(i);
			DynamicVO temp = new DynamicVO();
			temp.setdId(dynamic.getdId());
			temp.setAccountId(dynamic.getAccountId());
			temp.setdCategory(dynamic.getdCategory());
			temp.setdReleasetime(dynamic.getdReleasetime());
			temp.setSupport(dynamic.getSupport());
			temp.setUnlike(dynamic.getUnlike());
			temp.setGift(dynamic.getGift());
			temp.setComment(dynamic.getComment());
			temp.setShare(dynamic.getShare());
			temp.setDyima(dynamic.getDyima());
			temp.setdContent(dynamic.getdContent());
			//����̬���û���ͷ�������
			temp.setName(dynamic.getUser_info().getName());
			temp.setProfile(dynamic.getUser_info().getProfile());

			List<CommentVO> commentVO = new ArrayList<CommentVO>();
			List<Comment> comments = dynamic.getCommentList();

			for (int j = 0; j < comments.size(); j++) {
				CommentVO commentTemp = new CommentVO();
				Comment comment = comments.get(j);
				commentTemp.setCommentAccount(comment.getCommentAccount());
				/**
				 * ���˶�̬û�����ۣ����ò��������û���ID��if else�����ָ���쳣
				 */
				if (comment.getCommentAccount() != null) {
					User_info user_info = userService.getUserInfo(comment.getCommentAccount());
					commentTemp.setCommentUserName(user_info.getName());//�����۵��û�������
				} else {
					commentTemp.setCommentUserName(null);
				}
				commentTemp.setContent(comment.getContent());
				commentVO.add(commentTemp);
			}
			temp.setCommentList(commentVO);
			dybamicVOList.add(temp);
		}
		return dybamicVOList;
	}
	

	/**
	 * �㳡�е�ͼ����ݣ�ֻ��Ҫչʾ����ݣ����˷���̬���û���ID��
	 * Ҫ�õ��ľ�����ݷ�װ��DynamicVO����*/
	public List<DynamicVO> getAllDynamicVO() {
		List<DynamicVO> dybamicVOList = new ArrayList<DynamicVO>();
		List<Dynamic> dynamics = dynamicMapper.selectDynamic();

		for (int i = 0; i < dynamics.size(); i++) {
			Dynamic dynamic = dynamics.get(i);
			DynamicVO temp = new DynamicVO();
			temp.setdId(dynamic.getdId());
			temp.setAccountId(dynamic.getAccountId());
			temp.setdCategory(dynamic.getdCategory());
			temp.setdReleasetime(dynamic.getdReleasetime());
			temp.setSupport(dynamic.getSupport());
			temp.setUnlike(dynamic.getUnlike());
			temp.setGift(dynamic.getGift());
			temp.setComment(dynamic.getComment());
			temp.setShare(dynamic.getShare());
			temp.setDyima(dynamic.getDyima());
			temp.setdContent(dynamic.getdContent());
			//����̬���û���ͷ�������
			temp.setName(dynamic.getUser_info().getName());
			temp.setProfile(dynamic.getUser_info().getProfile());

			List<CommentVO> commentVO = new ArrayList<CommentVO>();
			List<Comment> comments = dynamic.getCommentList();

			for (int j = 0; j < comments.size(); j++) {
				CommentVO commentTemp = new CommentVO();
				Comment comment = comments.get(j);
				commentTemp.setCommentAccount(comment.getCommentAccount());
				/**
				 * ���˶�̬û�����ۣ����ò��������û���ID��if else�����ָ���쳣
				 */
				if (comment.getCommentAccount() != null) {
					User_info user_info = userService.getUserInfo(comment.getCommentAccount());
					commentTemp.setCommentUserName(user_info.getName());//�����۵��û�������
				} else {
					commentTemp.setCommentUserName(null);
				}
				commentTemp.setContent(comment.getContent());
				commentVO.add(commentTemp);
			}
			temp.setCommentList(commentVO);
			dybamicVOList.add(temp);
		}
		return dybamicVOList;
	}
	
	/**
	 * ����һ����̬
	 * @param record
	 * @return
	 */
	public int insertOneDynamic(Dynamic record){
		if (record == null || record.getAccountId() == null || record.getdContent() == null ) {
			return -1;
		}
		if (record.getAccountId().equals("null")) {
			return -1;
		}
		String id = UUID.randomUUID().toString().substring(0, 13);
		record.setdId(id);
		record.setdCategory(1);
		//TODO �������޸���ݿ�����Ĭ��ֵΪ0
		record.setComment(0);
		record.setGift(0);
		record.setShare(0);
		record.setSupport(0);
		record.setUnlike(0);
		
		return dynamicMapper.insert(record);
	}
	/**
	 * ����һ������
	 * @param comment
	 * @return
	 */
	public int  insertOneComment(Comment comment) {
		if (comment == null || comment.getContent() == null ||comment.getDynaimcId() == null
				||comment.getCommentAccount() == null) {
			return -1;
		}
		if (comment.getContent().equals("") ||comment.getDynaimcId().equals(null)
				||comment.getCommentAccount().equals(null)) {
			return -1;
		}
		String id = UUID.randomUUID().toString().substring(0, 13);
		comment.setId(id);
		comment.setSupport(0);
		comment.setUnlike(0);
		return commentMapper.insert(comment);
	}
	
	/**
	 * Support/Unlike/Comment/Gift/Share/
	 * �⼸�������ļ�һ,��������
	 * @param dynamic
	 * @return
	 */
	public int updateCount(Dynamic dynamic) {
		if (dynamic == null) {
			return -1;
		}
		if (dynamic.getdId().equals("null")) {
			return -1;
		}
		return dynamicMapper.updateByPrimaryKeySelective(dynamic);
	}
	
	public Integer getDynamicNumByUser(String accountid){
		if ( accountid == null )
			return -1;
		else
			return dynamicMapper.selectDynamicNumByUser(accountid);
	}

}
