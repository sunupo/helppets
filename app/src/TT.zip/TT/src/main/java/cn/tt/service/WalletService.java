package cn.tt.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Wallet;
import cn.tt.dao.WalletMapper;
import cn.tt.utils.MyProp;
@Service
public class WalletService {
	@Autowired
	private WalletMapper walletMapper;
	
	@Autowired
	private PocketService pocketService;
	
	public void updateReadPacket(String accoundId, int nums, boolean isSincerity){
		Wallet wallet = walletMapper.selectByPrimaryKey(accoundId);
		if(wallet != null){
			if(isSincerity){
				wallet.setSincerity(wallet.getSincerity()+nums);
				walletMapper.updateByPrimaryKey(wallet);
				
			}else{
				wallet.setIntegral(wallet.getIntegral()+nums);
				wallet.setChatcount(wallet.getChatcount()+nums);
				walletMapper.updateByPrimaryKey(wallet);
				//红包获得category为2 发送为4
				if(nums > 0)
					pocketService.addBill(accoundId,nums,2);
				else
					pocketService.addBill(accoundId,nums,4);
			}
		}
		
		
	}
	
	public boolean integralEnough(String accountid,String friendid,int num){
		Wallet wallet = walletMapper.selectByPrimaryKey(accountid);
		if(wallet.getSincerity() > num){
			wallet.setSincerity(wallet.getSincerity()-num);
			walletMapper.updateByPrimaryKey(wallet);
			Wallet friend = walletMapper.selectByPrimaryKey(friendid);
			friend.setSincerity(friend.getSincerity()+num);
			walletMapper.updateByPrimaryKey(friend);
			return true;
		}else{
			return false;
		}
			
	}
	
	
}	
