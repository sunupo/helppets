package cn.tt.dao;

import cn.tt.bean.Dynamic;
import cn.tt.bean.DynamicExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DynamicMapper {
    long countByExample(DynamicExample example);

    int deleteByExample(DynamicExample example);

    int deleteByPrimaryKey(String dId);

    int insert(Dynamic record);

    int insertSelective(Dynamic record);

    List<Dynamic> selectByExampleWithBLOBs(DynamicExample example);

    List<Dynamic> selectByExample(DynamicExample example);

    Dynamic selectByPrimaryKey(String dId);
    
    List<Dynamic> selectDynamic();
    
    List<Dynamic> selectDynamicbyUserId(String dId);

    int updateByExampleSelective(@Param("record") Dynamic record, @Param("example") DynamicExample example);

    int updateByExampleWithBLOBs(@Param("record") Dynamic record, @Param("example") DynamicExample example);

    int updateByExample(@Param("record") Dynamic record, @Param("example") DynamicExample example);

    int updateByPrimaryKeySelective(Dynamic record);

    int updateByPrimaryKeyWithBLOBs(Dynamic record);

    int updateByPrimaryKey(Dynamic record);
    
    int selectDynamicNumByUser(@Param("accountId")String accountId);

}