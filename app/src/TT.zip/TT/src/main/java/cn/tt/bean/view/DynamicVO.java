package cn.tt.bean.view;

import java.util.List;

import cn.tt.bean.Comment;
import cn.tt.bean.User_info;

public class DynamicVO {
	private String dId;// ��̬��id
	private String accountId;

	private Integer dCategory;

	private String dReleasetime;

	private Integer support;

	private Integer unlike;

	private Integer gift;

	private Integer comment;

	private Integer share;

	private String dyima;

	private String dContent;

	private String name;
	private String profile;

	private List<CommentVO> commentList;
	
	public String getdId() {
		return dId;
	}

	public void setdId(String dId) {
		this.dId = dId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Integer getdCategory() {
		return dCategory;
	}

	public void setdCategory(Integer dCategory) {
		this.dCategory = dCategory;
	}

	public String getdReleasetime() {
		return dReleasetime;
	}

	public void setdReleasetime(String dReleasetime) {
		this.dReleasetime = dReleasetime;
	}

	public Integer getSupport() {
		return support;
	}

	public void setSupport(Integer support) {
		this.support = support;
	}

	public Integer getUnlike() {
		return unlike;
	}

	public void setUnlike(Integer unlike) {
		this.unlike = unlike;
	}

	public Integer getGift() {
		return gift;
	}

	public void setGift(Integer gift) {
		this.gift = gift;
	}

	public Integer getComment() {
		return comment;
	}

	public void setComment(Integer comment) {
		this.comment = comment;
	}

	public Integer getShare() {
		return share;
	}

	public void setShare(Integer share) {
		this.share = share;
	}

	public String getDyima() {
		return dyima;
	}

	public void setDyima(String dyima) {
		this.dyima = dyima;
	}

	public String getdContent() {
		return dContent;
	}

	public void setdContent(String dContent) {
		this.dContent = dContent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public List<CommentVO> getCommentList() {
		return commentList;
	}

	public void setCommentList(List<CommentVO> commentList) {
		this.commentList = commentList;
	}

}
