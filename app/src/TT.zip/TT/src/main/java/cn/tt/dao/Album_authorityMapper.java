package cn.tt.dao;

import cn.tt.bean.Album_authority;
import cn.tt.bean.Album_authorityExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface Album_authorityMapper {
    long countByExample(Album_authorityExample example);

    int deleteByExample(Album_authorityExample example);

    int deleteByPrimaryKey(String accountId);

    int insert(Album_authority record);

    int insertSelective(Album_authority record);

    List<Album_authority> selectByExample(Album_authorityExample example);

    Album_authority selectByPrimaryKey(String accountId);

    int updateByExampleSelective(@Param("record") Album_authority record, @Param("example") Album_authorityExample example);

    int updateByExample(@Param("record") Album_authority record, @Param("example") Album_authorityExample example);

    int updateByPrimaryKeySelective(Album_authority record);

    int updateByPrimaryKey(Album_authority record);
}