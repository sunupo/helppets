package cn.tt.utils;

import java.util.Date;

public class MyDateWrapper {
	private Integer dId;

    private String inviteId;

    private String receiveId;

    private int integral;
    
    private int sincirity;
    
    private String theme;

    private Date datefortime;

    private String location;

    private String name;

    private String profile;
    
    private String maintext;
    
    private String mainpicture;

	public Integer getdId() {
		return dId;
	}

	public void setdId(Integer dId) {
		this.dId = dId;
	}

	public String getInviteId() {
		return inviteId;
	}

	public void setInviteId(String inviteId) {
		this.inviteId = inviteId;
	}

	public String getReceiveId() {
		return receiveId;
	}

	public void setReceiveId(String receiveId) {
		this.receiveId = receiveId;
	}

	public int getIntegral() {
		return integral;
	}

	public void setIntegral(int integral) {
		this.integral = integral;
	}

	public int getSincirity() {
		return sincirity;
	}

	public void setSincirity(int sincirity) {
		this.sincirity = sincirity;
	}

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public Date getDatefortime() {
		return datefortime;
	}

	public void setDatefortime(Date datefortime) {
		this.datefortime = datefortime;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getMaintext() {
		return maintext;
	}

	public void setMaintext(String maintext) {
		this.maintext = maintext;
	}

	public String getMainpicture() {
		return mainpicture;
	}

	public void setMainpicture(String mainpicture) {
		this.mainpicture = mainpicture;
	}
    
    
}
