package cn.tt.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.tt.bean.Album;
import cn.tt.bean.Msg;
import cn.tt.bean.view.PersonalAlbum;
import cn.tt.service.AlbumService;

@Controller
@RequestMapping("/album")
public class AlbumController {
	@Autowired
	private AlbumService albumService;

	@ResponseBody
	@RequestMapping("/addAlbum")
	public Msg addAlbum(Album album) {
		//如果是一个付费相册，price字段不能为空.
		if ( album.getLevel() == 3 && album.getPrice() == null ){
			return Msg.fail().add("error", "付费相册需要设定price参数");
		}
		int res = albumService.addAlbum(album);
		if (res == 1)
			return Msg.success();
		else {
			return Msg.fail();
		}
	}
	
	@ResponseBody
	@RequestMapping("/getAlbum/{albumid}")
	public Msg getAlbumVoice(@PathVariable("albumid") String albumid) {
		Album album = albumService.getAlbum(albumid);
		if (album != null)
			return Msg.success().add("album", album);
		else {
			return Msg.fail();
		}
	}
	
	@ResponseBody
	@RequestMapping("/getAlbumsByUser/{accountId}")
	public Msg getAlbumsByUser(@PathVariable("accountId") String accountId) {
		List<Album> albums = albumService.getAlbumsByUser(accountId);
		if ( albums != null)
			return Msg.success().add("albums", albums);
		else {
			return Msg.fail();
		}
	}
	
	/**
	 * @param wathcer the accountid of watcher
	 * @param wathced the accountid of watched
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getPersonalAlbums")
	public Msg getPersonalImgs(@RequestParam("watcher") String watcher, @RequestParam("watched") String watched) {
		PersonalAlbum personal = albumService.getPersonalAlbum(watcher, watched);
		if ( personal != null ){
			return Msg.success().add("personal", personal);
		}
		else{
			return Msg.fail();
		}
	}

}
