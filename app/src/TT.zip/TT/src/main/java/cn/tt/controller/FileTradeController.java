package cn.tt.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.tt.bean.FileTrade;
import cn.tt.bean.Msg;
import cn.tt.service.AlbumService;
import cn.tt.service.FileTradeService;
import cn.tt.service.PocketService;

@Controller
@RequestMapping("/filetrade")
public class FileTradeController {
	@Autowired
	private FileTradeService tradeService;
	@Autowired
	private AlbumService albumService; 
	@Autowired
	private PocketService pocketService; 
	
	/**
	 * @param trade
	 *  必须包含的参数包含：
	 *   accountid： 付款方
	 *   acceptside： 收款方
	 *   fileid: 文件id，可以是相册ID，也可以是声音ID，以及视频ID。具体分类由file_type字段决定
	 *   fileType: 相册：0，声音文件：1，视频文件：2，其它文件：3
	 *   charge: 付了多少钱
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/addFileTrade")
	public Msg addTrade(FileTrade trade) {
		if( trade.getAccountid() == null || trade.getAcceptside() == null || trade.getFileid() == null || trade.getFileType() == null )
			return Msg.fail().add("error", "accountid, acceptside, fileid or fileType cannot be null");
		trade.setStartTime(String.valueOf(System.nanoTime()));
		if ( tradeService.getTrade(trade.getAccountid(), trade.getAcceptside(), trade.getFileid()) != null )
			return Msg.fail().add("error", "you have been paied");
		trade.setEndTime(String.valueOf(System.nanoTime()));
		int res = tradeService.addTrade(trade);
		if (res == 1)
			return Msg.success();
		else {
			return Msg.fail();
		}
	}
	
	/**
	 * 
	 * @param trade
	 *  添加一个对相册的交易
	 *  必须包含的参数包含：
	 *   accountid： 付款方
	 *   acceptside： 收款方
	 *   fileid: 相册ID
	 *   charge: 付了多少钱
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/addAlbumTrade")
	public Msg addAlbumTrade(FileTrade trade) {
		if( trade.getAccountid() == null || trade.getAcceptside() == null || trade.getFileid() == null )
			return Msg.fail().add("msg", "accountid, acceptside, fileid or cannot be null");
		trade.setStartTime(String.valueOf(System.nanoTime()));
		if ( tradeService.getTrade(trade.getAccountid(), trade.getAcceptside(), trade.getFileid()) != null )
			return Msg.fail().add("msg", "you have been paied");
		trade.setEndTime(String.valueOf(System.nanoTime()));
		// it means a album
		trade.setFileType(0);
		int res = tradeService.addTrade(trade);
		if (res == 1){
			res = pocketService.payForAlbum(trade.getAccountid(), trade.getAcceptside(), trade.getCharge().intValue());
			if ( res == 1 )
				return Msg.success();
			else
				return Msg.fail().add("msg", "add pocket failed");
		}
		else {
			return Msg.fail().add("msg", "add file trade failed");
		}
		
	}
	
	/**
	 * 
	 * @param trade
	 *  添加一个对声音的交易
	 *  必须包含的参数包含：
	 *   accountid： 付款方
	 *   acceptside： 收款方
	 *   fileid: 声音ID
	 *   charge: 付了多少钱
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/addVoiceTrade")
	public Msg addVoiceTrade(FileTrade trade) {
		trade.setFileType(1);
		return addTrade(trade);
	}
	
	@ResponseBody
	@RequestMapping("/getTrade/{tradeid}")
	public Msg getTrade(@PathVariable("tradeid") String tradeid) {
		FileTrade trade = tradeService.getTrade(tradeid);
		if (trade!= null)
			return Msg.success().add("trade", trade);
		else {
			return Msg.fail();
		}
	}
	
	/**
	 * http://localhost:8080/TT/filetrade/getUniqueTrade?accountid=00000003&fileid=2
	 * @param accountid
	 * @param fileid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getUniqueTrade")
	public Msg getUniqueTrade(@RequestParam("accountid") String accountid,@RequestParam("acceptside") String acceptside, @RequestParam("fileid") String fileid) {
		FileTrade trade = tradeService.getTrade(accountid, acceptside, fileid);
		if ( trade!= null)
			return Msg.success().add("trade", trade);
		else {
			return Msg.fail();
		}
	}
	
	@ResponseBody
	@RequestMapping("/isChargeAlbumTraded")
	public Msg isChargeAlbumTraded(@RequestParam("accountid") String accountid,@RequestParam("acceptside") String acceptside, @RequestParam("albumid") String albumid) {
		boolean res = tradeService.isChargeAlbumTraded(accountid, acceptside, albumid);
		return Msg.success().add("res", res);
	}

}
