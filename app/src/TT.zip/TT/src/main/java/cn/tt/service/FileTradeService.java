package cn.tt.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.print.attribute.standard.RequestingUserName;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Album;
import cn.tt.bean.Comment;
import cn.tt.bean.Dynamic;
import cn.tt.bean.FileTrade;
import cn.tt.bean.User_info;
import cn.tt.bean.Voicedy;
import cn.tt.bean.view.CommentVO;
import cn.tt.bean.view.DynamicVO;
import cn.tt.dao.AlbumMapper;
import cn.tt.dao.CommentMapper;
import cn.tt.dao.DynamicMapper;
import cn.tt.dao.FileTradeMapper;

@Service
public class FileTradeService {

	@Autowired
	private FileTradeMapper tradeMapper;
	
	public int addTrade(FileTrade record){
		if ( record.getTradeid() == null ){
			String id = UUID.randomUUID().toString();
			record.setTradeid(id);
		}
		record.setStatus(1);
		return tradeMapper.insert(record);
	}
	
	/**
	 * get a trade with accountid and fileid
	 * @param accountid
	 * @param fileid
	 * @return
	 */
	public FileTrade getTrade(String accountid, String acceptside,String fileid) {
		FileTrade trade = new FileTrade();
		trade.setAccountid(accountid);
		trade.setAcceptside(acceptside);
		trade.setFileid(fileid);
		return tradeMapper.selectUniqueTrade(trade);
	}
	
	public FileTrade getTrade(String tradeid) {
		return tradeMapper.selectByPrimaryKey(tradeid);
	}
	
	
	/**
	 * 查看的相册是否已经交费，已经交费则返回true, 否则返回false
	 * @param accountid
	 * @param acceptside
	 * @param albumid
	 * @return
	 */
	public boolean isChargeAlbumTraded(String accountid, String acceptside, String albumid){
		FileTrade trade = new FileTrade();
		trade.setAccountid(accountid);
		trade.setAcceptside(acceptside);
		trade.setFileid(albumid);
		FileTrade res = tradeMapper.selectUniqueTrade(trade);
		if ( res!= null )
			return true;
		else
			return false;
	}

}
