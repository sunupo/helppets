package cn.tt.bean;

public class Gift {
    private Integer gId;

    private Integer gCategory;

    private String gName;

    private String pictureurl;

    private Integer integral;

    private Integer sincererity;

    public Integer getgId() {
        return gId;
    }

    public void setgId(Integer gId) {
        this.gId = gId;
    }

    public Integer getgCategory() {
        return gCategory;
    }

    public void setgCategory(Integer gCategory) {
        this.gCategory = gCategory;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName == null ? null : gName.trim();
    }

    public String getPictureurl() {
        return pictureurl;
    }

    public void setPictureurl(String pictureurl) {
        this.pictureurl = pictureurl == null ? null : pictureurl.trim();
    }

    public Integer getIntegral() {
        return integral;
    }

    public void setIntegral(Integer integral) {
        this.integral = integral;
    }

    public Integer getSincererity() {
        return sincererity;
    }

    public void setSincererity(Integer sincererity) {
        this.sincererity = sincererity;
    }
}