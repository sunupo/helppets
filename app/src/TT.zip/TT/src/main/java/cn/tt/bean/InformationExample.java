package cn.tt.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InformationExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public InformationExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andActoridIsNull() {
            addCriterion("actorid is null");
            return (Criteria) this;
        }

        public Criteria andActoridIsNotNull() {
            addCriterion("actorid is not null");
            return (Criteria) this;
        }

        public Criteria andActoridEqualTo(String value) {
            addCriterion("actorid =", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridNotEqualTo(String value) {
            addCriterion("actorid <>", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridGreaterThan(String value) {
            addCriterion("actorid >", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridGreaterThanOrEqualTo(String value) {
            addCriterion("actorid >=", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridLessThan(String value) {
            addCriterion("actorid <", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridLessThanOrEqualTo(String value) {
            addCriterion("actorid <=", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridLike(String value) {
            addCriterion("actorid like", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridNotLike(String value) {
            addCriterion("actorid not like", value, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridIn(List<String> values) {
            addCriterion("actorid in", values, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridNotIn(List<String> values) {
            addCriterion("actorid not in", values, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridBetween(String value1, String value2) {
            addCriterion("actorid between", value1, value2, "actorid");
            return (Criteria) this;
        }

        public Criteria andActoridNotBetween(String value1, String value2) {
            addCriterion("actorid not between", value1, value2, "actorid");
            return (Criteria) this;
        }

        public Criteria andToidIsNull() {
            addCriterion("toid is null");
            return (Criteria) this;
        }

        public Criteria andToidIsNotNull() {
            addCriterion("toid is not null");
            return (Criteria) this;
        }

        public Criteria andToidEqualTo(String value) {
            addCriterion("toid =", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidNotEqualTo(String value) {
            addCriterion("toid <>", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidGreaterThan(String value) {
            addCriterion("toid >", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidGreaterThanOrEqualTo(String value) {
            addCriterion("toid >=", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidLessThan(String value) {
            addCriterion("toid <", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidLessThanOrEqualTo(String value) {
            addCriterion("toid <=", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidLike(String value) {
            addCriterion("toid like", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidNotLike(String value) {
            addCriterion("toid not like", value, "toid");
            return (Criteria) this;
        }

        public Criteria andToidIn(List<String> values) {
            addCriterion("toid in", values, "toid");
            return (Criteria) this;
        }

        public Criteria andToidNotIn(List<String> values) {
            addCriterion("toid not in", values, "toid");
            return (Criteria) this;
        }

        public Criteria andToidBetween(String value1, String value2) {
            addCriterion("toid between", value1, value2, "toid");
            return (Criteria) this;
        }

        public Criteria andToidNotBetween(String value1, String value2) {
            addCriterion("toid not between", value1, value2, "toid");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(Integer value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(Integer value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(Integer value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(Integer value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(Integer value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<Integer> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<Integer> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(Integer value1, Integer value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andReleasedateIsNull() {
            addCriterion("releasedate is null");
            return (Criteria) this;
        }

        public Criteria andReleasedateIsNotNull() {
            addCriterion("releasedate is not null");
            return (Criteria) this;
        }

        public Criteria andReleasedateEqualTo(Date value) {
            addCriterion("releasedate =", value, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateNotEqualTo(Date value) {
            addCriterion("releasedate <>", value, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateGreaterThan(Date value) {
            addCriterion("releasedate >", value, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateGreaterThanOrEqualTo(Date value) {
            addCriterion("releasedate >=", value, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateLessThan(Date value) {
            addCriterion("releasedate <", value, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateLessThanOrEqualTo(Date value) {
            addCriterion("releasedate <=", value, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateIn(List<Date> values) {
            addCriterion("releasedate in", values, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateNotIn(List<Date> values) {
            addCriterion("releasedate not in", values, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateBetween(Date value1, Date value2) {
            addCriterion("releasedate between", value1, value2, "releasedate");
            return (Criteria) this;
        }

        public Criteria andReleasedateNotBetween(Date value1, Date value2) {
            addCriterion("releasedate not between", value1, value2, "releasedate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}