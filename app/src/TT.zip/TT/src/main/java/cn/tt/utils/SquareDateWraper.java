package cn.tt.utils;

import java.util.Date;

import cn.tt.bean.Publishdate;
import cn.tt.bean.User_info;

public class SquareDateWraper {
	private Integer dId;

    private String inviteId;

    private String receiveId;

    private int integral;
    
    private int sincirity;
    
    private String theme;

    private Date time;
    
    private Date datefortime;

    private String location;

    private Byte sex;

    private String name;

    private Integer hight;

    private Integer weight;

    private String profile;

    private Integer age;
    
    private String maintext;
    
    private String mainpicture;

	public String getMaintext() {
		return maintext;
	}

	public void setMaintext(String maintext) {
		this.maintext = maintext;
	}

	public String getMainpicture() {
		return mainpicture;
	}

	public void setMainpicture(String mainpicture) {
		this.mainpicture = mainpicture;
	}

	public Integer getdId() {
		return dId;
	}

	public void setdId(Integer dId) {
		this.dId = dId;
	}

	public String getInviteId() {
		return inviteId;
	}

	public void setInviteId(String inviteId) {
		this.inviteId = inviteId;
	}

	public String getReceiveId() {
		return receiveId;
	}

	public void setReceiveId(String receiveId) {
		this.receiveId = receiveId;
	}

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Byte getSex() {
		return sex;
	}

	public void setSex(Byte sex) {
		this.sex = sex;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getHight() {
		return hight;
	}

	public void setHight(Integer hight) {
		this.hight = hight;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Date getDatefortime() {
		return datefortime;
	}

	public void setDatefortime(Date datefortime) {
		this.datefortime = datefortime;
	}

	public int getIntegral() {
		return integral;
	}

	public void setIntegral(int integral) {
		this.integral = integral;
	}

	public int getSincirity() {
		return sincirity;
	}

	public void setSincirity(int sincirity) {
		this.sincirity = sincirity;
	}
    
	
	
}
