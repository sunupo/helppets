package cn.tt.bean;

public class User_info {
    private String accountId;

    private Byte sex;

    private String constellation;

    private String name;

    private String city;

    private Integer hight;

    private Integer weight;

    private String qq;

    private String phoneNum;

    private String likeSports;

    private String sexInfo;

    private Byte merriage;

    private Integer friendcount;

    private Integer follwcount;

    private Integer fanscount;

    private Integer giftcount;

    private String profile;

    private String token;

    private String relation;

    private Integer age;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId == null ? null : accountId.trim();
    }

    public Byte getSex() {
        return sex;
    }

    public void setSex(Byte sex) {
        this.sex = sex;
    }

    public String getConstellation() {
        return constellation;
    }

    public void setConstellation(String constellation) {
        this.constellation = constellation == null ? null : constellation.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public Integer getHight() {
        return hight;
    }

    public void setHight(Integer hight) {
        this.hight = hight;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq == null ? null : qq.trim();
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum == null ? null : phoneNum.trim();
    }

    public String getLikeSports() {
        return likeSports;
    }

    public void setLikeSports(String likeSports) {
        this.likeSports = likeSports == null ? null : likeSports.trim();
    }

    public String getSexInfo() {
        return sexInfo;
    }

    public void setSexInfo(String sexInfo) {
        this.sexInfo = sexInfo == null ? null : sexInfo.trim();
    }

    public Byte getMerriage() {
        return merriage;
    }

    public void setMerriage(Byte merriage) {
        this.merriage = merriage;
    }

    public Integer getFriendcount() {
        return friendcount;
    }

    public void setFriendcount(Integer friendcount) {
        this.friendcount = friendcount;
    }

    public Integer getFollwcount() {
        return follwcount;
    }

    public void setFollwcount(Integer follwcount) {
        this.follwcount = follwcount;
    }

    public Integer getFanscount() {
        return fanscount;
    }

    public void setFanscount(Integer fanscount) {
        this.fanscount = fanscount;
    }

    public Integer getGiftcount() {
        return giftcount;
    }

    public void setGiftcount(Integer giftcount) {
        this.giftcount = giftcount;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile == null ? null : profile.trim();
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token == null ? null : token.trim();
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation == null ? null : relation.trim();
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}