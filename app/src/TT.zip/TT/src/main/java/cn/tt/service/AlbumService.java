package cn.tt.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableLoadTimeWeaving;
import org.springframework.stereotype.Service;
import cn.tt.bean.Album;
import cn.tt.bean.FileTrade;
import cn.tt.bean.view.PersonalAlbum;
import cn.tt.dao.AlbumMapper;

@Service
public class AlbumService {

	@Autowired
	private AlbumMapper albumMapper;
	@Autowired
	private FileTradeService tradeService;
	@Autowired
	private FriendsService friendsService;
	
	public int addAlbum(Album record){
		if ( record.getAlbumid() == null ){
			String id = UUID.randomUUID().toString();
			record.setAlbumid(id);
		}
		if ( record.getLevel() == null )
			record.setLevel(0);
		if ( record.getPrice() == null )
			record.setPrice(0.0);
		if ( record.getCreateTime() == null )
			record.setCreateTime(String.valueOf(System.nanoTime()));
		return albumMapper.insert(record);
	}
	
	public Album getAlbum(String albumid) {
		return albumMapper.selectByPrimaryKey(albumid);
	}
	
	public List<Album> getFreeAlbums(String accountId){
		return albumMapper.selectFreeAlbums(accountId);
	}
	public List<Album> getVipFreeAlbums(String accountId){
		return albumMapper.selectVipFreeAlbums(accountId);
	}
	public List<Album> getChargeAlbums(String accountId){
		return albumMapper.selectChargeAlbums(accountId);
	}
	public List<Album> getAlbumsByUser(String accountId){
		return albumMapper.selectAlbumsByUser(accountId);
	}
	
	public PersonalAlbum getPersonalAlbum(String watcher, String watched){
		PersonalAlbum personalAlbum = new PersonalAlbum();
		personalAlbum.setWatcher(watcher);
		personalAlbum.setWatched(watched);
		personalAlbum.setVipFriend(friendsService.isVipFriend(watched, watcher));
		personalAlbum.setFreeAlbum(getFreeAlbums(watched));
		personalAlbum.setVipFreeAlbum(getVipFreeAlbums(watched));
		List<Album> chargeAlbum = new ArrayList<Album>();
		chargeAlbum = getChargeAlbums(watched);
		personalAlbum.setChargeAlbum(chargeAlbum);
		HashMap<String, Boolean> map = new HashMap<String, Boolean>();
		for ( Album album : chargeAlbum ){
			Boolean tradeExist = tradeService.isChargeAlbumTraded(watcher, watched, album.getAlbumid());
			map.put(album.getAlbumid(), tradeExist);
		}
		personalAlbum.setCharged(map);
		return personalAlbum;
	}
	
}
