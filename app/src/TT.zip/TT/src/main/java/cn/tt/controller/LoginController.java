package cn.tt.controller;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Account;
import cn.tt.bean.Msg;
import cn.tt.bean.User_info;
import cn.tt.service.LoginService;
import cn.tt.service.UserService;
/*
 * 登录controller
 * APP的LoginActivity通过RequestBody中包含了用户名和密码的json数据userbame、password
 * LoginController接收到了数据，判断用户名密码是否匹配：
 * 否：返回一个json数据，包括MSG对象的code=200，message=fail
 * 是，返回一个json数据，包括code=100，message=success，并且往MSG对象的data（是一个hashmap，key/value）属性中以key/value的形式添加数据
 * 最后返回的json数据在APP通过创建一个JSONObject对象，JSONObject jSONObject = new JSONObject(responseData);
 * 在APP中code用jSONObject。getInt("code")获取，data中的value数据用jSONObject。getJSONObject("data").getString("data中的key")获取
 */
@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	@Autowired
	private UserService userService;
	
	//验证用户账号密码是否正确，若正确返回用户一些信息
	@RequestMapping("/identify")
	@ResponseBody
	public Msg identify(@RequestParam("username") String username,
			@RequestParam("password") String password){
		Account account = loginService.getAccount(username, password);
		if(account == null)
			return Msg.fail();
		else{
			String id = account.getAccountid();
			User_info userinfo = userService.getUserInfo(id);
			return Msg.success().add("accountid", id).add("sex", userinfo.getSex()==1?"男":"女")
					.add("name", userinfo.getName()).add("picurl", userinfo.getProfile());
		}
			
	}
	
	//注册时验证账号是否存在
	@RequestMapping("/regtest/{username}")
	@ResponseBody
	public Msg regtest(@PathVariable("username") String username){
		Account account = loginService.getAccount(username);
		if(account == null)
			return Msg.success();
		else
			return Msg.fail();
	}
	
	//注册用户
	@RequestMapping("/regiser")
	@ResponseBody
	public Msg regiser(@RequestParam("username") String username,
			@RequestParam("password") String password,
			@RequestParam("sex") String sex,
			@RequestParam("nickname") String nickname,
			@RequestParam("age") String age,
			@RequestParam("relation") String relation){
		User_info user = loginService.register(username,password,sex,nickname,age,relation);
		if(user == null)
			return Msg.fail();
		else
			return Msg.success().add("accountid", user.getAccountId()).add("sex", sex)
					.add("picUrl", user.getProfile());
	}
	
	
}
