package cn.tt.utils;

import cn.tt.bean.Information;
import cn.tt.bean.User_info;

public class InformationWrapper {
	private User_info user_info;
	private Information information;
	public User_info getUser_info() {
		return user_info;
	}
	public void setUser_info(User_info user_info) {
		this.user_info = user_info;
	}
	public Information getInformation() {
		return information;
	}
	public void setInformation(Information information) {
		this.information = information;
	}
	
}
