package cn.tt.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Dynamic;
import cn.tt.bean.DynamicState;
import cn.tt.bean.Msg;
import cn.tt.bean.Voicedy;
import cn.tt.service.DynamicService;
import cn.tt.service.DynamicStateService;
import cn.tt.service.VoiceService;
import cn.tt.utils.Constants;

@Controller
@RequestMapping("/dynamic")
public class DynamicStateController {
	@Autowired
	private DynamicService dynamicService;
	@Autowired
	private DynamicStateService stateService;
	@Autowired
	private VoiceService voiceService;

	@ResponseBody
	@RequestMapping("/addDynamicState")
	public Msg addDynamicState(DynamicState state) {
		if (state == null || state.getAccountid() == null || state.getDynamicid() == null
				|| state.getDynamicType() == null)
			return Msg.fail().add("msg", "parameter is null");
		if (state.getUnlike() == null && state.getSupport() == null)
			return Msg.fail().add("msg", "parameter is null");
		if (state.getUnlike() != null && state.getSupport() != null)
			return Msg.fail().add("msg", "only set one parameter between unlike and support");
		state.setStateid(UUID.randomUUID().toString());
		Msg msg = stateService.addDynamicState(state);
		if (msg.getCode() == 200) // 添加失败了
			return msg;
		else { // if successs, update dynamic
			boolean res = false;
			if (state.getDynamicType() == Constants.DYNAMIC_TYPE_PICTURE) {
				Dynamic dynamic = dynamicService.getDynamic(state.getDynamicid());
				if (dynamic != null) {
					if (state.getSupport() != null) {
						dynamic.setSupport(dynamic.getSupport() + 1);
					} else if (state.getUnlike() != null) {
						dynamic.setUnlike(dynamic.getUnlike() + 1);
					}
					if (dynamicService.updateCount(dynamic) > 0)
						res = true;
				}

			} else if (state.getDynamicType() == Constants.DYNAMIC_TYPE_VOICE) {
				Voicedy voicedy = voiceService.getVoicedyById(state.getDynamicid());
				if (voicedy != null) {
					if (state.getSupport() != null) {
						voicedy.setSupport(voicedy.getSupport() + 1);
					} else if (state.getUnlike() != null) {
						voicedy.setUnlike(voicedy.getUnlike() + 1);
					}
					if (voiceService.updateCount(voicedy) > 0)
						res = true;
				}
			}
			/*
			 * else if ( state.getDynamicType() == Constants.DYNAMIC_TYPE_VIDEO
			 * ){ if ( state.getSupport() != null ){
			 * 
			 * } else if ( state.getUnlike() != null ){
			 * 
			 * } }
			 */
			if (res == true)
				return Msg.success();
			else
				return Msg.fail().add("msg", "failed to update dynamic");
		}
	}
}
