package cn.tt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Msg;
import cn.tt.bean.User_info;
import cn.tt.service.UserService;

@Controller
@RequestMapping("/fxs")
public class TestController {
	@Autowired
	private UserService userService;

	@ResponseBody
	@RequestMapping("/fxs")
	public Msg getUserInfo() {
		User_info userinfo = userService.getUserInfo("00000001");
		if (userinfo != null)
			return Msg.success().add("userinfo", userinfo);
		else {
			return Msg.fail();
		}
	}
}
