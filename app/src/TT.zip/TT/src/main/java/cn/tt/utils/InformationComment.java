package cn.tt.utils;

import cn.tt.bean.Comment;
import cn.tt.bean.Dynamic;
import cn.tt.bean.User_info;

public class InformationComment {
	private Comment comment;
	private Dynamic dynamic;
	private User_info userinfo;
	public Comment getComment() {
		return comment;
	}
	public void setComment(Comment comment) {
		this.comment = comment;
	}
	public Dynamic getDynamic() {
		return dynamic;
	}
	public void setDynamic(Dynamic dynamic) {
		this.dynamic = dynamic;
	}
	public User_info getUserinfo() {
		return userinfo;
	}
	public void setUserinfo(User_info userinfo) {
		this.userinfo = userinfo;
	}
	
	
}
