package cn.tt.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import cn.tt.bean.Friends;
import cn.tt.bean.Gift;
import cn.tt.bean.Msg;
import cn.tt.bean.Publishdate;
import cn.tt.bean.User_gift;
import cn.tt.bean.User_info;
import cn.tt.dao.User_giftMapper;
import cn.tt.service.DynamicService;
import cn.tt.service.FriendsService;
import cn.tt.service.SquareDateService;
import cn.tt.service.UserService;
import cn.tt.service.User_giftService;
import cn.tt.utils.BaseUtil;
import cn.tt.utils.GiftHolder;
import cn.tt.utils.MyProp;
import cn.tt.utils.SquareDateWraper;
/*
 * 我的页面controller
 */
@Controller
@RequestMapping("/mine")
public class MineController {
	private String getTokenUrl = "http://api.cn.ronghub.com/user/getToken.json";
	@Autowired
	private UserService userService;

	@Autowired
	private FriendsService friendsService;

	@Autowired
	private User_giftService user_giftService;
	
	@Autowired
	private SquareDateService squareDateService;
	
	@Autowired
	private DynamicService dynamicService;
	

	private String baseUserPictureUrl = MyProp.baseUserPictureUrl;

	//得到用户信息
	@ResponseBody
	@RequestMapping("/home/{accountid}")
	public Msg getUserInfo(@PathVariable("accountid") String accountid) {
		User_info userinfo = userService.getUserInfo(accountid);
		if (userinfo != null){
			long friendcount = friendsService.getFriendsCount(accountid);
			long follwcount = friendsService.getFollowCount(accountid);
			long fanscount = friendsService.getFansCount(accountid);
			long giftcount = user_giftService.getGiftCount(accountid);
			return Msg.success().add("userinfo", userinfo).add("friendcount", friendcount)
					.add("follwcount", follwcount).add("fanscount", fanscount).add("giftcount", giftcount);
		}
			
		else {
			return Msg.fail();
		}
	}
	
	//更新用户信息
	@ResponseBody
	@RequestMapping("/updateuserinfo/{accountid}")
	public Msg updateUserInfo(@PathVariable("accountid") String accountid,
			@RequestParam("name") String name,
			@RequestParam("city") String city,
			@RequestParam("height") String  height,
			@RequestParam("weight") String weight,
			@RequestParam("age") String age,
			@RequestParam("relation") String relation) {
		Boolean b = userService.updateUser(accountid, name, city, height, weight, age, relation);
		if (b){
			return Msg.success();
		}else {
			return Msg.fail();
		}
	}

	//得到好友信息以及用户是否已经关注好友
	@ResponseBody
	@RequestMapping("/home/friend/{accountid}/{friendid}")
	public Msg getFriendInfo(@PathVariable("accountid") String accountid,
			@PathVariable("friendid") String friendid) {
		User_info userinfo = userService.getUserInfo(friendid);
		if (userinfo != null){
			long friendcount = friendsService.getFriendsCount(friendid);
			long follwcount = friendsService.getFollowCount(friendid);
			long fanscount = friendsService.getFansCount(friendid);
			//long giftcount = user_giftService.getGiftCount(friendid);
			long hasfollow = friendsService.hasFollow(accountid, friendid);
			int dynamicCount = dynamicService.getDynamicNumByUser(friendid);
			return Msg.success().add("userinfo", userinfo).add("friendcount", friendcount)
					.add("follwcount", follwcount).add("fanscount", fanscount).add("hasfollow", hasfollow).add("dynamicCount", dynamicCount);
		}	
		else {
			return Msg.fail();
		}
	}

	//得到用户头像
	@RequestMapping("/home/profile")
	public void test(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "url") String url) {
		// response.setContentType("application/octet-stream;charset=UTF-8");
		try {
			FileInputStream in;
			in = new FileInputStream(baseUserPictureUrl + url);
			int i = in.available();
			byte[] data = new byte[i];
			in.read(data);
			in.close();

			// 写图片
			OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
			outputStream.write(data);
			outputStream.flush();
			outputStream.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//得到动态的图片
	@RequestMapping("/home/dynamic")
	public void getdynamicPic(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "url") String url) {
		// response.setContentType("application/octet-stream;charset=UTF-8");
		try {
			FileInputStream in;
			in = new FileInputStream(MyProp.baseDynamicPictureUrl + url);
			int i = in.available();
			byte[] data = new byte[i];
			in.read(data);
			in.close();

			// 写图片
			OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
			outputStream.write(data);
			outputStream.flush();
			outputStream.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	//得到好友列表：frienditem是类型（0好友，1关注，2粉丝）
	@RequestMapping(value = "/friends/{accountid}/{frienditem}")
	@ResponseBody
	public Msg getFriends(@PathVariable("accountid") String accountid, @PathVariable("frienditem") int frienditem) {
		List<User_info> friends_info = friendsService.getFriendsInfo(accountid, frienditem);
		return Msg.success().add("friends", friends_info).add("haha", "哈哈");

	}

	//得到用户的礼物列表
	@RequestMapping(value = "/gift/{accountid}")
	@ResponseBody
	public Msg getGift(@PathVariable("accountid") String accountid) {
		List<GiftHolder> Gifts = user_giftService.getGifts(accountid);
		if(Gifts != null)
			return Msg.success().add("gifts", Gifts);
		else
			return Msg.fail();
	}
	/*
	@RequestMapping(value="/gettoken")
	public Msg getToken(@RequestParam("userid") String userId,@RequestParam("name") String name){
		int val = new Random().nextInt(10);
        long timestamp = new Date().getTime();
        String data = MyProp.appSecret + val + timestamp;
        String siqn = DigestUtils.sha1Hex(data);
        Map<String,String> params = new HashMap<String, String>();
        Map<String,String> headers = new HashMap<String, String>();
        params.put("userid", userId);
        params.put("name", name);
        headers.put("App-Key", MyProp.appKey);
        headers.put("Nonce", val+"");
        headers.put("Timestamp", timestamp+"");
        headers.put("Signature", siqn);
        String token = HttpHelper.sendPostByHttpUrlConnection(getTokenUrl, params, headers, "UTF-8");
		return Msg.success().add("token", token);
		
	}*/
	
	//改变头像
	@RequestMapping(value = "/setting/changeprofile/{accountid}", method = RequestMethod.POST)
	public void uploadOrderSignImage(HttpServletRequest request,@PathVariable("accountid") String accountid) {
		try {
			MultipartHttpServletRequest rq = (MultipartHttpServletRequest) request;
			Map<String, MultipartFile> file_list = rq.getFileMap();
			String url = baseUserPictureUrl+userService.getUserInfo(accountid).getProfile();
			File targetFile = new File(url);  
			if (!targetFile.exists()) {  
		           targetFile.mkdirs();  
		       } 
			if (file_list != null && file_list.size() > 0) {
				if (file_list.containsKey("inputName")) {
					MultipartFile file = file_list.get("inputName");
					file.transferTo(targetFile);
					Boolean ys = BaseUtil.zipWidthHeightImageFile(targetFile.getPath(), targetFile.getPath(), 400,400, 1f);
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//accountid关注用户friendid
	@ResponseBody
	@RequestMapping(value="/follow/{accountid}/{friendid}")
	public Msg follow(@PathVariable("accountid") String accountid,
			@PathVariable("friendid") String friendid){
		int i = friendsService.follow(accountid, friendid);
		if(i == -1)
			return Msg.fail();
		else
			return Msg.success();
	}
	//accountid关注用户friendid
		@ResponseBody
		@RequestMapping(value="/changepassword/{accountid}")
		public Msg changepassword(@PathVariable("accountid") String accountid){
			
			if(false)
				return Msg.fail();
			else
				return Msg.success();

		}
		
	
}
