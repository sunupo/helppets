package cn.tt.controller;

import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.test.annotation.Rollback;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Comment;
import cn.tt.bean.Dynamic;
import cn.tt.bean.DynamicState;
import cn.tt.bean.Msg;
import cn.tt.bean.Voicedy;
import cn.tt.bean.view.DynamicVO;
import cn.tt.service.DynamicService;
import cn.tt.service.DynamicStateService;
import cn.tt.utils.Constants;
import cn.tt.utils.MyProp;

@Controller
@RequestMapping("/dynamic")
public class DynamicController {

	@Autowired
	private DynamicService dynamicService;
	@Autowired
	private DynamicStateService stateService;
	
	private String baseDynamicPictureUrl = MyProp.baseDynamicPictureUrl;

	@ResponseBody
	@RequestMapping("/dynamicforid/{dynamicId}")
	public Msg getDynamic(@PathVariable("dynamicId") String dynamicId) {
		Dynamic dynamic = dynamicService.getDynamic(dynamicId);
		if (dynamic != null)
			return Msg.success().add("dynamic", dynamic);
		else {
			return Msg.fail();
		}
	}

	@ResponseBody
	@RequestMapping("/dynamicall")
	public Msg getAllDynamic() {
		List<Dynamic> allDynamic = dynamicService.getAllDynamic();
		if (allDynamic != null) {
			return Msg.success().add("alldynamic", allDynamic);
		} else {
			return Msg.fail();
		}
	}
	
	/**
	 * ��ȡ���û���ȫ����̬������û���accountId
	 * @param accountId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/dynamicallbyuserid/{accountId}")
	public Msg getAllDynamicById(@PathVariable("accountId") String accountId) {
		List<DynamicVO> allDynamic = dynamicService.getAllDyVOByUserID(accountId);
		if (allDynamic != null) {
			return Msg.success().add("alldynamic", allDynamic);
		} else {
			return Msg.fail();
		}
	}

	/**
	 * ��ȡ�����û��Ķ�̬��Ϣ
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/dynamicallVO")
	public Msg getAllDynamicVO() {
		List<DynamicVO> allDynamic = dynamicService.getAllDynamicVO();
		if (allDynamic != null) {
			return Msg.success().add("alldynamic", allDynamic);
		} else {
			return Msg.fail();
		}
	}

	/**
	 * http://localhost:8080/TT/dynamic/dynamicImag/image?url=/00/00/00/01/
	 * 1803311620.jpg
	 */
	@RequestMapping("/dynamicImag/image")
	public void test(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "url") String url) {
		// response.setContentType("application/octet-stream;charset=UTF-8");
		try {
			if (!url.equals("null") && url != null) {//����̬û��ͼƬʱ��ִ�л�ȡͼƬ��������ֹ�ļ��Ҳ����쳣
				FileInputStream in;
				System.out.println("--------------------" + url);
				in = new FileInputStream(baseDynamicPictureUrl + url);
				int i = in.available();
				byte[] data = new byte[i];
				in.read(data);
				in.close();

				OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
				outputStream.write(data);
				outputStream.flush();
				outputStream.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/**
	 * ���붯̬
	 * @param dynamic
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/postDynamic")
	public Msg postDynamic(Dynamic dynamic) {
		System.out.println(dynamic);
		int state = dynamicService.insertOneDynamic(dynamic);
		if (state == 1) {
			return Msg.success();
		}else {
			return Msg.fail();
		}
		
	}
	/**
	 * ��������
	 * account=00000001&commentAccount=00000004&dynaimcId=000000010001&content=����
	 * @param comment
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/postComment")
	public Msg postComment(Comment comment) {
		System.out.println(comment);
		int state = dynamicService.insertOneComment(comment);
		if (state == 1) {
			return Msg.success();
		}else {
			return Msg.fail();
		}
		
	}
	
	/**
	 *  http://localhost:8080/TT/dynamic/updateDynamic?dId=000000010001&support=5
	 * ����
	 * @param dynamic
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/updateDynamic")
	@Rollback(false)
	public Msg updateVoice(Dynamic dynamic) {
		System.out.println(dynamic);
		int state = dynamicService.updateCount(dynamic);
		System.out.println(state);
		if (state == 1) {
			return Msg.success();
		}else {
			return Msg.fail();
		}
	}
	
	@ResponseBody
	@RequestMapping("/getDynamicNumByUser/{accountid}")
	public Msg getDynamicNumByUser(@PathVariable("accountid") String accountid) {
		Integer res = dynamicService.getDynamicNumByUser(accountid);
		if (res >= 0 ) {
			return Msg.success().add("number", res);
		}else {
			return Msg.fail();
		}
	}

}
