package cn.tt.controller;

import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.tt.bean.Wallet;
import cn.tt.service.User_giftService;
import cn.tt.service.WalletService;
import cn.tt.utils.MyProp;
/*
 * 聊天controller
 */
@Controller
@RequestMapping("/chat")
public class ChatController {
	private String baseGiftPictureUrl = MyProp.baseGiftPictureUrl;
	@Autowired
	private WalletService walletService;
	
	@Autowired
	private User_giftService user_giftService;
	
	//送红包
	@RequestMapping("/updateReadPacket")
	public void updateReadPacket(@RequestParam("accountid") String accountId,
			@RequestParam("nums") int nums, @RequestParam("isSincerity") boolean isSincerity){
		
		walletService.updateReadPacket(accountId, nums, isSincerity);
	}
	
	//得到礼物的图片
	@RequestMapping("/gift/getPic")
	public void giftPicture(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "url") String url) {
		// response.setContentType("application/octet-stream;charset=UTF-8");
		try {
			FileInputStream in;
			in = new FileInputStream(baseGiftPictureUrl + url);
			int i = in.available();
			byte[] data = new byte[i];
			in.read(data);
			in.close();

			// 写图片
			OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
			outputStream.write(data);
			outputStream.flush();
			outputStream.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//添加礼物
	@RequestMapping("/gift/addGift")
	public void addGift(@RequestParam("toid") String toid, @RequestParam("giftid") int giftid,
			@RequestParam("dyid") String dyid,@RequestParam("fromid") String fromid){
		user_giftService.addGift(toid, giftid, dyid, fromid);
	}
	
	//删除礼物，送出的要删除
	@RequestMapping("/gift/removeGift")
	public void removeGift(@RequestParam("toid") String toid, @RequestParam("giftid") int giftid,
			@RequestParam("dyid") String dyid,@RequestParam("fromid") String fromid){
		user_giftService.removeGift(toid, giftid, dyid, fromid);
	}
	
}
