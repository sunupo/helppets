package cn.tt.service;

import java.nio.file.attribute.UserDefinedFileAttributeView;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Gift;
import cn.tt.bean.User_gift;
import cn.tt.bean.User_giftExample;
import cn.tt.dao.GiftMapper;
import cn.tt.dao.User_giftMapper;
import cn.tt.utils.GiftHolder;

@Service
public class User_giftService {
	@Autowired
	private User_giftMapper user_giftMapper;
	
	@Autowired
	private GiftMapper giftMapper;
	
	public List<User_gift> getUserGift(String accountid){
		User_giftExample example = new User_giftExample();
		example.createCriteria().andAccountIdEqualTo(accountid);
		return user_giftMapper.selectByExample(example);
	}
	
	public List<GiftHolder> getGifts(String accountid){
		List<GiftHolder> Gifts = new ArrayList<GiftHolder>();
		List<User_gift> list = getUserGift(accountid);
		for(User_gift usergift : list){
			GiftHolder holder = new GiftHolder();
			Gift gift = giftMapper.selectByPrimaryKey(usergift.getGiftId());
			holder.setCount(usergift.getCount());
			holder.setgCategory(gift.getgCategory());
			holder.setgId(gift.getgId());
			holder.setgName(gift.getgName());
			holder.setIntegral(gift.getIntegral());
			holder.setSincererity(gift.getSincererity());
			holder.setPictureurl(gift.getPictureurl());
			Gifts.add(holder);
		}
		return Gifts;
	}
	
	public void addGift(String toid, int giftid, String dyid,String fromid){
		User_giftExample example = new User_giftExample();
		User_giftExample.Criteria criteria = example.createCriteria();
		criteria.andAccountIdEqualTo(toid).andGiftIdEqualTo(giftid);
		List<User_gift> userGifts = user_giftMapper.selectByExample(example);
		if(userGifts == null || userGifts.size() == 0){
			User_gift ug = new User_gift();
			ug.setAccountId(toid);
			ug.setGiftId(giftid);
			ug.setCount(1);
			user_giftMapper.insert(ug);
		}else{
			User_gift ug = userGifts.get(0);
			ug.setCount(ug.getCount()+1);	
			user_giftMapper.updateByExample(ug, example);
		}
		
	}
	
	//送出去的用户要删去对应礼物
	public void removeGift(String toid, int giftid, String dyid,String fromid){
		User_giftExample example = new User_giftExample();
		User_giftExample.Criteria criteria = example.createCriteria();
		criteria.andAccountIdEqualTo(fromid).andGiftIdEqualTo(giftid);
		List<User_gift> userGifts = user_giftMapper.selectByExample(example);
		if(userGifts == null || userGifts.size() == 0){
			return;
		}else{
			User_gift ug = userGifts.get(0);
			int count = ug.getCount();
			if(count == 1)
				user_giftMapper.deleteByExample(example);
			else{
				ug.setCount(count-1);	
				user_giftMapper.updateByExample(ug, example);
			}
			
		}
		
	}
	
	public void removeGiftFromExchange(String accountid, int giftid, int num){
		User_giftExample example = new User_giftExample();
		User_giftExample.Criteria criteria = example.createCriteria();
		criteria.andAccountIdEqualTo(accountid).andGiftIdEqualTo(giftid);
		List<User_gift> userGifts = user_giftMapper.selectByExample(example);
		if(userGifts == null || userGifts.size() == 0){
			return;
		}else{
			User_gift ug = userGifts.get(0);
			int count = ug.getCount();
			if(count == num)
				user_giftMapper.deleteByExample(example);
			else if(count > num){
				ug.setCount(count-num);	
				user_giftMapper.updateByExample(ug, example);
			}
			
		}
		
	}
	
	public int deleteAllGifts(String accountid){
		User_giftExample example = new User_giftExample();
		example.createCriteria().andAccountIdEqualTo(accountid);
		return user_giftMapper.deleteByExample(example);
	}
	
	public long getGiftCount(String accountid){
		return user_giftMapper.sumByAccountid(accountid);
	}
}
