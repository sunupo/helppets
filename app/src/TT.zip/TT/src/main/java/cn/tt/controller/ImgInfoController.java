package cn.tt.controller;


import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.tt.bean.Album;
import cn.tt.bean.ImgInfo;
import cn.tt.bean.Msg;
import cn.tt.service.AlbumService;
import cn.tt.service.ImageInfoService;
import cn.tt.utils.MyProp;

@Controller
@RequestMapping("/image")
public class ImgInfoController {
	@Autowired
	private ImageInfoService imgService;
	
	/**
	 * test: http://localhost:8080/TT/image/addimg?albumid=2&filename=hello
	 * @param imgInfo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/addimg")
	public Msg addImg(ImgInfo imgInfo) {
		int res = imgService.addImgInfo(imgInfo);
		if (res == 1)
			return Msg.success();
		else {
			return Msg.fail();
		}
	}
	
	@ResponseBody
	@RequestMapping("/addimgs")
	public Msg addImgs(List<ImgInfo> imgs) {
		return null;
	}
	
	/**
	 * http://localhost:8080/TT/image/getimginfo/2b30f75e-bb46-42ab-9a2e-8a981c176ae8
	 * @param imgid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getimginfo/{imgid}")
	public Msg getAlbumVoice(@PathVariable("imgid") String imgid) {
		ImgInfo imgInfo= imgService.getImg(imgid);
		if (imgInfo != null)
			return Msg.success().add("imgInfo", imgInfo);
		else {
			return Msg.fail();
		}
	}
	
	/**
	 * http://localhost:8080/TT/image/getimgsbyalbum/2
	 * @param albumid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getimgsbyalbum/{albumid}")
	public Msg getImgsByAlbum(@PathVariable("albumid") String albumid) {
		List<ImgInfo> imgs = imgService.getImgsByAlbum(albumid);
		if ( imgs != null)
			return Msg.success().add("imgs", imgs);
		else {
			return Msg.fail();
		}
	}
	
	/**
	 * http://localhost:8080/TT/image/getimgsbyalbum/2
	 * @param albumid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getImgsByUser/{accountid}")
	public Msg getImgsByUser(@PathVariable("accountid") String accountid) {
		List<String> res = imgService.getImgsByUser(accountid);
		if ( res != null ){
			return Msg.success().add("imgurls", res);
		}
		else{
			return Msg.fail();
		}
	}
	
	@RequestMapping("/albumimg")
	public void test(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "url") String url) {
		// response.setContentType("application/octet-stream;charset=UTF-8");
		try {
			if (!url.equals("null") && url != null) {
				FileInputStream in;
				in = new FileInputStream(MyProp.baseAlbumPictureUrl + url);
				int i = in.available();
				byte[] data = new byte[i];
				in.read(data);
				in.close();
				OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
				outputStream.write(data);
				outputStream.flush();
				outputStream.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * @param accountid 
	 * @param num 要获取的个数
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getFreeImgsByUser/{accountid}/{num}")
	public Msg getFreeImgsByUser(@PathVariable("accountid") String accountid, @PathVariable("num") Integer num) {
		List<String> res = imgService.getFreeImgsByUser(accountid,num);
		if ( res != null ){
			return Msg.success().add("imgurls", res);
		}
		else{
			return Msg.fail();
		}
	}
	
}
