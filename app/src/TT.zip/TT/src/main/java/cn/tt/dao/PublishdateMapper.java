package cn.tt.dao;

import cn.tt.bean.Publishdate;
import cn.tt.bean.PublishdateExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PublishdateMapper {
    long countByExample(PublishdateExample example);

    int deleteByExample(PublishdateExample example);

    int deleteByPrimaryKey(Integer dId);

    int insert(Publishdate record);

    int insertSelective(Publishdate record);

    List<Publishdate> selectByExample(PublishdateExample example);

    Publishdate selectByPrimaryKey(Integer dId);

    int updateByExampleSelective(@Param("record") Publishdate record, @Param("example") PublishdateExample example);

    int updateByExample(@Param("record") Publishdate record, @Param("example") PublishdateExample example);

    int updateByPrimaryKeySelective(Publishdate record);

    int updateByPrimaryKey(Publishdate record);
}