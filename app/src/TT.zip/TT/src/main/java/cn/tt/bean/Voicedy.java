package cn.tt.bean;

import java.util.List;

public class Voicedy {
    private String vId;

    private String accountId;

    private Integer vCategory;

    private Integer vTime;

    private Integer vPeroflisen;

    private Integer vRate;

    private Integer support;

    private Integer unlike;

    private Integer gift;

    private Integer comment;

    private Integer share;

    private String voiceUrl;

    private String voicePubtime;

    private Integer level;

    private Double price;
    private User_info user_info;
    private List<VoiComment> voicommentList;
    
  
    public User_info getUser_info() {
		return user_info;
	}

	public void setUser_info(User_info user_info) {
		this.user_info = user_info;
	}

	public List<VoiComment> getVoicommentList() {
		return voicommentList;
	}

	public void setVoicommentList(List<VoiComment> voicommentList) {
		this.voicommentList = voicommentList;
	}

    public String getvId() {
        return vId;
    }

    public void setvId(String vId) {
        this.vId = vId == null ? null : vId.trim();
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId == null ? null : accountId.trim();
    }

    public Integer getvCategory() {
        return vCategory;
    }

    public void setvCategory(Integer vCategory) {
        this.vCategory = vCategory;
    }

    public Integer getvTime() {
        return vTime;
    }

    public void setvTime(Integer vTime) {
        this.vTime = vTime;
    }

    public Integer getvPeroflisen() {
        return vPeroflisen;
    }

    public void setvPeroflisen(Integer vPeroflisen) {
        this.vPeroflisen = vPeroflisen;
    }

    public Integer getvRate() {
        return vRate;
    }

    public void setvRate(Integer vRate) {
        this.vRate = vRate;
    }

    public Integer getSupport() {
        return support;
    }

    public void setSupport(Integer support) {
        this.support = support;
    }

    public Integer getUnlike() {
        return unlike;
    }

    public void setUnlike(Integer unlike) {
        this.unlike = unlike;
    }

    public Integer getGift() {
        return gift;
    }

    public void setGift(Integer gift) {
        this.gift = gift;
    }

    public Integer getComment() {
        return comment;
    }

    public void setComment(Integer comment) {
        this.comment = comment;
    }

    public Integer getShare() {
        return share;
    }

    public void setShare(Integer share) {
        this.share = share;
    }

    public String getVoiceUrl() {
        return voiceUrl;
    }

    public void setVoiceUrl(String voiceUrl) {
        this.voiceUrl = voiceUrl == null ? null : voiceUrl.trim();
    }

    public String getVoicePubtime() {
        return voicePubtime;
    }

    public void setVoicePubtime(String voicePubtime) {
        this.voicePubtime = voicePubtime == null ? null : voicePubtime.trim();
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}