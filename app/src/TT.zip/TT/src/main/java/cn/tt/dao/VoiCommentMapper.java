package cn.tt.dao;

import cn.tt.bean.VoiComment;
import cn.tt.bean.VoiCommentExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface VoiCommentMapper {
    long countByExample(VoiCommentExample example);

    int deleteByExample(VoiCommentExample example);

    int deleteByPrimaryKey(String vcId);

    int insert(VoiComment record);

    int insertSelective(VoiComment record);

    List<VoiComment> selectByExample(VoiCommentExample example);

    VoiComment selectByPrimaryKey(String vcId);

    int updateByExampleSelective(@Param("record") VoiComment record, @Param("example") VoiCommentExample example);

    int updateByExample(@Param("record") VoiComment record, @Param("example") VoiCommentExample example);

    int updateByPrimaryKeySelective(VoiComment record);

    int updateByPrimaryKey(VoiComment record);
}