package cn.tt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.User_info;
import cn.tt.bean.User_infoExample;
import cn.tt.bean.User_infoExample.Criteria;
import cn.tt.dao.User_infoMapper;





@Service
public class UserService {
	
	@Autowired
	private User_infoMapper user_infoMapper;
	
	public User_info getUserInfo(String accountId){
		return user_infoMapper.selectByPrimaryKey(accountId);
	}
	
	public List<List<User_info>> getMainUserInfo(String relation,String city,int start,int end){
		User_infoExample example = new User_infoExample();
		example.setOrderByClause("fanscount desc");
		/*
		 * *<if test="offset != null &amp;&amp; limit != null">
			limit ${offset},${limit}
			</if>
		 */
		Criteria criteria = example.createCriteria();  
		if(!relation.equals("all"))
			criteria.andRelationEqualTo(relation);
		if(!city.equals("all"))
			criteria.andCityEqualTo(city);
		if(start != -1)
			criteria.andAgeGreaterThanOrEqualTo(start);
		if(end != -1)
			criteria.andAgeLessThanOrEqualTo(end);
		example.setOffset(0);
		example.setLimit(12);
		List<User_info> list = user_infoMapper.selectByExample(example);
		List<List<User_info>> newlist = new ArrayList<List<User_info>>();
		int index = 0;
		int length = list.size();
		while(index < length){
			List<User_info> curlist = new ArrayList<User_info>();
			for(int i = 0; i < 6 && index < length; i++){
				curlist.add(list.get(index++));
			}
			newlist.add(curlist);
		}
		
		return newlist;
		
	}
	
	public boolean updateUser(String accountid, String name, String city, String height, String weight,
             String age, String relation){
		User_info user = user_infoMapper.selectByPrimaryKey(accountid);
		 user.setName(name);
		user.setCity(city);
		user.setAge(Integer.parseInt(age));
		user.setHight(Integer.parseInt(height));
		user.setWeight(Integer.parseInt(weight));
		user.setRelation(relation);
		user_infoMapper.updateByPrimaryKey(user);
		return true;
	}
	
	
}
