package cn.tt.dao;

import cn.tt.bean.ImgInfo;
import cn.tt.bean.ImgInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ImgInfoMapper {
    long countByExample(ImgInfoExample example);

    int deleteByExample(ImgInfoExample example);

    int deleteByPrimaryKey(String imgid);

    int insert(ImgInfo record);

    int insertSelective(ImgInfo record);

    List<ImgInfo> selectByExample(ImgInfoExample example);

    ImgInfo selectByPrimaryKey(String imgid);

    int updateByExampleSelective(@Param("record") ImgInfo record, @Param("example") ImgInfoExample example);

    int updateByExample(@Param("record") ImgInfo record, @Param("example") ImgInfoExample example);

    int updateByPrimaryKeySelective(ImgInfo record);

    int updateByPrimaryKey(ImgInfo record);
    
    List<ImgInfo> selectImgsByAlbum(String albumid);
    List<String> selectFreeImgsByUser(@Param("accountid")String accountid, @Param("offset")Integer offset, @Param("limit")Integer limit);
    List<String> selectChargeImgsByUser(@Param("accountid")String accountid, @Param("offset")Integer offset, @Param("limit")Integer limit);
    List<String> selectVipfreeImgsByUser(@Param("accountid")String accountid, @Param("offset")Integer offset, @Param("limit")Integer limit);
}