package cn.tt.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class WalletExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public WalletExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andAccountIdIsNull() {
            addCriterion("account_id is null");
            return (Criteria) this;
        }

        public Criteria andAccountIdIsNotNull() {
            addCriterion("account_id is not null");
            return (Criteria) this;
        }

        public Criteria andAccountIdEqualTo(String value) {
            addCriterion("account_id =", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotEqualTo(String value) {
            addCriterion("account_id <>", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThan(String value) {
            addCriterion("account_id >", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThanOrEqualTo(String value) {
            addCriterion("account_id >=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThan(String value) {
            addCriterion("account_id <", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThanOrEqualTo(String value) {
            addCriterion("account_id <=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLike(String value) {
            addCriterion("account_id like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotLike(String value) {
            addCriterion("account_id not like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdIn(List<String> values) {
            addCriterion("account_id in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotIn(List<String> values) {
            addCriterion("account_id not in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdBetween(String value1, String value2) {
            addCriterion("account_id between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotBetween(String value1, String value2) {
            addCriterion("account_id not between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andIntegralIsNull() {
            addCriterion("integral is null");
            return (Criteria) this;
        }

        public Criteria andIntegralIsNotNull() {
            addCriterion("integral is not null");
            return (Criteria) this;
        }

        public Criteria andIntegralEqualTo(Integer value) {
            addCriterion("integral =", value, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralNotEqualTo(Integer value) {
            addCriterion("integral <>", value, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralGreaterThan(Integer value) {
            addCriterion("integral >", value, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralGreaterThanOrEqualTo(Integer value) {
            addCriterion("integral >=", value, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralLessThan(Integer value) {
            addCriterion("integral <", value, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralLessThanOrEqualTo(Integer value) {
            addCriterion("integral <=", value, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralIn(List<Integer> values) {
            addCriterion("integral in", values, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralNotIn(List<Integer> values) {
            addCriterion("integral not in", values, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralBetween(Integer value1, Integer value2) {
            addCriterion("integral between", value1, value2, "integral");
            return (Criteria) this;
        }

        public Criteria andIntegralNotBetween(Integer value1, Integer value2) {
            addCriterion("integral not between", value1, value2, "integral");
            return (Criteria) this;
        }

        public Criteria andSincerityIsNull() {
            addCriterion("Sincerity is null");
            return (Criteria) this;
        }

        public Criteria andSincerityIsNotNull() {
            addCriterion("Sincerity is not null");
            return (Criteria) this;
        }

        public Criteria andSincerityEqualTo(Integer value) {
            addCriterion("Sincerity =", value, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityNotEqualTo(Integer value) {
            addCriterion("Sincerity <>", value, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityGreaterThan(Integer value) {
            addCriterion("Sincerity >", value, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityGreaterThanOrEqualTo(Integer value) {
            addCriterion("Sincerity >=", value, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityLessThan(Integer value) {
            addCriterion("Sincerity <", value, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityLessThanOrEqualTo(Integer value) {
            addCriterion("Sincerity <=", value, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityIn(List<Integer> values) {
            addCriterion("Sincerity in", values, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityNotIn(List<Integer> values) {
            addCriterion("Sincerity not in", values, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityBetween(Integer value1, Integer value2) {
            addCriterion("Sincerity between", value1, value2, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSincerityNotBetween(Integer value1, Integer value2) {
            addCriterion("Sincerity not between", value1, value2, "sincerity");
            return (Criteria) this;
        }

        public Criteria andSigncountIsNull() {
            addCriterion("signcount is null");
            return (Criteria) this;
        }

        public Criteria andSigncountIsNotNull() {
            addCriterion("signcount is not null");
            return (Criteria) this;
        }

        public Criteria andSigncountEqualTo(Integer value) {
            addCriterion("signcount =", value, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountNotEqualTo(Integer value) {
            addCriterion("signcount <>", value, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountGreaterThan(Integer value) {
            addCriterion("signcount >", value, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountGreaterThanOrEqualTo(Integer value) {
            addCriterion("signcount >=", value, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountLessThan(Integer value) {
            addCriterion("signcount <", value, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountLessThanOrEqualTo(Integer value) {
            addCriterion("signcount <=", value, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountIn(List<Integer> values) {
            addCriterion("signcount in", values, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountNotIn(List<Integer> values) {
            addCriterion("signcount not in", values, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountBetween(Integer value1, Integer value2) {
            addCriterion("signcount between", value1, value2, "signcount");
            return (Criteria) this;
        }

        public Criteria andSigncountNotBetween(Integer value1, Integer value2) {
            addCriterion("signcount not between", value1, value2, "signcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountIsNull() {
            addCriterion("rewardcount is null");
            return (Criteria) this;
        }

        public Criteria andRewardcountIsNotNull() {
            addCriterion("rewardcount is not null");
            return (Criteria) this;
        }

        public Criteria andRewardcountEqualTo(Integer value) {
            addCriterion("rewardcount =", value, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountNotEqualTo(Integer value) {
            addCriterion("rewardcount <>", value, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountGreaterThan(Integer value) {
            addCriterion("rewardcount >", value, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("rewardcount >=", value, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountLessThan(Integer value) {
            addCriterion("rewardcount <", value, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountLessThanOrEqualTo(Integer value) {
            addCriterion("rewardcount <=", value, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountIn(List<Integer> values) {
            addCriterion("rewardcount in", values, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountNotIn(List<Integer> values) {
            addCriterion("rewardcount not in", values, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountBetween(Integer value1, Integer value2) {
            addCriterion("rewardcount between", value1, value2, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andRewardcountNotBetween(Integer value1, Integer value2) {
            addCriterion("rewardcount not between", value1, value2, "rewardcount");
            return (Criteria) this;
        }

        public Criteria andChatcountIsNull() {
            addCriterion("chatcount is null");
            return (Criteria) this;
        }

        public Criteria andChatcountIsNotNull() {
            addCriterion("chatcount is not null");
            return (Criteria) this;
        }

        public Criteria andChatcountEqualTo(Integer value) {
            addCriterion("chatcount =", value, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountNotEqualTo(Integer value) {
            addCriterion("chatcount <>", value, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountGreaterThan(Integer value) {
            addCriterion("chatcount >", value, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountGreaterThanOrEqualTo(Integer value) {
            addCriterion("chatcount >=", value, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountLessThan(Integer value) {
            addCriterion("chatcount <", value, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountLessThanOrEqualTo(Integer value) {
            addCriterion("chatcount <=", value, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountIn(List<Integer> values) {
            addCriterion("chatcount in", values, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountNotIn(List<Integer> values) {
            addCriterion("chatcount not in", values, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountBetween(Integer value1, Integer value2) {
            addCriterion("chatcount between", value1, value2, "chatcount");
            return (Criteria) this;
        }

        public Criteria andChatcountNotBetween(Integer value1, Integer value2) {
            addCriterion("chatcount not between", value1, value2, "chatcount");
            return (Criteria) this;
        }

        public Criteria andSharecountIsNull() {
            addCriterion("sharecount is null");
            return (Criteria) this;
        }

        public Criteria andSharecountIsNotNull() {
            addCriterion("sharecount is not null");
            return (Criteria) this;
        }

        public Criteria andSharecountEqualTo(Integer value) {
            addCriterion("sharecount =", value, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountNotEqualTo(Integer value) {
            addCriterion("sharecount <>", value, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountGreaterThan(Integer value) {
            addCriterion("sharecount >", value, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountGreaterThanOrEqualTo(Integer value) {
            addCriterion("sharecount >=", value, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountLessThan(Integer value) {
            addCriterion("sharecount <", value, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountLessThanOrEqualTo(Integer value) {
            addCriterion("sharecount <=", value, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountIn(List<Integer> values) {
            addCriterion("sharecount in", values, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountNotIn(List<Integer> values) {
            addCriterion("sharecount not in", values, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountBetween(Integer value1, Integer value2) {
            addCriterion("sharecount between", value1, value2, "sharecount");
            return (Criteria) this;
        }

        public Criteria andSharecountNotBetween(Integer value1, Integer value2) {
            addCriterion("sharecount not between", value1, value2, "sharecount");
            return (Criteria) this;
        }

        public Criteria andVipIsNull() {
            addCriterion("vip is null");
            return (Criteria) this;
        }

        public Criteria andVipIsNotNull() {
            addCriterion("vip is not null");
            return (Criteria) this;
        }

        public Criteria andVipEqualTo(Byte value) {
            addCriterion("vip =", value, "vip");
            return (Criteria) this;
        }

        public Criteria andVipNotEqualTo(Byte value) {
            addCriterion("vip <>", value, "vip");
            return (Criteria) this;
        }

        public Criteria andVipGreaterThan(Byte value) {
            addCriterion("vip >", value, "vip");
            return (Criteria) this;
        }

        public Criteria andVipGreaterThanOrEqualTo(Byte value) {
            addCriterion("vip >=", value, "vip");
            return (Criteria) this;
        }

        public Criteria andVipLessThan(Byte value) {
            addCriterion("vip <", value, "vip");
            return (Criteria) this;
        }

        public Criteria andVipLessThanOrEqualTo(Byte value) {
            addCriterion("vip <=", value, "vip");
            return (Criteria) this;
        }

        public Criteria andVipIn(List<Byte> values) {
            addCriterion("vip in", values, "vip");
            return (Criteria) this;
        }

        public Criteria andVipNotIn(List<Byte> values) {
            addCriterion("vip not in", values, "vip");
            return (Criteria) this;
        }

        public Criteria andVipBetween(Byte value1, Byte value2) {
            addCriterion("vip between", value1, value2, "vip");
            return (Criteria) this;
        }

        public Criteria andVipNotBetween(Byte value1, Byte value2) {
            addCriterion("vip not between", value1, value2, "vip");
            return (Criteria) this;
        }

        public Criteria andExpireIsNull() {
            addCriterion("expire is null");
            return (Criteria) this;
        }

        public Criteria andExpireIsNotNull() {
            addCriterion("expire is not null");
            return (Criteria) this;
        }

        public Criteria andExpireEqualTo(Date value) {
            addCriterionForJDBCDate("expire =", value, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireNotEqualTo(Date value) {
            addCriterionForJDBCDate("expire <>", value, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireGreaterThan(Date value) {
            addCriterionForJDBCDate("expire >", value, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("expire >=", value, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireLessThan(Date value) {
            addCriterionForJDBCDate("expire <", value, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("expire <=", value, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireIn(List<Date> values) {
            addCriterionForJDBCDate("expire in", values, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireNotIn(List<Date> values) {
            addCriterionForJDBCDate("expire not in", values, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("expire between", value1, value2, "expire");
            return (Criteria) this;
        }

        public Criteria andExpireNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("expire not between", value1, value2, "expire");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}