package cn.tt.bean;

import java.util.ArrayList;
import java.util.List;

public class VoicedyExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public VoicedyExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andVIdIsNull() {
            addCriterion("v_id is null");
            return (Criteria) this;
        }

        public Criteria andVIdIsNotNull() {
            addCriterion("v_id is not null");
            return (Criteria) this;
        }

        public Criteria andVIdEqualTo(String value) {
            addCriterion("v_id =", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdNotEqualTo(String value) {
            addCriterion("v_id <>", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdGreaterThan(String value) {
            addCriterion("v_id >", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdGreaterThanOrEqualTo(String value) {
            addCriterion("v_id >=", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdLessThan(String value) {
            addCriterion("v_id <", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdLessThanOrEqualTo(String value) {
            addCriterion("v_id <=", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdLike(String value) {
            addCriterion("v_id like", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdNotLike(String value) {
            addCriterion("v_id not like", value, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdIn(List<String> values) {
            addCriterion("v_id in", values, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdNotIn(List<String> values) {
            addCriterion("v_id not in", values, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdBetween(String value1, String value2) {
            addCriterion("v_id between", value1, value2, "vId");
            return (Criteria) this;
        }

        public Criteria andVIdNotBetween(String value1, String value2) {
            addCriterion("v_id not between", value1, value2, "vId");
            return (Criteria) this;
        }

        public Criteria andAccountIdIsNull() {
            addCriterion("account_id is null");
            return (Criteria) this;
        }

        public Criteria andAccountIdIsNotNull() {
            addCriterion("account_id is not null");
            return (Criteria) this;
        }

        public Criteria andAccountIdEqualTo(String value) {
            addCriterion("account_id =", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotEqualTo(String value) {
            addCriterion("account_id <>", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThan(String value) {
            addCriterion("account_id >", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdGreaterThanOrEqualTo(String value) {
            addCriterion("account_id >=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThan(String value) {
            addCriterion("account_id <", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLessThanOrEqualTo(String value) {
            addCriterion("account_id <=", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdLike(String value) {
            addCriterion("account_id like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotLike(String value) {
            addCriterion("account_id not like", value, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdIn(List<String> values) {
            addCriterion("account_id in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotIn(List<String> values) {
            addCriterion("account_id not in", values, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdBetween(String value1, String value2) {
            addCriterion("account_id between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andAccountIdNotBetween(String value1, String value2) {
            addCriterion("account_id not between", value1, value2, "accountId");
            return (Criteria) this;
        }

        public Criteria andVCategoryIsNull() {
            addCriterion("v_category is null");
            return (Criteria) this;
        }

        public Criteria andVCategoryIsNotNull() {
            addCriterion("v_category is not null");
            return (Criteria) this;
        }

        public Criteria andVCategoryEqualTo(Integer value) {
            addCriterion("v_category =", value, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryNotEqualTo(Integer value) {
            addCriterion("v_category <>", value, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryGreaterThan(Integer value) {
            addCriterion("v_category >", value, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryGreaterThanOrEqualTo(Integer value) {
            addCriterion("v_category >=", value, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryLessThan(Integer value) {
            addCriterion("v_category <", value, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryLessThanOrEqualTo(Integer value) {
            addCriterion("v_category <=", value, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryIn(List<Integer> values) {
            addCriterion("v_category in", values, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryNotIn(List<Integer> values) {
            addCriterion("v_category not in", values, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryBetween(Integer value1, Integer value2) {
            addCriterion("v_category between", value1, value2, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVCategoryNotBetween(Integer value1, Integer value2) {
            addCriterion("v_category not between", value1, value2, "vCategory");
            return (Criteria) this;
        }

        public Criteria andVTimeIsNull() {
            addCriterion("v_time is null");
            return (Criteria) this;
        }

        public Criteria andVTimeIsNotNull() {
            addCriterion("v_time is not null");
            return (Criteria) this;
        }

        public Criteria andVTimeEqualTo(Integer value) {
            addCriterion("v_time =", value, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeNotEqualTo(Integer value) {
            addCriterion("v_time <>", value, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeGreaterThan(Integer value) {
            addCriterion("v_time >", value, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("v_time >=", value, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeLessThan(Integer value) {
            addCriterion("v_time <", value, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeLessThanOrEqualTo(Integer value) {
            addCriterion("v_time <=", value, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeIn(List<Integer> values) {
            addCriterion("v_time in", values, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeNotIn(List<Integer> values) {
            addCriterion("v_time not in", values, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeBetween(Integer value1, Integer value2) {
            addCriterion("v_time between", value1, value2, "vTime");
            return (Criteria) this;
        }

        public Criteria andVTimeNotBetween(Integer value1, Integer value2) {
            addCriterion("v_time not between", value1, value2, "vTime");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenIsNull() {
            addCriterion("v_peroflisen is null");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenIsNotNull() {
            addCriterion("v_peroflisen is not null");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenEqualTo(Integer value) {
            addCriterion("v_peroflisen =", value, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenNotEqualTo(Integer value) {
            addCriterion("v_peroflisen <>", value, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenGreaterThan(Integer value) {
            addCriterion("v_peroflisen >", value, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenGreaterThanOrEqualTo(Integer value) {
            addCriterion("v_peroflisen >=", value, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenLessThan(Integer value) {
            addCriterion("v_peroflisen <", value, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenLessThanOrEqualTo(Integer value) {
            addCriterion("v_peroflisen <=", value, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenIn(List<Integer> values) {
            addCriterion("v_peroflisen in", values, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenNotIn(List<Integer> values) {
            addCriterion("v_peroflisen not in", values, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenBetween(Integer value1, Integer value2) {
            addCriterion("v_peroflisen between", value1, value2, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVPeroflisenNotBetween(Integer value1, Integer value2) {
            addCriterion("v_peroflisen not between", value1, value2, "vPeroflisen");
            return (Criteria) this;
        }

        public Criteria andVRateIsNull() {
            addCriterion("v_rate is null");
            return (Criteria) this;
        }

        public Criteria andVRateIsNotNull() {
            addCriterion("v_rate is not null");
            return (Criteria) this;
        }

        public Criteria andVRateEqualTo(Integer value) {
            addCriterion("v_rate =", value, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateNotEqualTo(Integer value) {
            addCriterion("v_rate <>", value, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateGreaterThan(Integer value) {
            addCriterion("v_rate >", value, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateGreaterThanOrEqualTo(Integer value) {
            addCriterion("v_rate >=", value, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateLessThan(Integer value) {
            addCriterion("v_rate <", value, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateLessThanOrEqualTo(Integer value) {
            addCriterion("v_rate <=", value, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateIn(List<Integer> values) {
            addCriterion("v_rate in", values, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateNotIn(List<Integer> values) {
            addCriterion("v_rate not in", values, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateBetween(Integer value1, Integer value2) {
            addCriterion("v_rate between", value1, value2, "vRate");
            return (Criteria) this;
        }

        public Criteria andVRateNotBetween(Integer value1, Integer value2) {
            addCriterion("v_rate not between", value1, value2, "vRate");
            return (Criteria) this;
        }

        public Criteria andSupportIsNull() {
            addCriterion("support is null");
            return (Criteria) this;
        }

        public Criteria andSupportIsNotNull() {
            addCriterion("support is not null");
            return (Criteria) this;
        }

        public Criteria andSupportEqualTo(Integer value) {
            addCriterion("support =", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotEqualTo(Integer value) {
            addCriterion("support <>", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportGreaterThan(Integer value) {
            addCriterion("support >", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportGreaterThanOrEqualTo(Integer value) {
            addCriterion("support >=", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportLessThan(Integer value) {
            addCriterion("support <", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportLessThanOrEqualTo(Integer value) {
            addCriterion("support <=", value, "support");
            return (Criteria) this;
        }

        public Criteria andSupportIn(List<Integer> values) {
            addCriterion("support in", values, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotIn(List<Integer> values) {
            addCriterion("support not in", values, "support");
            return (Criteria) this;
        }

        public Criteria andSupportBetween(Integer value1, Integer value2) {
            addCriterion("support between", value1, value2, "support");
            return (Criteria) this;
        }

        public Criteria andSupportNotBetween(Integer value1, Integer value2) {
            addCriterion("support not between", value1, value2, "support");
            return (Criteria) this;
        }

        public Criteria andUnlikeIsNull() {
            addCriterion("unlike is null");
            return (Criteria) this;
        }

        public Criteria andUnlikeIsNotNull() {
            addCriterion("unlike is not null");
            return (Criteria) this;
        }

        public Criteria andUnlikeEqualTo(Integer value) {
            addCriterion("unlike =", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotEqualTo(Integer value) {
            addCriterion("unlike <>", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeGreaterThan(Integer value) {
            addCriterion("unlike >", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeGreaterThanOrEqualTo(Integer value) {
            addCriterion("unlike >=", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeLessThan(Integer value) {
            addCriterion("unlike <", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeLessThanOrEqualTo(Integer value) {
            addCriterion("unlike <=", value, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeIn(List<Integer> values) {
            addCriterion("unlike in", values, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotIn(List<Integer> values) {
            addCriterion("unlike not in", values, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeBetween(Integer value1, Integer value2) {
            addCriterion("unlike between", value1, value2, "unlike");
            return (Criteria) this;
        }

        public Criteria andUnlikeNotBetween(Integer value1, Integer value2) {
            addCriterion("unlike not between", value1, value2, "unlike");
            return (Criteria) this;
        }

        public Criteria andGiftIsNull() {
            addCriterion("gift is null");
            return (Criteria) this;
        }

        public Criteria andGiftIsNotNull() {
            addCriterion("gift is not null");
            return (Criteria) this;
        }

        public Criteria andGiftEqualTo(Integer value) {
            addCriterion("gift =", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftNotEqualTo(Integer value) {
            addCriterion("gift <>", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftGreaterThan(Integer value) {
            addCriterion("gift >", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftGreaterThanOrEqualTo(Integer value) {
            addCriterion("gift >=", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftLessThan(Integer value) {
            addCriterion("gift <", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftLessThanOrEqualTo(Integer value) {
            addCriterion("gift <=", value, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftIn(List<Integer> values) {
            addCriterion("gift in", values, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftNotIn(List<Integer> values) {
            addCriterion("gift not in", values, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftBetween(Integer value1, Integer value2) {
            addCriterion("gift between", value1, value2, "gift");
            return (Criteria) this;
        }

        public Criteria andGiftNotBetween(Integer value1, Integer value2) {
            addCriterion("gift not between", value1, value2, "gift");
            return (Criteria) this;
        }

        public Criteria andCommentIsNull() {
            addCriterion("comment is null");
            return (Criteria) this;
        }

        public Criteria andCommentIsNotNull() {
            addCriterion("comment is not null");
            return (Criteria) this;
        }

        public Criteria andCommentEqualTo(Integer value) {
            addCriterion("comment =", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotEqualTo(Integer value) {
            addCriterion("comment <>", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThan(Integer value) {
            addCriterion("comment >", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentGreaterThanOrEqualTo(Integer value) {
            addCriterion("comment >=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThan(Integer value) {
            addCriterion("comment <", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentLessThanOrEqualTo(Integer value) {
            addCriterion("comment <=", value, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentIn(List<Integer> values) {
            addCriterion("comment in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotIn(List<Integer> values) {
            addCriterion("comment not in", values, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentBetween(Integer value1, Integer value2) {
            addCriterion("comment between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andCommentNotBetween(Integer value1, Integer value2) {
            addCriterion("comment not between", value1, value2, "comment");
            return (Criteria) this;
        }

        public Criteria andShareIsNull() {
            addCriterion("share is null");
            return (Criteria) this;
        }

        public Criteria andShareIsNotNull() {
            addCriterion("share is not null");
            return (Criteria) this;
        }

        public Criteria andShareEqualTo(Integer value) {
            addCriterion("share =", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareNotEqualTo(Integer value) {
            addCriterion("share <>", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareGreaterThan(Integer value) {
            addCriterion("share >", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareGreaterThanOrEqualTo(Integer value) {
            addCriterion("share >=", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareLessThan(Integer value) {
            addCriterion("share <", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareLessThanOrEqualTo(Integer value) {
            addCriterion("share <=", value, "share");
            return (Criteria) this;
        }

        public Criteria andShareIn(List<Integer> values) {
            addCriterion("share in", values, "share");
            return (Criteria) this;
        }

        public Criteria andShareNotIn(List<Integer> values) {
            addCriterion("share not in", values, "share");
            return (Criteria) this;
        }

        public Criteria andShareBetween(Integer value1, Integer value2) {
            addCriterion("share between", value1, value2, "share");
            return (Criteria) this;
        }

        public Criteria andShareNotBetween(Integer value1, Integer value2) {
            addCriterion("share not between", value1, value2, "share");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlIsNull() {
            addCriterion("voice_url is null");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlIsNotNull() {
            addCriterion("voice_url is not null");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlEqualTo(String value) {
            addCriterion("voice_url =", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlNotEqualTo(String value) {
            addCriterion("voice_url <>", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlGreaterThan(String value) {
            addCriterion("voice_url >", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlGreaterThanOrEqualTo(String value) {
            addCriterion("voice_url >=", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlLessThan(String value) {
            addCriterion("voice_url <", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlLessThanOrEqualTo(String value) {
            addCriterion("voice_url <=", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlLike(String value) {
            addCriterion("voice_url like", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlNotLike(String value) {
            addCriterion("voice_url not like", value, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlIn(List<String> values) {
            addCriterion("voice_url in", values, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlNotIn(List<String> values) {
            addCriterion("voice_url not in", values, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlBetween(String value1, String value2) {
            addCriterion("voice_url between", value1, value2, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoiceUrlNotBetween(String value1, String value2) {
            addCriterion("voice_url not between", value1, value2, "voiceUrl");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeIsNull() {
            addCriterion("voice_pubtime is null");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeIsNotNull() {
            addCriterion("voice_pubtime is not null");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeEqualTo(String value) {
            addCriterion("voice_pubtime =", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeNotEqualTo(String value) {
            addCriterion("voice_pubtime <>", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeGreaterThan(String value) {
            addCriterion("voice_pubtime >", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeGreaterThanOrEqualTo(String value) {
            addCriterion("voice_pubtime >=", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeLessThan(String value) {
            addCriterion("voice_pubtime <", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeLessThanOrEqualTo(String value) {
            addCriterion("voice_pubtime <=", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeLike(String value) {
            addCriterion("voice_pubtime like", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeNotLike(String value) {
            addCriterion("voice_pubtime not like", value, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeIn(List<String> values) {
            addCriterion("voice_pubtime in", values, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeNotIn(List<String> values) {
            addCriterion("voice_pubtime not in", values, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeBetween(String value1, String value2) {
            addCriterion("voice_pubtime between", value1, value2, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andVoicePubtimeNotBetween(String value1, String value2) {
            addCriterion("voice_pubtime not between", value1, value2, "voicePubtime");
            return (Criteria) this;
        }

        public Criteria andLevelIsNull() {
            addCriterion("level is null");
            return (Criteria) this;
        }

        public Criteria andLevelIsNotNull() {
            addCriterion("level is not null");
            return (Criteria) this;
        }

        public Criteria andLevelEqualTo(Integer value) {
            addCriterion("level =", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelNotEqualTo(Integer value) {
            addCriterion("level <>", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelGreaterThan(Integer value) {
            addCriterion("level >", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelGreaterThanOrEqualTo(Integer value) {
            addCriterion("level >=", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelLessThan(Integer value) {
            addCriterion("level <", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelLessThanOrEqualTo(Integer value) {
            addCriterion("level <=", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelIn(List<Integer> values) {
            addCriterion("level in", values, "level");
            return (Criteria) this;
        }

        public Criteria andLevelNotIn(List<Integer> values) {
            addCriterion("level not in", values, "level");
            return (Criteria) this;
        }

        public Criteria andLevelBetween(Integer value1, Integer value2) {
            addCriterion("level between", value1, value2, "level");
            return (Criteria) this;
        }

        public Criteria andLevelNotBetween(Integer value1, Integer value2) {
            addCriterion("level not between", value1, value2, "level");
            return (Criteria) this;
        }

        public Criteria andPriceIsNull() {
            addCriterion("price is null");
            return (Criteria) this;
        }

        public Criteria andPriceIsNotNull() {
            addCriterion("price is not null");
            return (Criteria) this;
        }

        public Criteria andPriceEqualTo(Double value) {
            addCriterion("price =", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotEqualTo(Double value) {
            addCriterion("price <>", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThan(Double value) {
            addCriterion("price >", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThanOrEqualTo(Double value) {
            addCriterion("price >=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThan(Double value) {
            addCriterion("price <", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThanOrEqualTo(Double value) {
            addCriterion("price <=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceIn(List<Double> values) {
            addCriterion("price in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotIn(List<Double> values) {
            addCriterion("price not in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceBetween(Double value1, Double value2) {
            addCriterion("price between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotBetween(Double value1, Double value2) {
            addCriterion("price not between", value1, value2, "price");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}