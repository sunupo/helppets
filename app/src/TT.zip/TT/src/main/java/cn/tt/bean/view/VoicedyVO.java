package cn.tt.bean.view;

import java.util.List;

public class VoicedyVO {
	private String vId;//��̬��id
	private String accountId;//��̬�û���id

    private Integer vCategory;//���ͣ�������

    private String voicePubtime;//����ʱ��
    //ϲ������ϲ������������������������ת����
    private Integer support;
    private Integer unlike;
    private Integer gift;
    private Integer comment;
    private Integer share;

    private Integer vTime;//������ʱ��

    private Integer vPeroflisen;//���������İٷֱ�

    private Integer vRate;//�����û�����

    private String voiceUrl;//������ŵĵ�ַ
    
    private String name;//�û�����
    private String profile;//�û�ͷ��
	private Integer level; //�����ȼ������ɼ�0/��ͨ���ѿɼ�1/VIP���ѿɼ�2/�����û��ɼ�3
    private Double price; // ���ѽ��
    private List<CommentVO> commentList;//�����б�
    
    

	public String getvId() {
		return vId;
	}

	public void setvId(String vId) {
		this.vId = vId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Integer getvCategory() {
		return vCategory;
	}

	public void setvCategory(Integer vCategory) {
		this.vCategory = vCategory;
	}

	public String getVoicePubtime() {
		return voicePubtime;
	}

	public void setVoicePubtime(String voicePubtime) {
		this.voicePubtime = voicePubtime;
	}

	public Integer getSupport() {
		return support;
	}

	public void setSupport(Integer support) {
		this.support = support;
	}

	public Integer getUnlike() {
		return unlike;
	}

	public void setUnlike(Integer unlike) {
		this.unlike = unlike;
	}

	public Integer getGift() {
		return gift;
	}

	public void setGift(Integer gift) {
		this.gift = gift;
	}

	public Integer getComment() {
		return comment;
	}

	public void setComment(Integer comment) {
		this.comment = comment;
	}

	public Integer getShare() {
		return share;
	}

	public void setShare(Integer share) {
		this.share = share;
	}

	public Integer getvTime() {
		return vTime;
	}

	public void setvTime(Integer vTime) {
		this.vTime = vTime;
	}

	public Integer getvPeroflisen() {
		return vPeroflisen;
	}

	public void setvPeroflisen(Integer vPeroflisen) {
		this.vPeroflisen = vPeroflisen;
	}

	public Integer getvRate() {
		return vRate;
	}

	public void setvRate(Integer vRate) {
		this.vRate = vRate;
	}

	public String getVoiceUrl() {
		return voiceUrl;
	}

	public void setVoiceUrl(String voiceUrl) {
		this.voiceUrl = voiceUrl;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}
    public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public List<CommentVO> getCommentList() {
		return commentList;
	}

	public void setCommentList(List<CommentVO> commentList) {
		this.commentList = commentList;
	}
    
    

}
