package cn.tt.dao;

import cn.tt.bean.DynamicState;
import cn.tt.bean.DynamicStateExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DynamicStateMapper {
    long countByExample(DynamicStateExample example);

    int deleteByExample(DynamicStateExample example);

    int deleteByPrimaryKey(String stateid);

    int insert(DynamicState record);

    int insertSelective(DynamicState record);

    List<DynamicState> selectByExample(DynamicStateExample example);

    DynamicState selectByPrimaryKey(String stateid);

    int updateByExampleSelective(@Param("record") DynamicState record, @Param("example") DynamicStateExample example);

    int updateByExample(@Param("record") DynamicState record, @Param("example") DynamicStateExample example);

    int updateByPrimaryKeySelective(DynamicState record);

    int updateByPrimaryKey(DynamicState record);
    int selectSupportByUser(@Param("dynamicid") String dynamicid, @Param("accountid") String accountid);
    int selectUnlikeByUser(@Param("dynamicid") String dynamicid, @Param("accountid") String accountid);
    int selectStateByUser(@Param("dynamicid") String dynamicid, @Param("accountid") String accountid);
    
}