package cn.tt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Account;
import cn.tt.bean.AccountExample;
import cn.tt.bean.User_info;
import cn.tt.bean.Wallet;
import cn.tt.dao.AccountMapper;
import cn.tt.dao.User_infoMapper;
import cn.tt.dao.WalletMapper;
import cn.tt.utils.BaseUtil;

@Service
public class LoginService {
	@Autowired
	private AccountMapper accountMapper;
	//自动绑定，相当于：AccountMapper mapper=session.getMapper(AccountMapper.class);
	
	@Autowired
	private User_infoMapper user_infoMapper;
	
	@Autowired
	private WalletMapper walletMapper;
	
	public Account getAccount(String username,String password){
		String mdPass = BaseUtil.MD5(password);
		AccountExample example = new AccountExample();
		example.createCriteria().andUsernameEqualTo(username).andPasswordEqualTo(mdPass);
		List<Account> list = accountMapper.selectByExample(example);
		if(list == null || list.size() == 0)
			return null;
		else
			return list.get(0);
	}
	
	public Account getAccount(String username){
		AccountExample example = new AccountExample();
		example.createCriteria().andUsernameEqualTo(username);
		List<Account> list = accountMapper.selectByExample(example);
		if(list == null || list.size() == 0)
			return null;
		else
			return list.get(0);
	}
	
	public User_info register(String username, String password, String sex, String nickname, String age,String relation){
		Account account = new Account();
		account.setUsername(username);
		account.setPassword(BaseUtil.MD5(password));;
		String str = accountMapper.selectMaxAccountid();
		String newStr = String.valueOf(((Integer.parseInt(str))+1));
		int count = 8-newStr.length();
		StringBuilder b = new StringBuilder();
		for(int i = 0; i < count; i++)
			b.append(0);
		b.append(newStr);
		account.setAccountid(b.toString());
		accountMapper.insert(account);
		/*
		 * <select id="selectMaxAccountid" resultType="String">
  			select max(accountid) from account;
  			</select>
		 */
		AccountExample example = new AccountExample();
		example.createCriteria().andUsernameEqualTo(username);
		List<Account> list = accountMapper.selectByExample(example);
		String accountid = null;
		if(list != null && list.size() != 0)
			accountid = list.get(0).getAccountid();
		String profile = BaseUtil.getPictureUrl(accountid)+"/profile.jpg";
		User_info user_info = new User_info();
		user_info.setAccountId(accountid);
		user_info.setSex(Byte.valueOf(sex));
		user_info.setName(nickname);
		user_info.setAge(Integer.valueOf(age));
		user_info.setProfile(profile);
		user_info.setRelation(relation);
		user_info.setFanscount(0);
		user_info.setFriendcount(0);
		user_info.setFollwcount(0);
		user_info.setGiftcount(0);
		user_infoMapper.insert(user_info);
		
		Wallet wallet = new Wallet();
		wallet.setAccountId(accountid);
		wallet.setChatcount(0);
		wallet.setIntegral(0);
		wallet.setRewardcount(0);
		wallet.setSharecount(0);
		wallet.setSigncount(0);
		wallet.setSincerity(0);
		walletMapper.insert(wallet);
		return user_info;
	}
}
