package cn.tt.utils;

public class MyProp {
	public static final String serverIP= "192.168.191.4";
	public static final String serverPort= "34098";
	public static final String serverName= "TT";
	public static final String urlPrefix="http://"+MyProp.serverIP+":"+MyProp.serverPort+"/"+MyProp.serverName;
	public static final String baseDir = "F:\\TT";
	//public static final String baseDir = "E:\\TTresouce\\";
	public static final String baseUserPictureUrl = baseDir+"picture\\user";
	public static final String baseGiftPictureUrl = baseDir+"picture\\gift";
	public static final String baseDynamicPictureUrl = baseDir+"picture\\dynamic";
	public static final String baseVoicePictureUrl = baseDir+"voice\\voicesource";
	public static final String baseAlbumPictureUrl = baseDir+"picture\\album";
	public static final String baseAlipayUrl = baseDir + "txtfile";
	//一元1000积分
		public static final Double IntegralTime = 1000.0;
	public static final String appSecret = "1A7ZV9tt1ifK";
	public static final String appKey = "25wehl3u29hvw";
}
