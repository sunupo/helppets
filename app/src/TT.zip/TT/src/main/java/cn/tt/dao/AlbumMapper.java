package cn.tt.dao;

import cn.tt.bean.Album;
import cn.tt.bean.AlbumExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.junit.runners.Parameterized.Parameters;

public interface AlbumMapper {
    long countByExample(AlbumExample example);

    int deleteByExample(AlbumExample example);

    int deleteByPrimaryKey(String albumid);

    int insert(Album record);

    int insertSelective(Album record);

    List<Album> selectByExample(AlbumExample example);

    Album selectByPrimaryKey(String albumid);

    int updateByExampleSelective(@Param("record") Album record, @Param("example") AlbumExample example);

    int updateByExample(@Param("record") Album record, @Param("example") AlbumExample example);

    int updateByPrimaryKeySelective(Album record);

    int updateByPrimaryKey(Album record);
    
    List<Album> selectAlbumsByUser(String accountId);

    List<Album> selectFreeAlbums(@Param("accountId") String accountId);
    
    List<Album> selectVipFreeAlbums(String accountId);
    
    List<Album> selectChargeAlbums(String accountId);

    
}