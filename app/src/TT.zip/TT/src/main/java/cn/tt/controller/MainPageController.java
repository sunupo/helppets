package cn.tt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Comment;
import cn.tt.bean.Information;
import cn.tt.bean.Msg;
import cn.tt.bean.User_info;
import cn.tt.dao.CommentMapper;
import cn.tt.service.InformationService;
import cn.tt.service.UserService;
import cn.tt.utils.InformationComment;
import cn.tt.utils.InformationWrapper;
/*
 * 九宫格controller
 */
@Controller
@RequestMapping("/mainpage")
public class MainPageController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private InformationService informationService;
	
	//九宫格主页得到用户信息
	@ResponseBody
	@RequestMapping("/getuser")
	public Msg getUser(@RequestParam(value="relation",defaultValue = "all") String relation,
			@RequestParam(value="city",defaultValue = "all") String city,
			@RequestParam(value = "start",defaultValue = "18") String start,
			@RequestParam(value = "end",defaultValue = "100") String end){
		List<List<User_info>> list = userService.getMainUserInfo(relation,city,Integer.parseInt(start),Integer.parseInt(end));
		if(list == null || list.size() == 0)
			return Msg.fail();
		else
			return Msg.success().add("list", list);
	}
	
	//得到用户被评论的消息列表
	@ResponseBody
	@RequestMapping(value="/getComments/{accountid}/{offset}/{limit}")
	public Msg getConments(@PathVariable("accountid") String accountid,
			@PathVariable("offset") int offset,
			@PathVariable("limit") int limit){
		List<InformationComment> comments = informationService.getComments(accountid, offset, limit);
		if(comments == null)
			return Msg.fail();
		else
			return Msg.success().add("comments", comments);
	}
	
	//根据type类型得到用户消息
	@ResponseBody
	@RequestMapping(value="/getInformation/{accountid}/{type}/{offset}/{limit}")
	public Msg getInformations(@PathVariable("accountid") String accountid,
			@PathVariable("type") int type,
			@PathVariable("offset") int offset,
			@PathVariable("limit") int limit){
		List<InformationWrapper> infos = null;
		//所有消息
		if(type == -1)
			infos = informationService.getAllInformation(accountid, offset, limit);
		else
			infos = informationService.getAllInformation(accountid, type,offset, limit);
		if(infos == null)
			return Msg.fail();
		else
			return Msg.success().add("infos", infos);
	}
}
