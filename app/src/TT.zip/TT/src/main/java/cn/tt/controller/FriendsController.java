package cn.tt.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.tt.bean.Msg;
import cn.tt.service.FriendsService;
/*
 * 好友controller
 */
@Controller
@RequestMapping("/friends")
public class FriendsController {
	@Autowired
	private FriendsService friendsService;
	
	/**
	 * localhost:8080/TT/friends/isVipFriends?accountid=00000001&friendid=00000003
	 * @param accountid
	 * @param friendid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/isVipFriends")
	public Msg isVipFriends(@RequestParam("accountid") String accountid,@RequestParam("friendid") String friendid) {
		boolean res = friendsService.isVipFriend(accountid, friendid);
		return Msg.success().add("res", res);
	}

}
