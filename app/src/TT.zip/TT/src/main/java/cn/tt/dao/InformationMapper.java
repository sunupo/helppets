package cn.tt.dao;

import cn.tt.bean.Comment;
import cn.tt.bean.Information;
import cn.tt.bean.InformationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface InformationMapper {
    long countByExample(InformationExample example);

    int deleteByExample(InformationExample example);

    int insert(Information record);

    int insertSelective(Information record);

    List<Information> selectByExample(InformationExample example);

    int updateByExampleSelective(@Param("record") Information record, @Param("example") InformationExample example);

    int updateByExample(@Param("record") Information record, @Param("example") InformationExample example);
    
    @Select("select * from information where toid = #{accountId} and type = #{type} order by releasedate limit #{offset},#{limit}")
    List<Information> getLimitTypeInformation(@Param("accountId") String accountId,@Param("type") int type,@Param("offset") int offset,@Param("limit") int limit);

    @Select("select * from information where toid = #{accountId} order by releasedate limit #{offset},#{limit}")
    List<Information> getLimitInformation(@Param("accountId") String accountId,@Param("offset") int offset,@Param("limit") int limit);
}