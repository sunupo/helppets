package cn.tt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.DynamicState;
import cn.tt.bean.Msg;
import cn.tt.dao.DynamicStateMapper;

@Service
public class DynamicStateService {
	@Autowired
	private DynamicStateMapper stateMapper;
	
	public Msg addDynamicState(DynamicState state){
		int count = stateMapper.selectStateByUser(state.getDynamicid(), state.getAccountid());
		if ( count == 0 ){
			if (stateMapper.insert(state) > 0)
				return Msg.success();
			else
				return Msg.fail().add("msg", "失败");
		}
		else{
			return Msg.fail().add("msg", "你已经点过了");
		}
	}
}
