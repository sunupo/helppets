package cn.tt.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Friends;
import cn.tt.bean.FriendsExample;
import cn.tt.bean.FriendsKey;
import cn.tt.bean.Information;
import cn.tt.bean.InformationExample;
import cn.tt.bean.User_info;
import cn.tt.dao.FriendsMapper;
import cn.tt.dao.InformationMapper;
import cn.tt.dao.User_infoMapper;

@Service
public class FriendsService {
	@Autowired
	private FriendsMapper friendsMapper;

	@Autowired
	private User_infoMapper user_infoMapper;

	@Autowired
	private InformationMapper informationMapper;

	public List<Friends> getFriends(String accountid, int frienditem) {
		FriendsExample friendsExample = new FriendsExample();
		friendsExample.createCriteria().andAccountidEqualTo(accountid).andFrienditemEqualTo(frienditem);
		List<Friends> friends = friendsMapper.selectByExample(friendsExample);
		return friends;
	}

	public List<User_info> getFriendsInfo(String accountid, int frienditem) {
		List<Friends> friends = getFriends(accountid, frienditem);
		List<User_info> friendsInfo = new ArrayList<User_info>();
		for (Friends friend : friends) {
			User_info user = user_infoMapper.selectByPrimaryKey(friend.getFriendid());
			friendsInfo.add(user);
		}
		return friendsInfo;
	}
	/*
	 * public List<Recent_connect> getRecentConnectFriends(String accountid){
	 * Recent_connectExample example = new Recent_connectExample();
	 * example.createCriteria().andAccountIdEqualTo(accountid);
	 * List<Recent_connect> lists =
	 * recent_connectMapper.selectByExample(example); return lists; }
	 * 
	 * public List<User_info> getRecentFriendsInfo(String accountid){
	 * List<Recent_connect> lists = getRecentConnectFriends(accountid);
	 * List<User_info> recentFriendsInfo = new ArrayList<User_info>();
	 * for(Recent_connect recent_connect : lists){ User_info user =
	 * user_infoMapper.selectByPrimaryKey(recent_connect.getFriendId());
	 * recentFriendsInfo.add(user); } return recentFriendsInfo; }
	 */

	public boolean isVipFriend(String accountid, String friendid) {
		FriendsKey key = new FriendsKey();
		key.setAccountid(accountid);
		key.setFriendid(friendid);
		Friends friends = friendsMapper.selectByPrimaryKey(key);
		System.out.println("===" + friends);
		if (friends != null && friends.getType() == 2) {
			return true;
		} else
			return false;
	}

	public long getFollowCount(String accountid) {
		FriendsExample example = new FriendsExample();
		example.createCriteria().andAccountidEqualTo(accountid).andFrienditemEqualTo(1);
		return friendsMapper.countByExample(example);
	}

	public long getFansCount(String accountid) {
		FriendsExample example = new FriendsExample();
		example.createCriteria().andAccountidEqualTo(accountid).andFrienditemEqualTo(2);
		return friendsMapper.countByExample(example);
	}

	public long getFriendsCount(String accountid) {
		FriendsExample example = new FriendsExample();
		example.createCriteria().andAccountidEqualTo(accountid).andFrienditemEqualTo(0);
		return friendsMapper.countByExample(example);
	}

	public long hasFollow(String accountid, String otherid) {
		FriendsExample example = new FriendsExample();
		example.createCriteria().andAccountidEqualTo(accountid).andFriendidEqualTo(otherid).andFrienditemBetween(0, 1);
		return friendsMapper.countByExample(example);
	}

	public int follow(String accountid, String friendid) {
		FriendsKey key = new FriendsKey();
		key.setFriendid(accountid);
		key.setAccountid(friendid);
		Friends friends = friendsMapper.selectByPrimaryKey(key);
		if (friends == null) {
			Friends newFriends = new Friends();
			newFriends.setAccountid(accountid);
			newFriends.setFriendid(friendid);
			newFriends.setFrienditem(1);
			// 消息表中插入一条数据
			/*
			 * Information information = null; InformationExample
			 * informationExample = new InformationExample();
			 * informationExample.createCriteria().andActoridEqualTo(accountid).
			 * andToidEqualTo(friendid); List<Information> informationLists =
			 * informationMapper.selectByExample(informationExample);
			 * if(informationLists != null){ information =
			 * informationLists.get(0); information.setReleasedate(new Date());
			 * informationMapper.updateByExample(information,
			 * informationExample); }
			 */
			Information information = new Information();
			information.setActorid(accountid);
			information.setToid(friendid);
			information.setReleasedate(new Date());
			// 1为关注消息
			information.setType(1);
			return friendsMapper.insert(newFriends) & informationMapper.insert(information);
		} else if (friends.getFrienditem() == 1) {
			friends.setFrienditem(0);
			Friends newFriends = new Friends();
			newFriends.setAccountid(accountid);
			newFriends.setFriendid(friendid);
			newFriends.setFrienditem(0);
			friendsMapper.updateByPrimaryKey(friends);
			return friendsMapper.updateByPrimaryKey(newFriends);
		}
		return -1;
	}
}
