package cn.tt.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.test.annotation.Rollback;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tt.bean.Dynamic;
import cn.tt.bean.Msg;
import cn.tt.bean.VoiComment;
import cn.tt.bean.Voicedy;
import cn.tt.bean.view.DynamicVO;
import cn.tt.bean.view.VoicedyVO;
import cn.tt.service.VoiceService;
import cn.tt.utils.MyProp;

@Controller
@RequestMapping("/voice")
public class VoiceController {
	@Autowired
	private VoiceService voiceService;

	private String baseVoicePictureUrl = MyProp.baseVoicePictureUrl;

	@ResponseBody
	@RequestMapping("/voiceforid/{voiceId}")
	public Msg getVoice(@PathVariable("voiceId") String voiceId) {
		Voicedy voicedy = voiceService.getVoicedyById(voiceId);
		if (voicedy != null)
			return Msg.success().add("voicedy", voicedy);
		else {
			return Msg.fail();
		}
	}
	/**
	 * �����û�ID��ȡ���û���ȫ��������̬
	 * @param accountId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/voiceallbyuserid/{accountId}")
	public Msg getAllVoiceById(@PathVariable("accountId") String accountId) {
		List<VoicedyVO> allVoice = voiceService.getAllVoiveVOByUserID(accountId);
		if (allVoice != null) {
			return Msg.success().add("allVoice", allVoice);
		} else {
			return Msg.fail();
		}
	}

	@ResponseBody
	@RequestMapping("/voiceallVO")
	public Msg getAllVoiceVO() {
		List<VoicedyVO> allVoice = voiceService.getAllVoicedyVO();
		if (allVoice != null) {
			return Msg.success().add("allVoice", allVoice);
		} else {
			return Msg.fail();
		}
	}

	/**
	 * ���ò��û�ã��õ������test2
	 * http://localhost:8080/TT/voice/voiceSource/voice?url=/00/00/00/01/
	 * 1804251700.mp3 D:\TTvip\voice\voicesource\00\00\00\01
	 */
	@RequestMapping("/voiceSource/voice")
	public void test(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "url") String url) {
		FileInputStream in = null;
		FileOutputStream out = null;
		BufferedInputStream bufis = null;
		BufferedOutputStream bufos = null;
		try {
			if (!url.equals("null") && url != null) {// ����̬û������ʱ��ִ�л�ȡ��������ֹ�ļ��Ҳ����쳣

				in = new FileInputStream(baseVoicePictureUrl + url);
				bufis = new BufferedInputStream(in);
				bufos = new BufferedOutputStream(response.getOutputStream());

				byte[] data = new byte[bufis.available()];
				int size = 0;
				while ((size = bufis.read(data)) != -1) {
					bufos.write(size);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (bufis != null)
					bufis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (bufos != null)
					bufos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	/**
	 * �ϴ������ļ�
	 * @param request
	 * @param response
	 * @param url
	 */
	@RequestMapping("/voiceSource/voice1")
	public void test2(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "url") String url) {
		try {
			if (!url.equals("null") && url != null) {
				System.out.println("++++++"+url);
				FileInputStream in;
				in = new FileInputStream(baseVoicePictureUrl + url);
				int i = in.available();
				byte[] data = new byte[i];
				in.read(data);
				in.close();

				OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
				outputStream.write(data);
				outputStream.flush();
				outputStream.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * ��������
	 * @param voicedy
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/postVoicedy")
	public Msg postVoice(Voicedy voicedy) {
		System.out.println(voicedy);
		int state = voiceService.insertOneVoice(voicedy);
		if (state == 1) {
			return Msg.success();
		}else {
			return Msg.fail();
		}
	}
	/**
	 * ��������
	 * account=00000002&commnetAccount=00000001&voicedyId=0000000220001&content=ҡ����
	 * @param voiComment
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/postVoComment")
	public Msg postVoiComment(VoiComment voiComment){
		System.out.println(voiComment);
		int state = voiceService.insertOneVoComment(voiComment);
		if (state == 1) {
			return Msg.success();
		}else {
			return Msg.fail();
		}
	}
	
	/**
	 * ����
	 * @param voicedy
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/updateVoicedy")
	@Rollback(false)
	public Msg updateVoice(Voicedy voicedy) {
		System.out.println(voicedy);
		int state = voiceService.updateCount(voicedy);
		System.out.println(state);
		if (state == 1) {
			return Msg.success();
		}else {
			return Msg.fail();
		}
	}

}
