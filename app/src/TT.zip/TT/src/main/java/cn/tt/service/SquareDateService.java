package cn.tt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.tt.bean.Publishdate;
import cn.tt.bean.PublishdateExample;
import cn.tt.bean.PublishdateExample.Criteria;
import cn.tt.bean.User_info;
import cn.tt.dao.PublishdateMapper;
import cn.tt.dao.User_infoMapper;
import cn.tt.dao.WalletMapper;
import cn.tt.utils.MyDateWrapper;
import cn.tt.utils.SquareDateWraper;

@Service
public class SquareDateService {
	@Autowired
	private PublishdateMapper publishdateMapper;

	@Autowired
	private User_infoMapper user_infoMapper;

	@Autowired
	private WalletService walletService;

	public List<SquareDateWraper> getDates() {
		PublishdateExample example = new PublishdateExample();
		Criteria criteria = example.createCriteria();
		criteria.andReceiveIdEqualTo("-1");
		List<Publishdate> list = publishdateMapper.selectByExample(example);
		List<SquareDateWraper> newList = new ArrayList<SquareDateWraper>();
		for (Publishdate date : list) {
			SquareDateWraper wraper = new SquareDateWraper();
			User_info user = user_infoMapper.selectByPrimaryKey(date.getInviteId());
			wraper.setAge(user.getAge());
			wraper.setdId(date.getdId());
			wraper.setHight(user.getHight());
			wraper.setInviteId(date.getInviteId());
			wraper.setLocation(date.getLocation());
			wraper.setName(user.getName());
			wraper.setProfile(user.getProfile());
			wraper.setSex(user.getSex());
			wraper.setTheme(date.getTheme());
			wraper.setTime(date.getTime());
			wraper.setWeight(user.getWeight());
			wraper.setMaintext(date.getMaintext());
			wraper.setMainpicture(date.getMainpicture());
			wraper.setDatefortime(date.getDatefortime());
			wraper.setIntegral(date.getIntegral());
			wraper.setSincirity(date.getSincirity());
			newList.add(wraper);
		}
		return newList;
	}

	public List<MyDateWrapper> getInviteDates(String inviteid, String receiveid) {
		PublishdateExample example = new PublishdateExample();
		Criteria criteria = example.createCriteria();
		// invited不等于-1说明查的是发起者
		if (!inviteid.equals("-1"))
			criteria.andInviteIdEqualTo(inviteid);
		else
			criteria.andReceiveIdEqualTo(receiveid);
		List<Publishdate> list = publishdateMapper.selectByExample(example);
		List<MyDateWrapper> newList = new ArrayList<MyDateWrapper>();
		for (Publishdate date : list) {
			MyDateWrapper wraper = new MyDateWrapper();
			User_info user = null;
			if (inviteid.equals("-1"))
				user = user_infoMapper.selectByPrimaryKey(date.getInviteId());
			else
				user = user_infoMapper.selectByPrimaryKey(date.getReceiveId());
			wraper.setdId(date.getdId());
			wraper.setInviteId(date.getInviteId());
			wraper.setReceiveId(date.getReceiveId());
			wraper.setLocation(date.getLocation());
			if (user != null) {
				wraper.setName(user.getName());
				wraper.setProfile(user.getProfile());
			} else {
				wraper.setName("未报名");
				wraper.setProfile("");
			}
			wraper.setTheme(date.getTheme());
			wraper.setMaintext(date.getMaintext());
			wraper.setMainpicture(date.getMainpicture());
			wraper.setDatefortime(date.getDatefortime());
			wraper.setIntegral(date.getIntegral());
			wraper.setSincirity(date.getSincirity());
			newList.add(wraper);
		}
		return newList;
	}

	public int signDate(String accountid, String friendid, int num, int did) {
		boolean isEnough = walletService.integralEnough(accountid, friendid, num);
		// -1表示积分不够
		if (!isEnough)
			return -1;
		Publishdate date = publishdateMapper.selectByPrimaryKey(did);
		date.setReceiveId(accountid);
		publishdateMapper.updateByPrimaryKey(date);
		return 1;
	}

	public boolean cancalDate(String accountid, String friendid, int num, int did) {
		// 如果没人报名，直接取消
		if (friendid.equals("-1"))
			publishdateMapper.deleteByPrimaryKey(did);
		else {
			// 如果有人报名，将诚意分退回
			boolean isEnough = walletService.integralEnough(accountid, friendid, num);
			if (!isEnough)
				return false;
			publishdateMapper.deleteByPrimaryKey(did);
		}
		return true;
	}

	public boolean cancalReceiveDate(String accountid, String friendid, int num, int did) {
		boolean isEnough = walletService.integralEnough(friendid, accountid, num);
		if (!isEnough)
			return false;
		Publishdate date = publishdateMapper.selectByPrimaryKey(did);
		date.setReceiveId("-1");
		publishdateMapper.updateByPrimaryKey(date);
		return true;
	}
}
