package com.servlet.bean;

import java.util.ArrayList;
import java.util.List;

public class ApplyExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ApplyExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFromuidIsNull() {
            addCriterion("fromuid is null");
            return (Criteria) this;
        }

        public Criteria andFromuidIsNotNull() {
            addCriterion("fromuid is not null");
            return (Criteria) this;
        }

        public Criteria andFromuidEqualTo(Integer value) {
            addCriterion("fromuid =", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidNotEqualTo(Integer value) {
            addCriterion("fromuid <>", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidGreaterThan(Integer value) {
            addCriterion("fromuid >", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidGreaterThanOrEqualTo(Integer value) {
            addCriterion("fromuid >=", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidLessThan(Integer value) {
            addCriterion("fromuid <", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidLessThanOrEqualTo(Integer value) {
            addCriterion("fromuid <=", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidIn(List<Integer> values) {
            addCriterion("fromuid in", values, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidNotIn(List<Integer> values) {
            addCriterion("fromuid not in", values, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidBetween(Integer value1, Integer value2) {
            addCriterion("fromuid between", value1, value2, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidNotBetween(Integer value1, Integer value2) {
            addCriterion("fromuid not between", value1, value2, "fromuid");
            return (Criteria) this;
        }

        public Criteria andTouidIsNull() {
            addCriterion("touid is null");
            return (Criteria) this;
        }

        public Criteria andTouidIsNotNull() {
            addCriterion("touid is not null");
            return (Criteria) this;
        }

        public Criteria andTouidEqualTo(Integer value) {
            addCriterion("touid =", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidNotEqualTo(Integer value) {
            addCriterion("touid <>", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidGreaterThan(Integer value) {
            addCriterion("touid >", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidGreaterThanOrEqualTo(Integer value) {
            addCriterion("touid >=", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidLessThan(Integer value) {
            addCriterion("touid <", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidLessThanOrEqualTo(Integer value) {
            addCriterion("touid <=", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidIn(List<Integer> values) {
            addCriterion("touid in", values, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidNotIn(List<Integer> values) {
            addCriterion("touid not in", values, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidBetween(Integer value1, Integer value2) {
            addCriterion("touid between", value1, value2, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidNotBetween(Integer value1, Integer value2) {
            addCriterion("touid not between", value1, value2, "touid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNull() {
            addCriterion("dynamicid is null");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNotNull() {
            addCriterion("dynamicid is not null");
            return (Criteria) this;
        }

        public Criteria andDynamicidEqualTo(Integer value) {
            addCriterion("dynamicid =", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotEqualTo(Integer value) {
            addCriterion("dynamicid <>", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThan(Integer value) {
            addCriterion("dynamicid >", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThanOrEqualTo(Integer value) {
            addCriterion("dynamicid >=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThan(Integer value) {
            addCriterion("dynamicid <", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThanOrEqualTo(Integer value) {
            addCriterion("dynamicid <=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIn(List<Integer> values) {
            addCriterion("dynamicid in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotIn(List<Integer> values) {
            addCriterion("dynamicid not in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidBetween(Integer value1, Integer value2) {
            addCriterion("dynamicid between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotBetween(Integer value1, Integer value2) {
            addCriterion("dynamicid not between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andApplytimeIsNull() {
            addCriterion("applyTime is null");
            return (Criteria) this;
        }

        public Criteria andApplytimeIsNotNull() {
            addCriterion("applyTime is not null");
            return (Criteria) this;
        }

        public Criteria andApplytimeEqualTo(String value) {
            addCriterion("applyTime =", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeNotEqualTo(String value) {
            addCriterion("applyTime <>", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeGreaterThan(String value) {
            addCriterion("applyTime >", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeGreaterThanOrEqualTo(String value) {
            addCriterion("applyTime >=", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeLessThan(String value) {
            addCriterion("applyTime <", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeLessThanOrEqualTo(String value) {
            addCriterion("applyTime <=", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeLike(String value) {
            addCriterion("applyTime like", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeNotLike(String value) {
            addCriterion("applyTime not like", value, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeIn(List<String> values) {
            addCriterion("applyTime in", values, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeNotIn(List<String> values) {
            addCriterion("applyTime not in", values, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeBetween(String value1, String value2) {
            addCriterion("applyTime between", value1, value2, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplytimeNotBetween(String value1, String value2) {
            addCriterion("applyTime not between", value1, value2, "applytime");
            return (Criteria) this;
        }

        public Criteria andApplystatusIsNull() {
            addCriterion("applyStatus is null");
            return (Criteria) this;
        }

        public Criteria andApplystatusIsNotNull() {
            addCriterion("applyStatus is not null");
            return (Criteria) this;
        }

        public Criteria andApplystatusEqualTo(Integer value) {
            addCriterion("applyStatus =", value, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusNotEqualTo(Integer value) {
            addCriterion("applyStatus <>", value, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusGreaterThan(Integer value) {
            addCriterion("applyStatus >", value, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("applyStatus >=", value, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusLessThan(Integer value) {
            addCriterion("applyStatus <", value, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusLessThanOrEqualTo(Integer value) {
            addCriterion("applyStatus <=", value, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusIn(List<Integer> values) {
            addCriterion("applyStatus in", values, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusNotIn(List<Integer> values) {
            addCriterion("applyStatus not in", values, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusBetween(Integer value1, Integer value2) {
            addCriterion("applyStatus between", value1, value2, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplystatusNotBetween(Integer value1, Integer value2) {
            addCriterion("applyStatus not between", value1, value2, "applystatus");
            return (Criteria) this;
        }

        public Criteria andApplycontentIsNull() {
            addCriterion("applyContent is null");
            return (Criteria) this;
        }

        public Criteria andApplycontentIsNotNull() {
            addCriterion("applyContent is not null");
            return (Criteria) this;
        }

        public Criteria andApplycontentEqualTo(String value) {
            addCriterion("applyContent =", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentNotEqualTo(String value) {
            addCriterion("applyContent <>", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentGreaterThan(String value) {
            addCriterion("applyContent >", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentGreaterThanOrEqualTo(String value) {
            addCriterion("applyContent >=", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentLessThan(String value) {
            addCriterion("applyContent <", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentLessThanOrEqualTo(String value) {
            addCriterion("applyContent <=", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentLike(String value) {
            addCriterion("applyContent like", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentNotLike(String value) {
            addCriterion("applyContent not like", value, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentIn(List<String> values) {
            addCriterion("applyContent in", values, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentNotIn(List<String> values) {
            addCriterion("applyContent not in", values, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentBetween(String value1, String value2) {
            addCriterion("applyContent between", value1, value2, "applycontent");
            return (Criteria) this;
        }

        public Criteria andApplycontentNotBetween(String value1, String value2) {
            addCriterion("applyContent not between", value1, value2, "applycontent");
            return (Criteria) this;
        }

        public Criteria andResponsetimeIsNull() {
            addCriterion("responseTime is null");
            return (Criteria) this;
        }

        public Criteria andResponsetimeIsNotNull() {
            addCriterion("responseTime is not null");
            return (Criteria) this;
        }

        public Criteria andResponsetimeEqualTo(String value) {
            addCriterion("responseTime =", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeNotEqualTo(String value) {
            addCriterion("responseTime <>", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeGreaterThan(String value) {
            addCriterion("responseTime >", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeGreaterThanOrEqualTo(String value) {
            addCriterion("responseTime >=", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeLessThan(String value) {
            addCriterion("responseTime <", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeLessThanOrEqualTo(String value) {
            addCriterion("responseTime <=", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeLike(String value) {
            addCriterion("responseTime like", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeNotLike(String value) {
            addCriterion("responseTime not like", value, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeIn(List<String> values) {
            addCriterion("responseTime in", values, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeNotIn(List<String> values) {
            addCriterion("responseTime not in", values, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeBetween(String value1, String value2) {
            addCriterion("responseTime between", value1, value2, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsetimeNotBetween(String value1, String value2) {
            addCriterion("responseTime not between", value1, value2, "responsetime");
            return (Criteria) this;
        }

        public Criteria andResponsecontentIsNull() {
            addCriterion("responseContent is null");
            return (Criteria) this;
        }

        public Criteria andResponsecontentIsNotNull() {
            addCriterion("responseContent is not null");
            return (Criteria) this;
        }

        public Criteria andResponsecontentEqualTo(String value) {
            addCriterion("responseContent =", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentNotEqualTo(String value) {
            addCriterion("responseContent <>", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentGreaterThan(String value) {
            addCriterion("responseContent >", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentGreaterThanOrEqualTo(String value) {
            addCriterion("responseContent >=", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentLessThan(String value) {
            addCriterion("responseContent <", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentLessThanOrEqualTo(String value) {
            addCriterion("responseContent <=", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentLike(String value) {
            addCriterion("responseContent like", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentNotLike(String value) {
            addCriterion("responseContent not like", value, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentIn(List<String> values) {
            addCriterion("responseContent in", values, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentNotIn(List<String> values) {
            addCriterion("responseContent not in", values, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentBetween(String value1, String value2) {
            addCriterion("responseContent between", value1, value2, "responsecontent");
            return (Criteria) this;
        }

        public Criteria andResponsecontentNotBetween(String value1, String value2) {
            addCriterion("responseContent not between", value1, value2, "responsecontent");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}