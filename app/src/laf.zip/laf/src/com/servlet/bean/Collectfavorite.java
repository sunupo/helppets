package com.servlet.bean;

public class Collectfavorite extends CollectfavoriteKey {
    private String iscollected;

    private String isfavorite;

    public String getIscollected() {
        return iscollected;
    }

    public void setIscollected(String iscollected) {
        this.iscollected = iscollected == null ? null : iscollected.trim();
    }

    public String getIsfavorite() {
        return isfavorite;
    }

    public void setIsfavorite(String isfavorite) {
        this.isfavorite = isfavorite == null ? null : isfavorite.trim();
    }
}