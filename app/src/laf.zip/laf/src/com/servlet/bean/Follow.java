package com.servlet.bean;

public class Follow extends FollowKey {
    private String isfollow;

    public String getIsfollow() {
        return isfollow;
    }

    public void setIsfollow(String isfollow) {
        this.isfollow = isfollow == null ? null : isfollow.trim();
    }
}