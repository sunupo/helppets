package com.servlet.bean;

public class Recommend extends RecommendKey {
    private String isclick;

    public String getIsclick() {
        return isclick;
    }

    public void setIsclick(String isclick) {
        this.isclick = isclick == null ? null : isclick.trim();
    }
}