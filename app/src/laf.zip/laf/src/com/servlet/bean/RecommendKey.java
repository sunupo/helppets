package com.servlet.bean;

public class RecommendKey {
    private Integer userid;

    private Integer relevantuserid;

    private Integer dynamicid;

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getRelevantuserid() {
        return relevantuserid;
    }

    public void setRelevantuserid(Integer relevantuserid) {
        this.relevantuserid = relevantuserid;
    }

    public Integer getDynamicid() {
        return dynamicid;
    }

    public void setDynamicid(Integer dynamicid) {
        this.dynamicid = dynamicid;
    }
}