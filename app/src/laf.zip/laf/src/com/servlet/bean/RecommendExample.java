package com.servlet.bean;

import java.util.ArrayList;
import java.util.List;

public class RecommendExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public RecommendExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUseridIsNull() {
            addCriterion("userid is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("userid is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("userid =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("userid <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("userid >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("userid >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("userid <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("userid <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("userid in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("userid not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("userid between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("userid not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridIsNull() {
            addCriterion("relevantuserid is null");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridIsNotNull() {
            addCriterion("relevantuserid is not null");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridEqualTo(Integer value) {
            addCriterion("relevantuserid =", value, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridNotEqualTo(Integer value) {
            addCriterion("relevantuserid <>", value, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridGreaterThan(Integer value) {
            addCriterion("relevantuserid >", value, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("relevantuserid >=", value, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridLessThan(Integer value) {
            addCriterion("relevantuserid <", value, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridLessThanOrEqualTo(Integer value) {
            addCriterion("relevantuserid <=", value, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridIn(List<Integer> values) {
            addCriterion("relevantuserid in", values, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridNotIn(List<Integer> values) {
            addCriterion("relevantuserid not in", values, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridBetween(Integer value1, Integer value2) {
            addCriterion("relevantuserid between", value1, value2, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andRelevantuseridNotBetween(Integer value1, Integer value2) {
            addCriterion("relevantuserid not between", value1, value2, "relevantuserid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNull() {
            addCriterion("dynamicid is null");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNotNull() {
            addCriterion("dynamicid is not null");
            return (Criteria) this;
        }

        public Criteria andDynamicidEqualTo(Integer value) {
            addCriterion("dynamicid =", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotEqualTo(Integer value) {
            addCriterion("dynamicid <>", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThan(Integer value) {
            addCriterion("dynamicid >", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThanOrEqualTo(Integer value) {
            addCriterion("dynamicid >=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThan(Integer value) {
            addCriterion("dynamicid <", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThanOrEqualTo(Integer value) {
            addCriterion("dynamicid <=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIn(List<Integer> values) {
            addCriterion("dynamicid in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotIn(List<Integer> values) {
            addCriterion("dynamicid not in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidBetween(Integer value1, Integer value2) {
            addCriterion("dynamicid between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotBetween(Integer value1, Integer value2) {
            addCriterion("dynamicid not between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andIsclickIsNull() {
            addCriterion("isclick is null");
            return (Criteria) this;
        }

        public Criteria andIsclickIsNotNull() {
            addCriterion("isclick is not null");
            return (Criteria) this;
        }

        public Criteria andIsclickEqualTo(String value) {
            addCriterion("isclick =", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickNotEqualTo(String value) {
            addCriterion("isclick <>", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickGreaterThan(String value) {
            addCriterion("isclick >", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickGreaterThanOrEqualTo(String value) {
            addCriterion("isclick >=", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickLessThan(String value) {
            addCriterion("isclick <", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickLessThanOrEqualTo(String value) {
            addCriterion("isclick <=", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickLike(String value) {
            addCriterion("isclick like", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickNotLike(String value) {
            addCriterion("isclick not like", value, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickIn(List<String> values) {
            addCriterion("isclick in", values, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickNotIn(List<String> values) {
            addCriterion("isclick not in", values, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickBetween(String value1, String value2) {
            addCriterion("isclick between", value1, value2, "isclick");
            return (Criteria) this;
        }

        public Criteria andIsclickNotBetween(String value1, String value2) {
            addCriterion("isclick not between", value1, value2, "isclick");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}