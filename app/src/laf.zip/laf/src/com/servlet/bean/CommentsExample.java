package com.servlet.bean;

import java.util.ArrayList;
import java.util.List;

public class CommentsExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CommentsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFromuidIsNull() {
            addCriterion("fromuid is null");
            return (Criteria) this;
        }

        public Criteria andFromuidIsNotNull() {
            addCriterion("fromuid is not null");
            return (Criteria) this;
        }

        public Criteria andFromuidEqualTo(Integer value) {
            addCriterion("fromuid =", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidNotEqualTo(Integer value) {
            addCriterion("fromuid <>", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidGreaterThan(Integer value) {
            addCriterion("fromuid >", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidGreaterThanOrEqualTo(Integer value) {
            addCriterion("fromuid >=", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidLessThan(Integer value) {
            addCriterion("fromuid <", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidLessThanOrEqualTo(Integer value) {
            addCriterion("fromuid <=", value, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidIn(List<Integer> values) {
            addCriterion("fromuid in", values, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidNotIn(List<Integer> values) {
            addCriterion("fromuid not in", values, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidBetween(Integer value1, Integer value2) {
            addCriterion("fromuid between", value1, value2, "fromuid");
            return (Criteria) this;
        }

        public Criteria andFromuidNotBetween(Integer value1, Integer value2) {
            addCriterion("fromuid not between", value1, value2, "fromuid");
            return (Criteria) this;
        }

        public Criteria andTouidIsNull() {
            addCriterion("touid is null");
            return (Criteria) this;
        }

        public Criteria andTouidIsNotNull() {
            addCriterion("touid is not null");
            return (Criteria) this;
        }

        public Criteria andTouidEqualTo(Integer value) {
            addCriterion("touid =", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidNotEqualTo(Integer value) {
            addCriterion("touid <>", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidGreaterThan(Integer value) {
            addCriterion("touid >", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidGreaterThanOrEqualTo(Integer value) {
            addCriterion("touid >=", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidLessThan(Integer value) {
            addCriterion("touid <", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidLessThanOrEqualTo(Integer value) {
            addCriterion("touid <=", value, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidIn(List<Integer> values) {
            addCriterion("touid in", values, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidNotIn(List<Integer> values) {
            addCriterion("touid not in", values, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidBetween(Integer value1, Integer value2) {
            addCriterion("touid between", value1, value2, "touid");
            return (Criteria) this;
        }

        public Criteria andTouidNotBetween(Integer value1, Integer value2) {
            addCriterion("touid not between", value1, value2, "touid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNull() {
            addCriterion("dynamicid is null");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNotNull() {
            addCriterion("dynamicid is not null");
            return (Criteria) this;
        }

        public Criteria andDynamicidEqualTo(Integer value) {
            addCriterion("dynamicid =", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotEqualTo(Integer value) {
            addCriterion("dynamicid <>", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThan(Integer value) {
            addCriterion("dynamicid >", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThanOrEqualTo(Integer value) {
            addCriterion("dynamicid >=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThan(Integer value) {
            addCriterion("dynamicid <", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThanOrEqualTo(Integer value) {
            addCriterion("dynamicid <=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIn(List<Integer> values) {
            addCriterion("dynamicid in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotIn(List<Integer> values) {
            addCriterion("dynamicid not in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidBetween(Integer value1, Integer value2) {
            addCriterion("dynamicid between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotBetween(Integer value1, Integer value2) {
            addCriterion("dynamicid not between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andCommentidIsNull() {
            addCriterion("commentid is null");
            return (Criteria) this;
        }

        public Criteria andCommentidIsNotNull() {
            addCriterion("commentid is not null");
            return (Criteria) this;
        }

        public Criteria andCommentidEqualTo(Integer value) {
            addCriterion("commentid =", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidNotEqualTo(Integer value) {
            addCriterion("commentid <>", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidGreaterThan(Integer value) {
            addCriterion("commentid >", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidGreaterThanOrEqualTo(Integer value) {
            addCriterion("commentid >=", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidLessThan(Integer value) {
            addCriterion("commentid <", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidLessThanOrEqualTo(Integer value) {
            addCriterion("commentid <=", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidIn(List<Integer> values) {
            addCriterion("commentid in", values, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidNotIn(List<Integer> values) {
            addCriterion("commentid not in", values, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidBetween(Integer value1, Integer value2) {
            addCriterion("commentid between", value1, value2, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidNotBetween(Integer value1, Integer value2) {
            addCriterion("commentid not between", value1, value2, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentcontentIsNull() {
            addCriterion("commentcontent is null");
            return (Criteria) this;
        }

        public Criteria andCommentcontentIsNotNull() {
            addCriterion("commentcontent is not null");
            return (Criteria) this;
        }

        public Criteria andCommentcontentEqualTo(String value) {
            addCriterion("commentcontent =", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentNotEqualTo(String value) {
            addCriterion("commentcontent <>", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentGreaterThan(String value) {
            addCriterion("commentcontent >", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentGreaterThanOrEqualTo(String value) {
            addCriterion("commentcontent >=", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentLessThan(String value) {
            addCriterion("commentcontent <", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentLessThanOrEqualTo(String value) {
            addCriterion("commentcontent <=", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentLike(String value) {
            addCriterion("commentcontent like", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentNotLike(String value) {
            addCriterion("commentcontent not like", value, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentIn(List<String> values) {
            addCriterion("commentcontent in", values, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentNotIn(List<String> values) {
            addCriterion("commentcontent not in", values, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentBetween(String value1, String value2) {
            addCriterion("commentcontent between", value1, value2, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andCommentcontentNotBetween(String value1, String value2) {
            addCriterion("commentcontent not between", value1, value2, "commentcontent");
            return (Criteria) this;
        }

        public Criteria andIscollectedIsNull() {
            addCriterion("iscollected is null");
            return (Criteria) this;
        }

        public Criteria andIscollectedIsNotNull() {
            addCriterion("iscollected is not null");
            return (Criteria) this;
        }

        public Criteria andIscollectedEqualTo(String value) {
            addCriterion("iscollected =", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedNotEqualTo(String value) {
            addCriterion("iscollected <>", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedGreaterThan(String value) {
            addCriterion("iscollected >", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedGreaterThanOrEqualTo(String value) {
            addCriterion("iscollected >=", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedLessThan(String value) {
            addCriterion("iscollected <", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedLessThanOrEqualTo(String value) {
            addCriterion("iscollected <=", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedLike(String value) {
            addCriterion("iscollected like", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedNotLike(String value) {
            addCriterion("iscollected not like", value, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedIn(List<String> values) {
            addCriterion("iscollected in", values, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedNotIn(List<String> values) {
            addCriterion("iscollected not in", values, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedBetween(String value1, String value2) {
            addCriterion("iscollected between", value1, value2, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIscollectedNotBetween(String value1, String value2) {
            addCriterion("iscollected not between", value1, value2, "iscollected");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteIsNull() {
            addCriterion("isfavorite is null");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteIsNotNull() {
            addCriterion("isfavorite is not null");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteEqualTo(String value) {
            addCriterion("isfavorite =", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteNotEqualTo(String value) {
            addCriterion("isfavorite <>", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteGreaterThan(String value) {
            addCriterion("isfavorite >", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteGreaterThanOrEqualTo(String value) {
            addCriterion("isfavorite >=", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteLessThan(String value) {
            addCriterion("isfavorite <", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteLessThanOrEqualTo(String value) {
            addCriterion("isfavorite <=", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteLike(String value) {
            addCriterion("isfavorite like", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteNotLike(String value) {
            addCriterion("isfavorite not like", value, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteIn(List<String> values) {
            addCriterion("isfavorite in", values, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteNotIn(List<String> values) {
            addCriterion("isfavorite not in", values, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteBetween(String value1, String value2) {
            addCriterion("isfavorite between", value1, value2, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andIsfavoriteNotBetween(String value1, String value2) {
            addCriterion("isfavorite not between", value1, value2, "isfavorite");
            return (Criteria) this;
        }

        public Criteria andViewsIsNull() {
            addCriterion("views is null");
            return (Criteria) this;
        }

        public Criteria andViewsIsNotNull() {
            addCriterion("views is not null");
            return (Criteria) this;
        }

        public Criteria andViewsEqualTo(Integer value) {
            addCriterion("views =", value, "views");
            return (Criteria) this;
        }

        public Criteria andViewsNotEqualTo(Integer value) {
            addCriterion("views <>", value, "views");
            return (Criteria) this;
        }

        public Criteria andViewsGreaterThan(Integer value) {
            addCriterion("views >", value, "views");
            return (Criteria) this;
        }

        public Criteria andViewsGreaterThanOrEqualTo(Integer value) {
            addCriterion("views >=", value, "views");
            return (Criteria) this;
        }

        public Criteria andViewsLessThan(Integer value) {
            addCriterion("views <", value, "views");
            return (Criteria) this;
        }

        public Criteria andViewsLessThanOrEqualTo(Integer value) {
            addCriterion("views <=", value, "views");
            return (Criteria) this;
        }

        public Criteria andViewsIn(List<Integer> values) {
            addCriterion("views in", values, "views");
            return (Criteria) this;
        }

        public Criteria andViewsNotIn(List<Integer> values) {
            addCriterion("views not in", values, "views");
            return (Criteria) this;
        }

        public Criteria andViewsBetween(Integer value1, Integer value2) {
            addCriterion("views between", value1, value2, "views");
            return (Criteria) this;
        }

        public Criteria andViewsNotBetween(Integer value1, Integer value2) {
            addCriterion("views not between", value1, value2, "views");
            return (Criteria) this;
        }

        public Criteria andCommenttimeIsNull() {
            addCriterion("commenttime is null");
            return (Criteria) this;
        }

        public Criteria andCommenttimeIsNotNull() {
            addCriterion("commenttime is not null");
            return (Criteria) this;
        }

        public Criteria andCommenttimeEqualTo(String value) {
            addCriterion("commenttime =", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeNotEqualTo(String value) {
            addCriterion("commenttime <>", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeGreaterThan(String value) {
            addCriterion("commenttime >", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeGreaterThanOrEqualTo(String value) {
            addCriterion("commenttime >=", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeLessThan(String value) {
            addCriterion("commenttime <", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeLessThanOrEqualTo(String value) {
            addCriterion("commenttime <=", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeLike(String value) {
            addCriterion("commenttime like", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeNotLike(String value) {
            addCriterion("commenttime not like", value, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeIn(List<String> values) {
            addCriterion("commenttime in", values, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeNotIn(List<String> values) {
            addCriterion("commenttime not in", values, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeBetween(String value1, String value2) {
            addCriterion("commenttime between", value1, value2, "commenttime");
            return (Criteria) this;
        }

        public Criteria andCommenttimeNotBetween(String value1, String value2) {
            addCriterion("commenttime not between", value1, value2, "commenttime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}