package com.servlet.bean;

public class ReplyKey {
    private Integer fromuid;

    private Integer touid;

    private Integer dynamicid;

    private Integer commentid;

    private Integer replyuid;

    private Integer replyid;

    public Integer getFromuid() {
        return fromuid;
    }

    public void setFromuid(Integer fromuid) {
        this.fromuid = fromuid;
    }

    public Integer getTouid() {
        return touid;
    }

    public void setTouid(Integer touid) {
        this.touid = touid;
    }

    public Integer getDynamicid() {
        return dynamicid;
    }

    public void setDynamicid(Integer dynamicid) {
        this.dynamicid = dynamicid;
    }

    public Integer getCommentid() {
        return commentid;
    }

    public void setCommentid(Integer commentid) {
        this.commentid = commentid;
    }

    public Integer getReplyuid() {
        return replyuid;
    }

    public void setReplyuid(Integer replyuid) {
        this.replyuid = replyuid;
    }

    public Integer getReplyid() {
        return replyid;
    }

    public void setReplyid(Integer replyid) {
        this.replyid = replyid;
    }
}