package com.servlet.utils;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

//request默认采用iso8859-1编码，数据库存储时需要转换为utf-8
public class  StringUtil {
	public static String alterCode(HttpServletRequest req,String parameterName){
		String str="";
		try {
			str=new String(req.getParameter(parameterName).getBytes("iso8859-1"),"utf-8");
			return str;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}

}
