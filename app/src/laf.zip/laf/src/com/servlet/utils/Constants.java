package com.servlet.utils;

public class Constants {
	public static final String UPLOAD_IMAGE_ROOT_PATH="D:/Program Files/apache-tomcat-7.0.88/webapps/laf/dynamicpicture";
	public static final String APP_KEY="mgb7ka1nmd87g";
	public static final String APP_SECRET="a6ro0cyYDJeZo";
	

}
