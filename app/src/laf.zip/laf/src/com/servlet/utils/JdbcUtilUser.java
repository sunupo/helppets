package com.servlet.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtilUser
{
	private static Properties p =null;
	static
	{
		InputStream in = JdbcUtilUser.class.getClassLoader().getResourceAsStream("jdbcInfo.properties");
		p = new Properties();
		try
		{
			p.load(in);
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try
		{
			Class.forName(p.getProperty("driverClassName"));
		}
		catch (ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	public static Connection getConnection() throws SQLException
	{
		return DriverManager.getConnection(p.getProperty("url"), p.getProperty("user"), p.getProperty("psw"));
	}

}