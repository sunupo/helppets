package com.servlet.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//根据用户的输入进行词频统计，然后把输入最多的词语，作为关键字搜索
//根据所有用户的输入的词频
//根据相似用户输入的词频推荐
//根据相似用户的历史让输入推荐
//怎么确定相似用户
public class WordCount {
	 public static void wordCountAndSort() throws IOException {
	        Map<String, Integer> map = new HashMap<String, Integer>();
//	        , "utf-8"
	        
	        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(
	        		(new File("D:/Android/AndroidProject/HelpPets/app/build/outputs/apk/debug/t.txt")))));

	        //每行一个IP，则统计
	        String s = null;
	        while((s=reader.readLine()) != null){
	            if (!map.containsKey(s))
	                map.put(s, 1);
	            else
	                map.put(s, map.get(s)+1);
	        }
	        System.out.println(map);

	        //排序。将Map转为list，然后进行sort
	        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(map.entrySet());
	        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
	            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
	                return o2.getValue().compareTo(o1.getValue());
	            }
	        });
	    }
	 public static void main(String[] args) throws IOException{
		 WordCount.wordCountAndSort();
	 }
}
