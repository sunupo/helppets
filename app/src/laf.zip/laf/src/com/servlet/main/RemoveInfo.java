package com.servlet.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.InfomanageDb;

@SuppressWarnings("serial")
public class RemoveInfo extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	{
		String numTemp = req.getParameter("num");
		int num = Integer.valueOf(numTemp);
		
		try
		{
			int temp=InfomanageDb.infoDelete(num);
			switch(temp)
			{
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("info delete");
				break;
			default:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("info delete wrong");
				break;
			}
			
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
	
}
