package com.servlet.main;

public class InfoList
{
	private int num;
	private String title;
	private String text;
	private String user;
	private int islost;
	
//	public InfoList(int num,String title, String text, String user)
//	{
//		this.num=num;
//		this.title=title;
//		this.text=text;
//		this.user=user;
//	}

	public void setNum(int num)
	{
		this.num=num;
	}
	
	public int getNum()
	{
		return this.num;
	}
	
	public void setTitle(String title)
	{
		this.title=title;
	}
	
	public String getTitle()
	{
		return this.title;
	}
	
	public void setText(String text)
	{
		this.text=text;
	}
	
	public String getText()
	{
		return this.text;
	}
	
	public void setUser(String user)
	{
		this.user=user;
	}
	
	public String getUser()
	{
		return this.user;
	}
	
	public void setIslost(int islost)
	{
		this.islost=islost;
	}
	
	public int getIslost()
	{
		return this.islost;
	}
}
