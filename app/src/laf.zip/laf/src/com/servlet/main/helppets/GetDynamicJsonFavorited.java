package com.servlet.main.helppets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;
import com.servlet.utils.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


/**
 * 由userinfo表和dynamic表，follow表，collect表，favorite表查询得到的
 */
@WebServlet("/getDynamicJsonFavorited")
public class GetDynamicJsonFavorited extends HttpServlet {

		String paraType1="哺乳类";
        String paraType2="猫";
        String paraType3="加菲猫";
        String paraProvince="重庆";
        String paraCity="重庆";
        String paraCreateTime="1970-1-1-0-0-0";
        int limitNumFrom=0;
        int limitNumTo=100;
        String loginName="";
        

      
	/***** servlet: doPost()  *****/
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{//处理json内容
	     
//		从数据库获取json数据返回
		System.out.println("-----------------Dynamic json data----------------------");

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
        response.setContentType("text/json");
        PrintWriter out=response.getWriter();
        
        Connection connection;
        
//        根据loginName得到当前登录用户的login_userid
        int loginUserId=1;

    
//从客户端获取参数
        try{      	
        	        	
        	paraType1=request.getParameter("paraType1");
        	paraType2=request.getParameter("paraType2");
        	paraType3=request.getParameter("paraType3");
        	paraProvince=request.getParameter("paraProvince");
        	paraCity=request.getParameter("paraCity");
        	paraCreateTime=request.getParameter("paraCreateTime");
        	loginName = StringUtil.alterCode(request, "loginName");

     	
        	
        	
//        	limitNumFrom=Integer.parseInt(request.getParameter("limitNumFrom"));
//        	limitNumTo=Integer.parseInt(request.getParameter("limitNumTo"));


        }catch(Exception e){
        	e.printStackTrace();
        }

//        String sql2="select u.userid,u.loginname,d.dynamicid,d.createtime,u.province,u.city,d.content,d.picture,d.type3,d.collected,d.favorite,d.views"+
//        		"from userinfo u inner join dynamic d on u.userid=d.userid ORDER BY d.createtime desc ";
		 
		try {
			connection = JdbcUtilUser.getConnection();
			
	        String sqlLoginUserId="select * from userinfo u where u.loginname=? ";
	        PreparedStatement psLoginUserId=connection.prepareStatement(sqlLoginUserId);
	        psLoginUserId.setString(1, loginName);
	        ResultSet rsLoginUserId= psLoginUserId.executeQuery();
	        while(rsLoginUserId.next()){
	        	loginUserId=rsLoginUserId.getInt(1);
	        }
	        rsLoginUserId.close();
	        psLoginUserId.close();

//	      para:province,city,type1,type2,type3,createTime,limitNumFrom,limitNumTo
//		      String sql="select u.userid,u.loginname,d.dynamicid,d.createtime,u.province,u.city,d.content,d.picture,d.type3,d.collected,d.favorite,d.views "+
//			      		"from userinfo u inner join dynamic d on u.userid=d.userid and u.province like ? "+
//			      		"and u.city like ? and (d.type1 like ? or d.type2 like ? or d.type3 like ?) "+
//			      		"having d.createtime>? ORDER BY d.createtime desc limit ?,?";
//		      String sql="select u.userid,u.loginname,d.dynamicid,d.createtime,u.province,u.city,d.content,d.picture,d.type3,d.collected,d.favorite,d.views "+
//			      		"from userinfo u inner join dynamic d on u.userid=d.userid  and d.type3 like ? ";
		      String sql="select u.loginname,u.logo,u.province,u.city,d.* from userinfo"
		      		+ " u inner join dynamic d on u.userid=d.userid  where d.type3 like ?";
	      
			PreparedStatement psDynamics=connection.prepareStatement(sql);
//			psDynamics.setString(1, "%"+paraProvince+"%");
//			psDynamics.setString(2, "%"+paraCity+"%");
//			psDynamics.setString(3, "%"+paraType1+"%");
//			psDynamics.setString(4, "%"+paraType2+"%");
//			psDynamics.setString(5, "%"+paraType3+"%");
//			psDynamics.setString(6, paraCreateTime);
//			psDynamics.setInt(7, limitNumFrom);
//			psDynamics.setInt(8, limitNumTo);

			psDynamics.setString(1, "%"+paraType3+"%");

			ResultSet rsDynamics= psDynamics.executeQuery();
			
			
	        JSONArray jsonarray = new JSONArray(); 
	        while(rsDynamics.next()){
				JSONObject jsonObject=new JSONObject();
				int userId=rsDynamics.getInt(5);
				jsonObject.put("loginName",rsDynamics.getString(1));
				jsonObject.put("logo",rsDynamics.getString(2));
				jsonObject.put("province",rsDynamics.getString(3));
				jsonObject.put("city",rsDynamics.getString(4));
				jsonObject.put("userId",rsDynamics.getInt(5));
				jsonObject.put("dynamicId",rsDynamics.getInt(6));
				jsonObject.put("isSend",rsDynamics.getString(7));
				jsonObject.put("content",rsDynamics.getString(8));
				jsonObject.put("type1",rsDynamics.getString(9));
				jsonObject.put("type2",rsDynamics.getString(10));
				jsonObject.put("type3",rsDynamics.getString(11));
				jsonObject.put("type4",rsDynamics.getInt(12));
				jsonObject.put("type5",rsDynamics.getString(13));
				jsonObject.put("type6",rsDynamics.getInt(14));
				jsonObject.put("collect",rsDynamics.getInt(15));
				jsonObject.put("favorite",rsDynamics.getInt(16));
				jsonObject.put("views",rsDynamics.getInt(17));
				jsonObject.put("createTime",rsDynamics.getString(18));
				jsonObject.put("picture",rsDynamics.getString(19));
				
				String followFlag="";
				String sqlFollow="select f.isfollow from follow f where fromuid=? and touid=? ";
				PreparedStatement psFollow=connection.prepareStatement(sqlFollow);
				psFollow.setInt(1,loginUserId);
				psFollow.setInt(2, userId);
				ResultSet rsFollow= psFollow.executeQuery();
				while(rsFollow.next()){
					followFlag=rsFollow.getString(1);//得到了这个dynamic用户是否被登陆用户所关注
				}
				rsFollow.close();
				psFollow.close();
				
				jsonObject.put("followFlag", followFlag);
				
				String collectFlag="";
				String favoriteFlag="";
				String sqlCollectFavorite="select c.iscollected,c.isfavorite from collectfavorite c where c.fromUid=? and c.touid=? and c.dynamicid=? ";
				PreparedStatement psCollectFavorite=connection.prepareStatement(sqlCollectFavorite);
				psCollectFavorite.setInt(1,loginUserId);
				psCollectFavorite.setInt(2, userId);
				psCollectFavorite.setInt(3, rsDynamics.getInt(6));
				ResultSet rsCollectFavorite= psCollectFavorite.executeQuery();
				while(rsCollectFavorite.next()){
					collectFlag=rsCollectFavorite.getString(1);//得到了这个dynamic用户是否被登陆用户所收藏
					favoriteFlag=rsCollectFavorite.getString(2);//得到了这个dynamic用户是否被登陆用户所点赞					
				}
				rsCollectFavorite.close();
				psCollectFavorite.close();
				jsonObject.put("collectFlag", collectFlag);
				jsonObject.put("favoriteFlag", favoriteFlag);
				jsonObject.put("loginUserId", loginUserId);
				jsonObject.put("successCode", 1);
				if(favoriteFlag.equals("已点赞")){
					jsonarray.add(jsonObject);
				}
			}
	        rsDynamics.close();
	        psDynamics.close();
	        connection.close();
	        
	        JSONObject jObject=new JSONObject();
	        jObject.put("data", jsonarray);
	        out = response.getWriter();
	        out.println(jObject);
	        System.out.println(jObject);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
                

		
//		System.out.println("=======json is===========");
//	        response.setCharacterEncoding("UTF-8");
//	        response.setContentType("text/json");
//	        String acceptjson = "";
//	        try {
//	            BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream)request.getInputStream(), "utf-8"));
//	            StringBuffer sb = new StringBuffer("");
//	            String temp;
//	            while((temp = br.readLine()) != null){
//	                sb.append(temp);
//	            }
//	            br.close();
//	            acceptjson = sb.toString();
//	            System.out.println("=======json is==========="+acceptjson);
//	            if(acceptjson != ""){
//	                //System.out.println("get the json successfully");
//	            	//先获取json
//
//	            	JSONObject jo = JSONObject.fromObject(acceptjson);
//	                //再获取json中包含的jsonarry，dao是刚才android端给出的key
//	                JSONArray ja = jo.getJSONArray("dao");
//	                //循环获取jsonarray中的每个json
//	                for(int i = 0; i < ja.size(); i++){
//	                    JSONObject object = JSONObject.fromObject(ja.get(i));
//	                    //获取json中的email值，email是json中的key
//
//	                    System.out.println("email is: "+object.get("email"));
//	                }
//	            }
//	            else{
//	                System.out.println("get the json failed");
//	            }
//	        } catch (Exception e) {
//	            // TODO: handle exception
//	            e.printStackTrace();
//	        }
	    }

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
}
