package com.servlet.main;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.LoginDb;
import com.servlet.utils.StringUtil;

import net.sf.json.JSONObject;


@SuppressWarnings("serial")
public class LoginAction extends HttpServlet
{
	

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException, IOException
	{
		req.setCharacterEncoding("utf-8");
		String userId =StringUtil.alterCode(req, "uid");
		String psw = req.getParameter("psw");
		String newpsw = req.getParameter("newpsw");
		try
		{
			if(newpsw.equals(""))
			{
				switch(LoginDb.checkId(userId,psw))
				{
					case 1:
						resp.getOutputStream().write("1".getBytes("utf-8"));
						System.out.println("Login 1");
						break;					
					case 2:
						resp.getOutputStream().write("2".getBytes("utf-8"));
						System.out.println("Login 2");
						break;	
					case -1:
						resp.getOutputStream().write("-1".getBytes("utf-8"));
						System.out.println("Login -1");
						break;	
				}
			}
			else
			{
				switch(LoginDb.changePsw(userId,psw,newpsw))
				{
					case 1:
						resp.getOutputStream().write("1".getBytes("utf-8"));
						System.out.println("ChangePsw 1");
						break;	
					case -2:
						resp.getOutputStream().write("-2".getBytes("utf-8"));
						System.out.println("ChangePsw -2");
						break;	
					case -1:
						resp.getOutputStream().write("-1".getBytes("utf-8"));
						System.out.println("ChangePsw -1");
						break;	
				}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
}