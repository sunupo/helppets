package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetFromApply
 */
@WebServlet("/getFromApply")
public class GetFromApply extends HttpServlet {
	private static final long serialVersionUID = 1L;

    Connection connection;
    PreparedStatement ps;
    ResultSet rs;

    int loginUserId=0;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
        response.setContentType("text/json");
        
        loginUserId=Integer.parseInt(request.getParameter("loginUserId"));
        
		String sql="select u.loginname,u.logo,v.* from v_apply_dynamic v "
				+ "left join userinfo u on v.applyuid=u.userid where v.userId=?";
		try {
			connection = JdbcUtilUser.getConnection();
			ps=connection.prepareStatement(sql);
			ps.setInt(1, loginUserId);
			rs=ps.executeQuery();
			JSONObject jsonObject=new JSONObject();
			JSONArray jsonArray=new JSONArray();
			while (rs.next()){
				JSONObject jo=new JSONObject();
				jo.put("loginName", rs.getString(1));
				jo.put("logo", rs.getString(2));
				jo.put("applyUid", rs.getInt(3));
				jo.put("applyTime", rs.getString(4));
				jo.put("applyStatus", rs.getInt(5));
				jo.put("applyContent", rs.getString(6));
				jo.put("responseTime", rs.getString(7));
				jo.put("responseContent", rs.getString(8));
				
				jo.put("userId",rs.getInt(9));
				jo.put("dynamicId",rs.getInt(10));
				jo.put("isSend",rs.getString(11));
				jo.put("content",rs.getString(12));
				jo.put("type1",rs.getString(13));
				jo.put("type2",rs.getString(14));
				jo.put("type3",rs.getString(15));
				jo.put("type4",rs.getInt(16));
				jo.put("type5",rs.getString(17));
				jo.put("type6",rs.getInt(18));
				jo.put("collect",rs.getInt(19));
				jo.put("favorite",rs.getInt(20));
				jo.put("views",rs.getInt(21));
				jo.put("createTime",rs.getString(22));
				jo.put("picture",rs.getString(23));

				jsonArray.add(jo);
			}
			jsonObject.put("data", jsonArray);
			jsonObject.put("code", 1);
			jsonObject.put("message", "apply与dynamic创建的的视图，视图再与userinfo关联的数据返回成功");
			response.getWriter().println(jsonObject);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
