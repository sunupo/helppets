package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;

import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetDynamicUserFollowUser
 */
@WebServlet("/getDynamicUserFollowUser")
public class GetDynamicUserFollowUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	static Connection connection;
	static PreparedStatement ps;
	static ResultSet rs;
	static String sql="select f.touid from follow f where f.fromuid=?";
	static int dynamicUserId=1;
	static StringBuffer strBuffer;
	StringBuffer para=new StringBuffer().append("(");

	int hasData=0;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/json");
	
		strBuffer=new StringBuffer();
		try {
			connection=JdbcUtilUser.getConnection();
			dynamicUserId=Integer.parseInt(request.getParameter("dynamicUserId"));
			ps=connection.prepareStatement(sql);
			ps.setInt(1, dynamicUserId);
			rs=ps.executeQuery();
			while(rs.next()){
				hasData=1;
				strBuffer.append(rs.getInt(1)+"-");
				para.append(rs.getInt(1)+",");
			}
			if(hasData==1){
				int length=strBuffer.toString().length();
				JSONObject jObject=new JSONObject();
				jObject.put("data", strBuffer.toString().substring(0,length-1));
				
				response.getWriter().println(jObject);
				System.out.println(strBuffer.toString().substring(0,length-1));
			}
			else{
				JSONObject jObject=new JSONObject();
				jObject.put("data", "-1");
			}
			
//			String in=para.substring(0,length-1).concat(")");//(1,2,3)

//			String sql2="select * from dynamic d where d.userid in ?";
//			ps=connection.prepareStatement(sql2);
//			ps.setString(1, in);
//			rs=ps.executeQuery();
//			while(rs.next()){
//				
//			}
			
			
			rs.close();
			ps.close();
			connection.close();
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public static void main(String[] args){
		strBuffer=new StringBuffer();
		try {
			connection=JdbcUtilUser.getConnection();
//			dynamicUerId=Integer.parseInt(request.getParameter("dynamicUserId"));
			ps=connection.prepareStatement(sql);
			ps.setInt(1, dynamicUserId);
			rs=ps.executeQuery();
			while(rs.next()){
				strBuffer.append(rs.getInt(1)+"-");
			}
			int length=strBuffer.toString().length();
			String in=strBuffer.substring(0,length-1).concat(")");//(1,2,3
			System.out.println(in);
			rs.close();
			ps.close();
			connection.close();
//			response.getWriter().println(strBuffer.toString());
			
			System.out.println(strBuffer.toString().substring(0,length-1));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
