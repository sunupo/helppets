package com.servlet.main.helppets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.FavoriteDb;

/**
 *  每当用户点赞，取消点赞，都需要同时操作dynamic表和collectfavorite表
 */
@WebServlet("/favorite")
public class Favorite extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Favorite() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		int loginUserID=2;
		int dynamicUserId=1;
		int dynamicId=1;
		int favoriteFlag=0;
		try{

			loginUserID=Integer.parseInt(request.getParameter("loginUserId"));
			dynamicUserId=Integer.parseInt(request.getParameter("dynamicUserId"));
			dynamicId=Integer.parseInt(request.getParameter("dynamicId"));
			favoriteFlag=Integer.parseInt(request.getParameter("favoriteFlag"));
			
			System.out.println("loginUserID="+request.getParameter("loginUserId")
			+"dynamicUserId="+request.getParameter("dynamicUserId")
			+"dynamicId="+request.getParameter("dynamicId")
			+"favoriteFlag="+request.getParameter("favoriteFlag"));
			
			System.out.println("loginUserID="+loginUserID+"点赞/取消点赞dynamicUserId="+dynamicUserId);
			switch(FavoriteDb.execute(loginUserID,dynamicUserId,dynamicId,favoriteFlag))
			{
				case 1:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("点赞成功\n"); 

					break;		

				case 0:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("点赞失败\n");	 

					break;
					
				case 10:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("你没有点赞"+loginUserID+"\n");			 

					break;
				case 11:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("你已经点赞"+loginUserID+"\n");		 

					break;
					
				case 20:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("取消点赞失败 "+loginUserID+"\n");			 

					break;
				case 21:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("取消点赞成功"+loginUserID+"\n");			 

					break;
					default :
						response.getOutputStream().write("-1".getBytes("utf-8"));
						break;
			}
		}catch(Exception e){
			
		}		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
