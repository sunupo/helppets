package com.servlet.main;

public class MessageBox
{
	private int num;
	private String sender;
	private String recipient;
	private String senderName;
	private String recipientName;
	private String content;
	
	public void setNum(int num)
	{
		this.num = num;
	}

	public int getNum()
	{
		return this.num;
	}

	public void setSender(String sender)
	{
		this.sender = sender;
	}

	public String getSender()
	{
		return this.sender;
	}

	public void setRecipient(String recipient)
	{
		this.recipient = recipient;
	}

	public String getRecipient()
	{
		return this.recipient;
	}
	
	public void setSenderName(String senderName)
	{
		this.senderName = senderName;
	}

	public String getSenderName()
	{
		return this.senderName;
	}

	public void setRecipientName(String recipientName)
	{
		this.recipientName = recipientName;
	}

	public String getRecipientName()
	{
		return this.recipientName;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getContent()
	{
		return this.content;
	}
}
