package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;

import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetLatestFollowCollectFavorite
 */
@WebServlet("/getLatestFollowCollectFavorite")
public class GetLatestFollowCollectFavorite extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetLatestFollowCollectFavorite() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/json");
		Connection connection=null;
		int loginUserId=0;
		int dynamicUserId=0;
		int dynamicId=0;
		JSONObject jsonObject;
		try{
			jsonObject=new JSONObject();
			loginUserId=Integer.parseInt(request.getParameter("loginUserId"));
			dynamicUserId=Integer.parseInt(request.getParameter("dynamicUserId"));
			dynamicId=Integer.parseInt(request.getParameter("dynamicId"));

			System.out.println("loginUserId="+loginUserId+"=dynamicUserId"+dynamicUserId+"dynamicId="+dynamicId);
			connection=JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);//如果有update操作，就执行这一行
			
			String sql1="select f.isfollow from follow f where fromuid=? and toUid=?";
			String sql2="select c.iscollected,isfavorite from collectFavorite c where fromUid=? and touid=? and dynamicid=?";
			String sql3="select d.collected,d.favorite,d.views from dynamic d where d.userId=? and d.dynamicId=?";
			PreparedStatement ps=connection.prepareStatement(sql1);
			ps.setInt(1, loginUserId);
			ps.setInt(2, dynamicUserId);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				jsonObject.put("followFlag", rs.getString(1));
			}else{
				jsonObject.put("followFlag", "未关注");
			}
			
			ps=connection.prepareStatement(sql2);
			ps.setInt(1, loginUserId);
			ps.setInt(2, dynamicUserId);
			ps.setInt(3, dynamicId);
			rs=ps.executeQuery();
			if(rs.next()){
				jsonObject.put("collectFlag", rs.getString(1));
				jsonObject.put("favoriteFlag", rs.getString(2));
			}else{
				jsonObject.put("collectFlag", "未收藏");
				jsonObject.put("favoriteFlag", "未点赞");
			}
			
			ps=connection.prepareStatement(sql3);
			ps.setInt(1, dynamicUserId);
			ps.setInt(2,dynamicId);
 			rs=ps.executeQuery();
 			if(rs.next()){
				jsonObject.put("collectNum", rs.getInt(1));
				jsonObject.put("favoriteNum", rs.getInt(2));
				jsonObject.put("views", rs.getInt(3));
				
			}else{//既然是从点击一条dynamic进去评论主页的，就一定有数据，不会进入else
				jsonObject.put("collectNum", 0);
				jsonObject.put("favoriteNum", 0);
				jsonObject.put("views", 1);
			}
			
		response.getWriter().println(jsonObject);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
