package com.servlet.main;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.ResetDb;
import com.servlet.utils.StringUtil;

@SuppressWarnings("serial")
public class ResetAccount extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException, IOException
	{
		req.setCharacterEncoding("utf-8");
		String uid = StringUtil.alterCode(req, "uid");
		String psw = req.getParameter("psw");
		try
		{
			switch(ResetDb.resetUser(uid,psw))
				{
					case 1:
						resp.getOutputStream().write("1".getBytes("utf-8"));
						System.out.println("reset 1");
						break;
					case -2:
						resp.getOutputStream().write("-2".getBytes("utf-8"));
						System.out.println("reset -2");
						break;
					case -1:
						resp.getOutputStream().write("-1".getBytes("utf-8"));
						System.out.println("reset -1");
						break;
					default:
						resp.getOutputStream().write("-1".getBytes("utf-8"));
						System.out.println("reset -1");
						break;
				}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}

}
