package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;

/**
 * Servlet implementation class GetFanFollowFavoriteCollect
 */
@WebServlet("/getFanFollowFavoriteCollect")
public class GetFanFollowFavoriteCollect extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	Connection connection;
	PreparedStatement ps;
	ResultSet rs;
	String sql1="select count(*) from follow f where f.touid=?";//粉丝
	String sql2="select count(*) from follow f where f.fromuid=?";//关注
	String sql3="select count(*) from collectfavorite f where f.touid =? and f.iscollected='已收藏'";//被收藏
	String sql4="select count(*) from collectfavorite f where f.touid =? and f.isfavorite='已点赞'";//被点赞
	int dynamicUserId=1;


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		StringBuffer buffer=new StringBuffer();
		try {
			connection=JdbcUtilUser.getConnection();
			dynamicUserId=Integer.parseInt(request.getParameter("dynamicUserId"));
			
			ps=connection.prepareStatement(sql1);
			ps.setInt(1, dynamicUserId);
			rs=ps.executeQuery();
			while(rs.next()){
				buffer.append(rs.getInt(1)+"-");
			}
			
			ps=connection.prepareStatement(sql2);
			ps.setInt(1, dynamicUserId);
			rs=ps.executeQuery();
			while(rs.next()){
				buffer.append(rs.getInt(1)+"-");
			}
			
			ps=connection.prepareStatement(sql3);
			ps.setInt(1, dynamicUserId);
			rs=ps.executeQuery();
			while(rs.next()){
				buffer.append(rs.getInt(1)+"-");
			}
			
			ps=connection.prepareStatement(sql4);
			ps.setInt(1, dynamicUserId);
			rs=ps.executeQuery();
			while(rs.next()){
				buffer.append(rs.getInt(1)+"");
			}
			
			rs.close();
			ps.close();
			connection.close();
			
			response.getWriter().println(buffer.toString());
			System.out.println(buffer.toString());
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
