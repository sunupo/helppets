package com.servlet.main.helppets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.Base64Coder;
import com.servlet.utils.Constants;

/**
 * Servlet implementation class UpdateUserInfo
 */
@WebServlet("/updateUserInfoLogo")
public class UpdateUserInfoLogo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
    private String logo;
    int userId=-1;
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
       
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp ) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 System.out.println("上床用户头像。。。");

			logo = req.getParameter("logo");        
	        userId=Integer.parseInt(req.getParameter("userId"));
			
			if (logo != null) {

	            byte[] b = Base64Coder.decodeLines(logo);
	            String  filepath=Constants.UPLOAD_LOGO_ROOT_PATH;
	            File file = new File(filepath);
	            if (!file.exists())
	                file.mkdirs();
//	            FileOutputStream fos = new FileOutputStream(file.getPath()
//	                    + "/image" + (int) (Math.random() * 100) + ".bmp");
	            FileOutputStream fos = new FileOutputStream(file.getPath() + "/"+userId+".bmp");
	            System.out.println(file.getPath());
	            System.out.println(file.getPath() + "/"+userId+".bmp");
	            fos.write(b);
	            fos.flush();
	            fos.close();
				resp.getOutputStream().write("2".getBytes("utf-8"));
				resp.getOutputStream().write("-2".getBytes("utf-8"));


	        }
		
	}

}
