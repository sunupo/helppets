package com.servlet.main;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import com.servlet.database.ViewlistDb;


@SuppressWarnings("serial")
public class GetViewlist extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String islostCode = req.getParameter("islostCode");
		String searchInfo = req.getParameter("searchInfo");
		List<InfoList> lists;
		
		if(searchInfo.equals("")) 
		{
			try
			{
				lists = ViewlistDb.query(islostCode);
				if (lists.isEmpty())
				{
					resp.getOutputStream().write("-1".getBytes("utf-8"));
				}
				else
				{
					JSONArray data = JSONArray.fromObject(lists);
					JSONObject map = new JSONObject();
					map.put("infoList", data);					
					resp.getOutputStream().write(map.toString().getBytes("utf-8"));
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			try
			{
				lists = ViewlistDb.searchInfo(searchInfo);
				if (lists.isEmpty())
				{
					resp.getOutputStream().write("-1".getBytes("utf-8"));
				}
				else
				{
					JSONArray data = JSONArray.fromObject(lists);
					JSONObject map = new JSONObject();
					map.put("infoList", data);					
					resp.getOutputStream().write(map.toString().getBytes("utf-8"));
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}

}

