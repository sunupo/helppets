package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;
import com.servlet.utils.StringUtil;

/**
 * Servlet implementation class UpdateUserInfo
 */
@WebServlet("/updateUserInfoContent")
public class UpdateUserInfoContent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
    Connection connection;
    PreparedStatement ps;
    
    int userId=-1;
    
    String sex; String birthday; String work; int salary; String education; 
    String marry; 
    String children; 
    String province; 
    String city; 
    String phone; 
    String qq; 
    String weChat;
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		sex=StringUtil.alterCode(req, "sex");
		birthday=StringUtil.alterCode(req, "birthday");
		work=StringUtil.alterCode(req, "work");
		
		salary=Integer.parseInt(StringUtil.alterCode(req, "salary"));
		
		education=StringUtil.alterCode(req, "education");
		marry=StringUtil.alterCode(req, "marry");
		children=StringUtil.alterCode(req, "children");
		province=StringUtil.alterCode(req, "province");
		city=StringUtil.alterCode(req, "city");
		phone=StringUtil.alterCode(req, "phone");
		qq=StringUtil.alterCode(req, "qq");
		weChat=StringUtil.alterCode(req, "weChat");
		
		userId=Integer.parseInt(StringUtil.alterCode(req, "userId"));
		
//		根据生日，计算年龄
		Calendar calendar = Calendar.getInstance();
		int age=2018+calendar.YEAR-Integer.parseInt((birthday.split("-")[0]));
		System.out.println("calendar.YEAR="+calendar.YEAR);

		
		String sql="update  userinfo u set u.sex=?,u.birthday=?,u.working=?,u.salary=?,u.education=?"
				+ ",u.married=?,u.haschildren=?,u.province=?,u.city=?,u.phone=?,u.qq=?,u.wechat=?,u.age=? where u.userid=?";
		
		try {
			connection=JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);//---------------------特别重要---------------------
			ps=connection.prepareStatement(sql);
			ps.setString(1, sex);
			ps.setString(2, birthday);
			ps.setString(3, work);
			ps.setInt(4, salary);
			ps.setString(5, education);
			ps.setString(6, marry);
			ps.setString(7, children);
			ps.setString(8, province);
			ps.setString(9, city);
			ps.setString(10, phone);
			ps.setString(11, qq);
			ps.setString(12, weChat);
			ps.setInt(13, age);
			ps.setInt(14, userId);
			
			int result=ps.executeUpdate();
			if(result!=0){
//				输出1
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("成功，修改用户信息 1");

			}else{
//				输出-1
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("失败，修改用户信息 -1");

			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
