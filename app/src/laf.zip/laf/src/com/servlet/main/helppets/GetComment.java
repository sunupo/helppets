package com.servlet.main.helppets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.FollowDb;


@SuppressWarnings("serial")
public class GetComment extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
//		request.setCharacterEncoding("utf-8");
		int loginUserID=2;
		int dynamicUserId=1;
		int followFlag=0;
		try{
			System.out.println("loginUserID="+request.getParameter("loginUserId")
			+"followFlag="+request.getParameter("followFlag"));
			loginUserID=Integer.parseInt(request.getParameter("loginUserId"));
			dynamicUserId=Integer.parseInt(request.getParameter("dynamicUserId"));
			followFlag=Integer.parseInt(request.getParameter("followFlag"));			
			
			System.out.println("loginUserID="+loginUserID+"关注了dynamicUserId="+dynamicUserId);
			switch(FollowDb.execute(loginUserID,dynamicUserId,followFlag))
			{
				case 1:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("关注成功\n"); 

					break;		

				case 0:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("关注失败\n");	 

					break;
					
				case 10:
					response.getOutputStream().write("10".getBytes("utf-8"));
					System.out.println("你没有关注"+loginUserID+"\n");			 

					break;
				case 11:
					response.getOutputStream().write("11".getBytes("utf-8"));
					System.out.println("你已经关注"+loginUserID+"\n");		 

					break;
					
				case 20:
					response.getOutputStream().write("20".getBytes("utf-8"));
					System.out.println("取消关注失败 "+loginUserID+"\n");			 

					break;
				case 21:
					response.getOutputStream().write("21".getBytes("utf-8"));
					System.out.println("取消关注成功"+loginUserID+"\n");			 

					break;
				default :
						response.getOutputStream().write("-1".getBytes("utf-8"));
						break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}	
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
}
