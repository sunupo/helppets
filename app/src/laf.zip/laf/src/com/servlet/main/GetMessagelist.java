package com.servlet.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.MessagelistDb;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


@SuppressWarnings("serial")
public class GetMessagelist extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String user = req.getParameter("user");
		String messageType = req.getParameter("messageType");
		List<MessageBox> lists;
		try
		{
			lists = MessagelistDb.getMaillist(user,messageType);
			if (lists.isEmpty())
			{
				resp.getOutputStream().write("-1".getBytes("utf-8"));
			}
			else
			{
				JSONArray data = JSONArray.fromObject(lists);
				JSONObject map = new JSONObject();
				map.put("MessageList", data);					
				resp.getOutputStream().write(map.toString().getBytes("utf-8"));
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}

}
