package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.SetCommentDataDb;

/**
 * Servlet implementation class SetCommentData
 */
@WebServlet(description = "写入评论信息", urlPatterns = { "/setCommentData" })
public class SetCommentData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetCommentData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("");
		
		req.setCharacterEncoding("utf-8");
		
		int fromUid = Integer.parseInt(req.getParameter("fromUid"));
		int toUid = Integer.parseInt(req.getParameter("toUid"));
		int dynamicId = Integer.parseInt(req.getParameter("dynamicId"));
		String commentContent = req.getParameter("commentContent");
		String commentTime=req.getParameter("commentTime");
//		TODO 计算dynamicId
		
		switch(SetCommentDataDb.postCom(fromUid,toUid,dynamicId,commentContent,commentTime))
		{
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("post comment success!");
				break;
			case -2:
				resp.getOutputStream().write("-2".getBytes("utf-8"));
				System.out.println("ban user post comment failed!");
				break;
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("post comment failed!");
				break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
