package com.servlet.main.helppets;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.LoginUserInfoDb;
import com.servlet.utils.StringUtil;

import net.sf.json.JSONObject;


//可以得到任何单个用户的详细信息，不仅仅是当前app登陆用户，这儿类的变量名字取得不好
@SuppressWarnings("serial")
@WebServlet("/loginUserInfo")
public class LoginUserInfo extends HttpServlet
{
	
	private JSONObject jsonObject;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException, IOException
	{
		String loginName = "zhangsan";
		
		
		resp.setCharacterEncoding("utf-8");

		resp.setContentType("text/json");


		try
		{        	loginName = StringUtil.alterCode(req, "loginName");

			jsonObject=LoginUserInfoDb.getUserInfoJsonObject(loginName);

			resp.getWriter().println(jsonObject);
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
}