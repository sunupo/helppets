package com.servlet.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.ReleaseDynamicDb;
import com.servlet.utils.StringUtil;

@SuppressWarnings("serial")
public class ReleaseDynamic extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
	{

		
		switch(ReleaseDynamicDb.releaseDynamic(
				StringUtil.alterCode(req, "loginName")
				,new String(req.getParameter("isSend").getBytes("iso8859-1"),"utf-8")
				,StringUtil.alterCode(req, "contentText")
				,StringUtil.alterCode(req, "type1")
				,StringUtil.alterCode(req, "type2")
				,StringUtil.alterCode(req, "type3")
				,Integer.parseInt(req.getParameter("type4"))
				,StringUtil.alterCode(req, "type5")
				,StringUtil.alterCode(req, "type6")
				,StringUtil.alterCode(req, "time")))
		{
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("post success!");
				break;
			case -2:
				resp.getOutputStream().write("-2".getBytes("utf-8"));
				System.out.println("ban user post failed!");
				break;
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("post failed!");
				break;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
	
}

