package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetCommentJson
 */
@WebServlet(description = "获取每一条动态的评论数据", urlPatterns = { "/getCommentJson" })
public class GetCommentJson extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
//	若果等于-1，说明客户端没有正确的传入过来参数
	private int userId=2;
	private int dynamicId=1;
	private int total=0;
//	sql 计算total（该条动态的评论总数）
	private String sql_a="select count(*) from comments c where c.touid=? and c.dynamicid=?";
//	sql 计算reply_total（该条动态的其中一条评论的回复总数）
	private String sql_b="select count(*) from reply r where r.fromuid=? and r.touid=? and r.dynamicid=?";
//	sqla得到该条评论的所有的评论者
//	private String sqlA="select r.fromuid, r.commentcontent,c.commenttime,c.commentid from reply r inner join comments"
//			+" c on r.touid=c.touid and r.dynamicid=c.dynamicid where r.touid=? and r.dynamicid=? group by (r.fromuid) ";
	private String sqlA="select c.fromuid, c.commentcontent,c.commenttime,c.commentid from comments c where c.touid=? and c.dynamicid=? ";
//	sqlb得到每个评论者下的回复者
	private String sqlB="SELECT r.replyuid,r.replyid,r.replycontent,r.replytime from reply r where r.fromuid=? and r.touid=? and r.dynamicid=? group by (r.replyid)";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetCommentJson() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection connection=null;
		
		userId=Integer.parseInt(request.getParameter("userId"));
		dynamicId=Integer.parseInt(request.getParameter("dynamicId"));

		response.setContentType("text/json");
		response.setCharacterEncoding("UTF-8");
		JSONObject jsonObject1=new JSONObject();
		jsonObject1.put("code", 1000);
		jsonObject1.put("message", "查看评论成功");
		
		
		
		try {
			connection=JdbcUtilUser.getConnection();
			
			PreparedStatement psSqla=connection.prepareStatement(sql_a);
			psSqla.setInt(1, userId);
			psSqla.setInt(2, dynamicId);
			ResultSet rsSqla=psSqla.executeQuery();
			while(rsSqla.next()){
				total=rsSqla.getInt(1);//计算total（该条动态的评论总数）
			}
			
			JSONObject jsonObject2=new JSONObject();
			jsonObject2.put("total",total);
			
			PreparedStatement psSqlA=connection.prepareStatement(sqlA);
			psSqlA.setInt(1, userId);
			psSqlA.setInt(2, dynamicId);
			ResultSet rsSqlA=psSqlA.executeQuery();

			JSONArray jsonArray3=new JSONArray();//jsonArray3添加多个jsonObject3，一个jsonObject3代表一个评论
			while(rsSqlA.next()){
				
				int tempFromUid=rsSqlA.getInt(1);
				int id=rsSqlA.getInt(4);//这是评论Id
				String nickName="";String userLogo="";
				String content=rsSqlA.getString(2);//评论内容
				String imgId="xcclsscr0tev11ok364";
				String createDate=rsSqlA.getString(3);//评论时间
				PreparedStatement  userInfo=connection.prepareStatement(
						"select u.loginname,u.logo from userinfo u where u.userid=?");
				userInfo.setInt(1, tempFromUid);
				
				ResultSet rsUserInfo=userInfo.executeQuery();
				while(rsUserInfo.next()){
					nickName=rsUserInfo.getString(1);
					userLogo=rsUserInfo.getString(2);
				}		
				
				int replyTotal=0;				
				PreparedStatement  psSqlb=connection.prepareStatement(sql_b);
				psSqlb.setInt(1, tempFromUid);
				psSqlb.setInt(2, userId);
				psSqlb.setInt(3, dynamicId);
				ResultSet rsSqlb=psSqlb.executeQuery();
				while(rsSqlb.next()){
					replyTotal=rsSqlb.getInt(1);//得到该条评论下的回复总数
				}
				
				JSONObject jsonObject3=new JSONObject();
				jsonObject3.put("id",id);
				jsonObject3.put("nickName",nickName);
				jsonObject3.put("userLogo",userLogo);
				jsonObject3.put("content",content);
				jsonObject3.put("imgId",imgId);
				jsonObject3.put("replyTotal",replyTotal);
				jsonObject3.put("createDate",createDate);
				
				PreparedStatement  psSqlB=connection.prepareStatement(sqlB);
				psSqlB.setInt(1, tempFromUid);
				psSqlB.setInt(2, userId);
				psSqlB.setInt(3, dynamicId);
				ResultSet rsSqlB=psSqlB.executeQuery();
				
				JSONArray jsonArray4=new JSONArray();		
				while(rsSqlB.next()){
					int tempReplyUid=rsSqlB.getInt(1);
					String reply_nickName="";
					String reply_userLogo="";
					int reply_id=rsSqlB.getInt(2);
					String commentId=id+"";
					String reply_content=rsSqlB.getString(3);
					String status="01";
					String reply_createDate=rsSqlB.getString(4);
					
					PreparedStatement  reply_userInfo=connection.prepareStatement(
							"select u.loginname,u.logo from userinfo u where u.userid=?");
					reply_userInfo.setInt(1, tempReplyUid);
					
					ResultSet reply_rsUserInfo=reply_userInfo.executeQuery();
					while(reply_rsUserInfo.next()){
						reply_nickName=reply_rsUserInfo.getString(1);
						reply_userLogo=reply_rsUserInfo.getString(2);
					}
					JSONObject jsonObject4=new JSONObject();
					jsonObject4.put("nickName", reply_nickName);
					jsonObject4.put("userLogo", reply_userLogo);
					jsonObject4.put("id", reply_id);
					jsonObject4.put("commentId", commentId);
					jsonObject4.put("content", reply_content);
					jsonObject4.put("status", status);
					jsonObject4.put("createDate", reply_createDate);
					jsonArray4.add(jsonObject4);
				}
				jsonObject3.put("replyList", jsonArray4);	
				jsonArray3.add(jsonObject3);
			}
			jsonObject2.put("list", jsonArray3);
			jsonObject1.put("data", jsonObject2);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		response.getWriter().println(jsonObject1);
		
		try{
			userId=Integer.parseInt(request.getParameter("userId"));
			dynamicId=Integer.parseInt(request.getParameter("dynamicId"));
			
		}catch(Exception e){
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
