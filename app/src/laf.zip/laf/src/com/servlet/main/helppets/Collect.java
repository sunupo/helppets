package com.servlet.main.helppets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.CollectDb;

/**
 * 每当用户收藏，取消收藏，都需要同时操作dynamic表和collectfavorite表
 * 
 */
@WebServlet("/collect")
public class Collect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Collect() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		int loginUserId=2;
		int dynamicUserId=1;
		int dynamicId=1;
		int collectFlag=0;
		try{

			loginUserId=Integer.parseInt(request.getParameter("loginUserId"));
			dynamicUserId=Integer.parseInt(request.getParameter("dynamicUserId"));
			dynamicId=Integer.parseInt(request.getParameter("dynamicId"));
			collectFlag=Integer.parseInt(request.getParameter("collectFlag"));	
			
			System.out.println("loginUserID="+request.getParameter("loginUserId")
			+"dynamicUserId="+request.getParameter("dynamicUserId")
			+"dynamicId="+request.getParameter("dynamicId")
			+"collectFlag="+request.getParameter("collectFlag"));
			
			switch(CollectDb.execute(loginUserId,dynamicUserId,dynamicId,collectFlag))
			{
				case 1:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("收藏成功\n"); 

					break;		

				case 0:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("收藏失败\n");	 

					break;
					
				case 10:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("你没有收藏"+loginUserId+"\n");			 

					break;
				case 11:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("你已经收藏"+loginUserId+"\n");		 

					break;
					
				case 20:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("取消收藏失败 "+loginUserId+"\n");			 

					break;
				case 21:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("取消收藏成功"+loginUserId+"\n");			 

					break;
					default :
						response.getOutputStream().write("-1".getBytes("utf-8"));
						break;
			}
		}catch(Exception e){
			
		}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
