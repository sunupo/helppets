package com.servlet.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.CommentDb;


@SuppressWarnings("serial")
public class GetComment extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String user = req.getParameter("user");
		try
		{
			String comment = CommentDb.getCom(user);
			if (comment.equals(""))
			{
				resp.getOutputStream().write("-1".getBytes("utf-8"));
			}
			else
			{				
				resp.getOutputStream().write(comment.toString().getBytes("utf-8"));
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
}
