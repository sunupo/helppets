package com.servlet.main;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class GetRandom extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
//		String user = req.getParameter("user");
		Random random = new Random();
		Integer randomnum = random.nextInt(9999-1000+1)+1000;
		resp.getOutputStream().write(randomnum.toString().getBytes("utf-8"));
		System.out.println("random");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
}
