package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;
import com.servlet.utils.StringUtil;

/**
 * Servlet implementation class SetBanAdmin
 */
@WebServlet("/setBanAdmin")
public class SetBanAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection connection;
	PreparedStatement ps;
	
	String sqlBanned="update  userinfo u set  u.isBanned=? where userId=?";
	String sqlAdmin="update  userinfo u set  u.isAdmin=? where userId=?";
	
	String flag,panduan;
	int userId=0;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		flag=StringUtil.alterCode(request, "flag");
		panduan=StringUtil.alterCode(request, "panduan");
		userId=Integer.parseInt(request.getParameter("userId"));
		
		try {
			connection=JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);
			if(panduan.equals("isAdmin")){
				
				ps=connection.prepareStatement(sqlAdmin);
				ps.setString(1, flag);
				ps.setInt(2, userId);
				int i=ps.executeUpdate();
				if(i!=0){
					response.getWriter().println("1");
				}
				else{
					response.getWriter().println("-1");
				}
				
			}else if(panduan.equals("isBanned")){
				ps=connection.prepareStatement(sqlBanned);
				ps.setString(1, flag);
				ps.setInt(2, userId);
				int i=ps.executeUpdate();
				if(i!=0){
					response.getWriter().println("2");
					return;
				}
				else{
					response.getWriter().println("-2");
					return;

				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
