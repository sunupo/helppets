package com.servlet.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.PostDb;

@SuppressWarnings("serial")
public class PostInfo extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
	{
//		String numStr = req.getParameter("num");
		String title = req.getParameter("title");
		String text = req.getParameter("text");
		String user = req.getParameter("user");
		String islostStr = req.getParameter("islost");
		switch(PostDb.postInfo(title,text,user,islostStr))
		{
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("post success!");
				break;
			case -2:
				resp.getOutputStream().write("-2".getBytes("utf-8"));
				System.out.println("ban user post failed!");
				break;
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("post failed!");
				break;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
	
}
