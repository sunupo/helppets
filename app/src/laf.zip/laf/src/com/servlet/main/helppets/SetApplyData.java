package com.servlet.main.helppets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.SetApplyDataDb;

/**
 * http://localhost:34098/laf/setApplyData?applyUid=2&toUid=1&dynamicId=1&applyContent=%22hello%22&appltTime=%222019-03-24-13-4-32%22
 * Servlet implementation class SetApplyData
 */
@WebServlet("/setApplyData")
public class SetApplyData extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("");
		
		req.setCharacterEncoding("utf-8");
		
		int applyUid = Integer.parseInt(req.getParameter("applyUid"));
		int toUid = Integer.parseInt(req.getParameter("toUid"));
		int dynamicId = Integer.parseInt(req.getParameter("dynamicId"));
		String applyContent = req.getParameter("applyContent");
		String applyTime=req.getParameter("applyTime");
//		TODO 计算dynamicId
		
		switch(SetApplyDataDb.postCom(applyUid,toUid,dynamicId,applyContent,applyTime))
		{
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("你已经申请了");
				break;
			case 2:
				resp.getOutputStream().write("0".getBytes("utf-8"));
				System.out.println("你已经申请成功了!");
				break;
			case 3:
				resp.getOutputStream().write("0".getBytes("utf-8"));
				System.out.println("上次申请过了，没有通过!");
				break;
			case -2:
				resp.getOutputStream().write("-2".getBytes("utf-8"));
				System.out.println("禁言!");
				break;
				
			case 11:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("其他人正在申请中");
				break;
			case 12:
				resp.getOutputStream().write("0".getBytes("utf-8"));
				System.out.println("其他人申请过了已经申请成功了!");
				break;
				
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("系统故障，提交失败");
				break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
