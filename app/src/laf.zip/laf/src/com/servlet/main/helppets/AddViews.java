package com.servlet.main.helppets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.AddViewsDb;
import com.servlet.utils.StringUtil;

/**
 * 点击浏览一次，views次数加1
 */
@WebServlet("/addViews")
public class AddViews extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddViews() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("utf-8");
		int userId=1;
		int dynamicId=1;
		try{
			userId=Integer.parseInt(request.getParameter("userId"));
			dynamicId=Integer.parseInt(request.getParameter("dynamicId"));
			
			switch(AddViewsDb.add(userId,dynamicId))
			{
				case 1:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("addViews success!");
					break;				
				case -1:
					response.getOutputStream().write("-1".getBytes("utf-8"));
					System.out.println("addViews failed!");
					break;
			}
		}catch(Exception e){
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
