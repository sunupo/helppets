package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetFromApply
 */
@WebServlet("/getToApply")
public class GetToApply extends HttpServlet {
	private static final long serialVersionUID = 1L;

    Connection connection;
    PreparedStatement ps;
    ResultSet rs;

    int loginUserId=0;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
        response.setContentType("text/json");
        
        loginUserId=Integer.parseInt(request.getParameter("loginUserId"));//传过来的登陆用户的id，查询他所申请的动态有哪些
        
		String sql="select v.userid,v.dynamicId,v.applyStatus,v.applyTime,v.applycontent "
				+ ",v.responseTime,v.responseContent from v_apply_dynamic v  where v.applyuid=?";
		try {
			connection = JdbcUtilUser.getConnection();
			ps=connection.prepareStatement(sql);
			ps.setInt(1, loginUserId);
			rs=ps.executeQuery();
			JSONObject jsonObject=new JSONObject();
			JSONArray jsonArray=new JSONArray();
			while (rs.next()){
				JSONObject jo=new JSONObject();		
				
				jo.put("userId",rs.getInt(1));
				jo.put("dynamicId",rs.getInt(2));
				jo.put("applyStatus", rs.getInt(3));
				jo.put("applyTime", rs.getString(4));
				jo.put("applyContent", rs.getString(5));
				jo.put("responseTime", rs.getString(6));
				jo.put("responseContent", rs.getString(7));
				
//				再根据userid dynamicid，得到dynamic对应用户的头像，名字，动态时间，动态内容，动态图片
				sql=" select u.logo,u.loginname,d.createtime,d.content,d.picture from userinfo u right join dynamic d "
						+ "on u.userid=d.userid where d.dynamicid=? and d.userid=?";
				ps=connection.prepareStatement(sql);
				ps.setInt(1, rs.getInt(1));
				ps.setInt(2, rs.getInt(2));
				rs=ps.executeQuery();
				while (rs.next()){
					jo.put("logo", rs.getString(1));
					jo.put("loginName", rs.getString(2));
					jo.put("createtime", rs.getString(3));
					jo.put("content", rs.getString(4));
					jo.put("picture", rs.getString(5));
				}
				jsonArray.add(jo);
			}
			jsonObject.put("data", jsonArray);
			jsonObject.put("code", 1);
			jsonObject.put("message", "apply与dynamic创建的的视图，得到登录用户的申请列表，数据返回成功");
			response.getWriter().println(jsonObject);
			System.out.println("登录用户的申请列表，数据返回--成功");
			rs.close();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("登录用户的申请列表，数据返回--失败");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
