package com.servlet.main.helppets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.FollowDb;

/**
 * 操作关注列表
 */
@WebServlet("/follow")
public class Follow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Follow() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		int loginUserID=2;
		int dynamicUserId=1;
		int followFlag=0;
		try{

			loginUserID=Integer.parseInt(request.getParameter("loginUserId"));
			dynamicUserId=Integer.parseInt(request.getParameter("dynamicUserId"));
			followFlag=Integer.parseInt(request.getParameter("followFlag"));
			System.out.println("loginUserID="+request.getParameter("loginUserId")
			+"followFlag="+request.getParameter("followFlag"));
			
			System.out.println("loginUserID="+loginUserID+"关注了dynamicUserId="+dynamicUserId);
			switch(FollowDb.execute(loginUserID,dynamicUserId,followFlag))
			{
				case 1:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("关注成功\n"); 

					break;		

				case 0:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("关注失败\n");	 

					break;
					
				case 10:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("你没有关注"+loginUserID+"\n");			 

					break;
				case 11:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("你已经关注"+loginUserID+"\n");		 

					break;
					
				case 20:
					response.getOutputStream().write("0".getBytes("utf-8"));
					System.out.println("取消关注失败 "+loginUserID+"\n");			 

					break;
				case 21:
					response.getOutputStream().write("1".getBytes("utf-8"));
					System.out.println("取消关注成功"+loginUserID+"\n");			 

					break;
					default :
						response.getOutputStream().write("-1".getBytes("utf-8"));
						break;
			}
		}catch(Exception e){
			
		}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}


}
