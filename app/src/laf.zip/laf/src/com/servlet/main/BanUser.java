package com.servlet.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.UsermanageDb;

@SuppressWarnings("serial")
public class BanUser extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	{
		String user = req.getParameter("user");
		
		try
		{
			switch(UsermanageDb.userBan(user))
			{
			case 0:
				resp.getOutputStream().write("0".getBytes("utf-8"));
				System.out.println("unban");
				break;
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("ban");
				break;
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("ban/unban wrong");
				break;
			}
			
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
}
