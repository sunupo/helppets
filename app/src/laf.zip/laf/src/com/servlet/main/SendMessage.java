package com.servlet.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.MessageDb;

@SuppressWarnings("serial")
public class SendMessage extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
	{
		String sender = req.getParameter("sender");
		String recipient = req.getParameter("recipient");
		String content = req.getParameter("content");
		
		switch(MessageDb.sendMessage(sender, recipient, content))
		{
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("send message success!");
				break;
			case -2:
				resp.getOutputStream().write("-2".getBytes("utf-8"));
				System.out.println("no recipient send message failed!");
				break;
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("send message failed!");
				break;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
	
}
