package com.servlet.main.helppets;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.helppets.LoginUserInfoListDb;

import net.sf.json.JSONObject;


//可以得到任何单个用户的详细信息，不仅仅是当前app登陆用户，这儿类的变量名字取得不好
@SuppressWarnings("serial")
@WebServlet("/loginUserInfoList")
public class LoginUserInfoList extends HttpServlet
{
	
	private JSONObject jsonObject;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException, IOException
	{
		int loginUserId = 1;
		
		
		resp.setCharacterEncoding("utf-8");

		resp.setContentType("text/json");


		try
		{
			loginUserId = Integer.parseInt(req.getParameter("loginUserId"));
			System.out.println("loginUserId="+loginUserId);
			jsonObject=LoginUserInfoListDb.getLoginUserInfoList(loginUserId);

			resp.getWriter().println(jsonObject);
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
}