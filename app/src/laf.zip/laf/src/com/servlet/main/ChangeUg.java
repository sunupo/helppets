package com.servlet.main;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.UsermanageDb;

@SuppressWarnings("serial")
public class ChangeUg extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	{
		String user = req.getParameter("user");
		
		try
		{
			switch(UsermanageDb.ugChange(user))
			{
			case 0:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("change to normal");
				break;
			case 1:
				resp.getOutputStream().write("2".getBytes("utf-8"));
				System.out.println("change to admin");
				break;
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("change to admin/normal wrong");
				break;
			}
			
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
