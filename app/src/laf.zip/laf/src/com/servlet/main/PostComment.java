package com.servlet.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.database.CommentDb;

@SuppressWarnings("serial")
public class PostComment extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
	{
		String user0 = req.getParameter("user0");
		String user1 = req.getParameter("user1");
		String content = req.getParameter("content");
		
		switch(CommentDb.postCom(user0,user1,content))
		{
			case 1:
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("post comment success!");
				break;
			case -2:
				resp.getOutputStream().write("-2".getBytes("utf-8"));
				System.out.println("ban user post comment failed!");
				break;
			case -1:
				resp.getOutputStream().write("-1".getBytes("utf-8"));
				System.out.println("post comment failed!");
				break;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		doGet(req, resp);
	}
	
}

