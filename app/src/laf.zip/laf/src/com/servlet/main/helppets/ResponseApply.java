package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;
import com.servlet.utils.StringUtil;

/**
 * Servlet implementation class ResponseApply
 */
@WebServlet("/responseApply")
public class ResponseApply extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String sql="update apply a set a.applyStatus=?,a.responseTime=?,a.responseContent=? "
			+ "where a.applyuid=? and a.touid=? and a.dynamicid=?";
	Connection connection;
	PreparedStatement ps;
	ResultSet rs;
	int applyUid=0,toUid=0,dynamicId=0,applyStatus=0;
	String responseTime,responseContent;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		try {
			
			applyUid=Integer.parseInt(req.getParameter("applyUid"));
			toUid=Integer.parseInt(req.getParameter("toUid"));
			dynamicId=Integer.parseInt(req.getParameter("dynamicId"));
			applyStatus=Integer.parseInt(req.getParameter("applyStatus"));
			responseTime=req.getParameter("responseTime");
			responseContent=StringUtil.alterCode(req, "responseContent");
			
			System.out.println("applyUid="+applyUid+"toUid="+toUid+"dynamicId="+dynamicId);
			
			connection=JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);//---------------------特别重要---------------------
			ps=connection.prepareStatement(sql);
			ps.setInt(1,applyStatus);
			ps.setString(2, responseTime);
			ps.setString(3, responseContent);
			ps.setInt(4,applyUid);
			ps.setInt(5,toUid);
			ps.setInt(6,dynamicId);
			
			int i=ps.executeUpdate();
			if(i>0){
				resp.getWriter().println("1");
				System.out.println("回应成功"+"1");
			}else{
				resp.getWriter().println("1");
				System.out.println("回应失败"+"-1");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
