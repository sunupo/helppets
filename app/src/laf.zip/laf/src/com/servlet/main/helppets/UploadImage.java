package com.servlet.main.helppets;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.Base64Coder;
import com.servlet.utils.Constants;
import com.servlet.utils.JdbcUtilUser;

/*
 * 由于http只支持上传的数据转化为字符串，对于想直接上传图片较不容易，
 * 故可以先将其转化为字节流，再将字节流转化为字符串。在此过程中经常出现错误，故可以考虑先将其用base64进行加密编码，
 * 在服务器端或客户端在将其通过base64解码成字节流，进而再转为相应的图片文件。
 */
public class UploadImage extends HttpServlet {

    private String file;
    Connection postIn;

    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req,resp);
	}


	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        file = req.getParameter("file");
        
        int userId=0;
        int dynamicId=0;
        String loginName;
        loginName=req.getParameter("loginName");
        try{
			postIn = JdbcUtilUser.getConnection();
			PreparedStatement psUid=postIn.prepareStatement("select userid from userinfo where loginName=?");
			psUid.setString(1, loginName);
			ResultSet rsUid= psUid.executeQuery();
			while(rsUid.next()){
				userId=rsUid.getInt(1);//根据loginname得到userid
			}
//			计算当前用户已经发布消息的条数，从而计算该条动态的dynamicid
			PreparedStatement psCount = postIn.prepareStatement("select d.dynamicid from dynamic d where userId=? order by d.dynamicid desc");
			psCount.setInt(1, userId);
			ResultSet rsCount = psCount.executeQuery();
			if(rsCount.next())
			{
				dynamicId = rsCount.getInt(1);
			}
//			dynamicId += 1;//得到当前即将插入的dynamicId
        }catch(Exception e){
        	
        }
        if (file != null) {

            byte[] b = Base64Coder.decodeLines(file);
            String filepath = req.getSession().getServletContext()
                    .getRealPath("/files");
            filepath=Constants.UPLOAD_IMAGE_ROOT_PATH;
            File file = new File(filepath);
            if (!file.exists())
                file.mkdirs();
//            FileOutputStream fos = new FileOutputStream(file.getPath()
//                    + "/image" + (int) (Math.random() * 100) + ".bmp");
            FileOutputStream fos = new FileOutputStream(file.getPath()
                    + "/image" +"_"+ userId+"_"+dynamicId + ".bmp");
            System.out.println(file.getPath());
            System.out.println(file.getPath()
                    + "/image" +"_"+ userId+"_"+dynamicId + ".bmp");
            fos.write(b);
            fos.flush();
            fos.close();
        }
    }

}