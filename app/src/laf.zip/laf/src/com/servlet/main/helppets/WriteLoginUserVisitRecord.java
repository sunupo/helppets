package com.servlet.main.helppets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.utils.JdbcUtilUser;
import com.servlet.utils.StringUtil;

/**
 * http://localhost:34098/laf/writeLoginUserVisitRecord?loginUserId=1&dynamicUserId=2&dynamicId=2&fromTime=1970-1-1-0-0-0&toTime=1970-1-1-0-0-0
 * Servlet implementation class GetSignName
 */
@WebServlet("/writeLoginUserVisitRecord")
public class WriteLoginUserVisitRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
    Connection connection;
    PreparedStatement ps;
    
    
    int loginUserId=-1,dynamicUserId,dynamicId;
    String fromTime="",toTime="";
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		loginUserId=Integer.parseInt(StringUtil.alterCode(req, "loginUserId"));
		dynamicUserId=Integer.parseInt(StringUtil.alterCode(req, "dynamicUserId"));
		dynamicId=Integer.parseInt(StringUtil.alterCode(req, "dynamicId"));
		fromTime=StringUtil.alterCode(req, "fromTime");
		toTime=StringUtil.alterCode(req, "toTime");
	
		
		String[] fromT=fromTime.split("-");
		String[] toT=toTime.split("-");
		int totalTime=0;//单位秒

		int second=0,minute=0;
		
//		一班浏览对方的动态不会超过分钟级，所以只考虑分钟级和秒级别上的差值
		if(Integer.parseInt(toT[5])<Integer.parseInt(fromT[5])){
			second=Integer.parseInt(toT[5])+60-Integer.parseInt(fromT[5]);
			if(Integer.parseInt(toT[4])<Integer.parseInt(fromT[4])){
				minute=Integer.parseInt(toT[4])+60-1-Integer.parseInt(fromT[4]);
			}
			else{
				minute=Integer.parseInt(toT[4])-1-Integer.parseInt(fromT[4]);
			}
		}else{
			second=Integer.parseInt(toT[5])-Integer.parseInt(fromT[5]);
			if(Integer.parseInt(toT[4])<Integer.parseInt(fromT[4])){
				minute=Integer.parseInt(toT[4])+60-Integer.parseInt(fromT[4]);
			}
			else{
				minute=Integer.parseInt(toT[4])-Integer.parseInt(fromT[4]);
			}
		}
		totalTime=minute*60+second;
		
		
		
		
		String sql="insert into visitrecord values(?,?,?,?,?,?) ";
		try {
			connection=JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);//---------------------特别重要---------------------
			ps=connection.prepareStatement(sql);
			 
			ps.setInt(1, loginUserId);
			ps.setInt(2, dynamicUserId);
			ps.setInt(3, dynamicId);
			ps.setString(4, fromTime);
			ps.setString(5, toTime);
			ps.setInt(6, totalTime);
			if(ps.executeUpdate()!=0){
				resp.getOutputStream().write("1".getBytes("utf-8"));
				System.out.println("访问记录 succes"+"loginUserId="+loginUserId+",dynamicUserId="+dynamicUserId+",dynamicId="+dynamicId+",fromTime="+fromTime+",toTime"+toTime+",totalTime="+totalTime);
			}else{
				System.out.println("访问记录 error"+"loginUserId="+loginUserId+",dynamicUserId="+dynamicUserId+",dynamicId="+dynamicId);
				resp.getOutputStream().write("-1".getBytes("utf-8"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	
	
	
	}

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
