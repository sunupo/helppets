package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.servlet.utils.JdbcUtilUser;

public class FollowDb
{
//若是followFlag=1关注，则插入一条数据写入关注；若是followFlag=0取消关注，则删除记录

	public static  int  execute(int loginUserId, int dynamicUserId,int followFlag)
	{
		System.out.println("loginUserId="+loginUserId+" dynamicUserId="+dynamicUserId
				+" followFlag="+followFlag);
		Connection connection;
		try{
			connection=JdbcUtilUser.getConnection();
			if(followFlag==0){
				connection.setAutoCommit(true);//---------------------特别重要---------------------
				String sqlDelte="delete from follow where fromuid=? and touid = ?";
				PreparedStatement psDelte = connection.prepareStatement(sqlDelte);
				psDelte.setInt(1, loginUserId);
				psDelte.setInt(2, dynamicUserId);
				System.out.println("psDelte.executeUpdate() 1");
				int i=psDelte.executeUpdate();
				if (i==1)
				{				
					System.out.println("psDelte.executeUpdate() 2");
					return 21;//取消关注成功
				}
				else
				{
					System.out.println("psDelte.executeUpdate() 2");
					return 20;//取消关注失败
				}
			}else if(followFlag==1){
				String sqlInsert = "insert into follow values(?,?,?)";
				PreparedStatement psInsert = connection.prepareStatement(sqlInsert);
				psInsert.setInt(1, loginUserId);
				psInsert.setInt(2, dynamicUserId);
				psInsert.setString(3, "已关注");
				int i=psInsert.executeUpdate();
				if (i== 1) {
					
					return 1;//关注成功
				} else {							
					System.out.println("early 0");
					return 0;//关注失败
				} 
			}										
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("last 0");
		return 0;
	}
	public static void main(String[] args ){
		FollowDb.execute(2, 1, 0);
	}

}
