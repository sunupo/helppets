package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import com.servlet.utils.JdbcUtilUser;


public class RegisterDb
{
	public static int regUser(String uid, String psw) throws Exception
	{
		Connection check = JdbcUtilUser.getConnection();
		check.setAutoCommit(true);
		
		PreparedStatement ps = check.prepareStatement("select * from userinfo where loginName=?");
		ps.setString(1, uid);
		ResultSet rs = ps.executeQuery();
		if(rs.next())
		{
			return -2;//用户名已存在
		}
		
		
		ps = check.prepareStatement("select userId from userinfo order by userid desc limit 1");
		rs = ps.executeQuery();
		int newKey=1;
		while(rs.next())
		{
			newKey=rs.getInt(1);
		}
		newKey++;
		
		
		ps = check.prepareStatement("insert into userinfo(userid,loginName,PassWord,jointime) values(?,?,?,?)");
		ps.setInt(1, newKey);
		ps.setString(2, uid);
		ps.setString(3, psw);
		 Calendar calendar = Calendar.getInstance();
         String currentTime=calendar.get(Calendar.YEAR)
                 +"-"+(calendar.get(Calendar.MONTH)+1)
                 +"-"+calendar.get(Calendar.DAY_OF_MONTH)+
                 "-"+calendar.get(Calendar.HOUR_OF_DAY)+
                 "-"+calendar.get(Calendar.MINUTE)+
                 "-"+calendar.get(Calendar.SECOND);
         ps.setString(4, currentTime);
         
		if (ps.executeUpdate()==1)
		{
//			给每一个用户自动添加上关注用户（管理员Admin，他的userid=0）
			ps=check.prepareStatement("insert into follow values (?,?,?) ");
			ps.setInt(1, newKey);
			ps.setInt(2, 0);
			ps.setString(3,"已关注");
			if(ps.executeUpdate()!=0){
				
				rs.close();
				ps.close();
				check.close();
				return 1;
				
			}else{
				rs.close();
				ps.close();
				check.close();
				return -2;
			}
			
		}
		else
		{
			rs.close();
			ps.close();
			check.close();
			return -1;
		}
		
	}

}
