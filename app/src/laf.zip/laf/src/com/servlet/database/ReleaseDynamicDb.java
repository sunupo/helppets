package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class ReleaseDynamicDb
{
//	其他值默认
//	图片的存储文件名为：IMAGE_USERID_DYNAMICID
	public static int releaseDynamic(
			String loginName
			, String isSend
			,String contentText
			, String type1
			, String type2
			,String type3
			,int type4
			,String type5
			,String type6
			,String time)
	{
		System.out.println("releaseDynamic");
		System.out.println(loginName+"\n"
		+isSend+"\n"
		+contentText+"\n"
		+type1+"\n"
		+type2+"\n"
		+type3+"\n"
		+type4+"\n"
		+type5+"\n"
		+type6+"\n"
		+time+"\n");
		Connection postIn;
		
		int dynamicId=0;
		String isBanned = "否";	
		int userId=0;
		
		try
		{
			postIn = JdbcUtilUser.getConnection();
			PreparedStatement psUid=postIn.prepareStatement("select userid from userinfo where loginName=?");
			psUid.setString(1, loginName);
			ResultSet rsUid= psUid.executeQuery();
			while(rsUid.next()){
				userId=rsUid.getInt(1);//根据loginname得到userid
			}
			
			
			PreparedStatement psBan = postIn.prepareStatement("select isBanned from userinfo where loginname=?");
			psBan.setString(1, loginName);
			ResultSet rsBan = psBan.executeQuery();
			while(rsBan.next())
			{
				isBanned = rsBan.getString(1);
			}
			if(isBanned.equals("是"))
			{
				return -2;//禁止发言
			}
			else
			{
//				计算当前用户已经发布消息的条数，从而计算该条动态的dynamicid
				PreparedStatement psCount = postIn.prepareStatement("select count(*) from dynamic where userId=?");
				psCount.setInt(1, userId);
				ResultSet rsCount = psCount.executeQuery();
				while(rsCount.next())
				{
					dynamicId = rsCount.getInt(1);
				}
				dynamicId += 1;//得到当前即将插入的dynamicId
				
				String sql="insert into dynamic values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
				PreparedStatement ps = postIn.prepareStatement(sql);
				ps.setInt(1, userId);
				ps.setInt(2, dynamicId);
				ps.setString(3, isSend+"");

				ps.setString(4, contentText+"");
				ps.setString(5,type1+"");
				ps.setString(6,type2+"");
				ps.setString(7,type3+"");
				ps.setInt(8,type4);
				ps.setString(9,type5+"");
				ps.setString(10,type6+"");
				ps.setInt(11,0);
				ps.setInt(12,0);
				ps.setInt(13,0);
				ps.setString(14,time+"");
				ps.setString(15,"dynamicpicture/image_"+userId+"_"+dynamicId+".bmp");
				
				if (ps.executeUpdate()==1)
				{
					return 1;
				}
				else
				{
					return -1;
				}	
			}
					
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
}
