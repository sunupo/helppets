package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.servlet.main.InfoList;
import com.servlet.utils.JdbcUtilUser;

public class ViewlistDb
{
	public static List<InfoList> query(String code) throws SQLException
	{
		String codeTemp = code;
		List<InfoList> lists = new ArrayList<InfoList>();
		Connection conn = JdbcUtilUser.getConnection();
		String sql = "select * from context where isdelete=0";
		
		if(codeTemp.equals("2"))
		{
			sql = "select * from context where isdelete=0";			
		}
		else if(codeTemp.equals("1"))
		{
			sql = "select * from context where islost=1 and isdelete=0";
		}
		else if(codeTemp.equals("0"))
		{
			sql = "select * from context where islost=0 and isdelete=0";
		}
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) 
		{
			int num = rs.getInt(1);
			String title = rs.getString(2);
			String text = rs.getString(3);
			String user = rs.getString(4);
			int islost = rs.getInt(5);
			InfoList p = new InfoList();
			p.setNum(num);
			p.setTitle(title);
			p.setText(text);
			p.setUser(user);
			p.setIslost(islost);
			lists.add(p);
		}
		return lists;
	}
	
	public static List<InfoList> searchInfo(String searchInfo) throws SQLException
	{
//		String infoTemp = searchInfo;
		List<InfoList> lists = new ArrayList<InfoList>();
		Connection conn = JdbcUtilUser.getConnection();
		String sql = "select * from context where isdelete=0 and title like ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, "%"+searchInfo+"%");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			int num = rs.getInt(1);
			String title = rs.getString(2);
			String text = rs.getString(3);
			String user = rs.getString(4);
			int islost = rs.getInt(5);
			InfoList p = new InfoList();
			p.setNum(num);
			p.setTitle(title);
			p.setText(text);
			p.setUser(user);
			p.setIslost(islost);
			lists.add(p);
		}
		return lists;
	}
	
}
