package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class SetApplyDataDb
{
//	fromUid,toUid,dynamicId,commentContent,commentTime
	public static int postCom(int applyUid, int toUid, int dynamicId,String applyContent, String applyTime)
	{
		Connection connection;
		
		String ban = "否";
				
		try
		{
			connection = JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);
			
			PreparedStatement ps = connection.prepareStatement("select applyStatus from apply where applyUid=? and toUid=? and dynamicId=?");
			ps.setInt(1, applyUid);
			ps.setInt(2, toUid);
			ps.setInt(3, dynamicId);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
//				'1：正在申请；2：申请成功；3：申请失败',
				if(rs.getInt(1)==1){
					return 1;//申请过了
				}
				if(rs.getInt(1)==2){
					return 2;//申请成功
				}
				if(rs.getInt(1)==3){
					return 3;//上次申请过了，没有通过
				}
			}
			rs.close();
			ps.close();

			
			PreparedStatement psBan = connection.prepareStatement("select isBanned from userinfo where UserId=?");
			psBan.setInt(1, applyUid);
			ResultSet rsBan = psBan.executeQuery();
			while(rsBan.next())
			{
				ban = rsBan.getString(1);
			}
			rsBan.close();
			psBan.close();
			if(ban=="是"||ban.equals("是"))
			{
				return -2;
			}
			else
			{
				PreparedStatement psInsert = connection.prepareStatement("insert into apply  values (?,?,?,?,?,?,?,?)");
				psInsert.setInt(1, applyUid);
				psInsert.setInt(2, toUid);
				psInsert.setInt(3, dynamicId);
				psInsert.setString(4, applyTime);
				psInsert.setInt(5, 1);
				psInsert.setString(6, applyContent);
				psInsert.setString(7, "1970-1-1-0-0-0");
				psInsert.setString(8, "等待回应");

				int i=psInsert.executeUpdate();
				psInsert.close();
				if(i==1)
				{
					return 1;
				}
				
			}	
			connection.close();
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

}
