package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class LoginUserInfoListDb
{
//	public static int checkId(String uid,String psw) throws SQLException
//	{
//		Connection check = JdbcUtilUser.getConnection();
//		PreparedStatement ps = check.prepareStatement("select * from user where UserId=?");
//		ps.setString(1, uid);
//		ResultSet rs = ps.executeQuery();
//		if(rs.next()&&psw.equals(rs.getString(2)))
//		{
//			String temp = "1";
//			if(temp.equals(rs.getString(3)))//如果是管理员（数据库中为1）返回2
//			{
//				return 2;
//			}
//			return 1;//如果是用户（数据库中为0）返回1
//		}
//		else
//		{
//			return -1;
//		}
//	}

	public static JSONObject getLoginUserInfoList(int loginUserId) throws SQLException
	{
		Connection check = JdbcUtilUser.getConnection();
		PreparedStatement ps = check.prepareStatement(
				"SELECT * FROM userinfo u right join follow f on u.userid=f.touid where f.fromuid=? and u.userid !=?");
		ps.setInt(1, loginUserId);
		ps.setInt(2, loginUserId);
		ResultSet rs = ps.executeQuery();
		JSONObject jsonObject0=new JSONObject();

		int flag=0;
		
		JSONArray jsonArray=new JSONArray();		
		while(rs.next())
		{
			flag++;
			JSONObject jsonObject=new JSONObject();
			jsonObject.put("userId", rs.getInt(1));
			jsonObject.put("userName", rs.getString(2));
			jsonObject.put("loginName", rs.getString(3));
			jsonObject.put("password", rs.getString(4));
			jsonObject.put("sendAnimal", rs.getString(5));
			jsonObject.put("adoptionAmial", rs.getString(6));
			jsonObject.put("sex", rs.getString(7));
			jsonObject.put("birthday", rs.getString(8));
			jsonObject.put("age", rs.getInt(9));
			jsonObject.put("working", rs.getString(10));
			jsonObject.put("salary", rs.getString(11));
			jsonObject.put("education", rs.getString(12));
			jsonObject.put("married", rs.getString(13));
			jsonObject.put("joinTime", rs.getString(14));
			jsonObject.put("isBanned", rs.getString(15));
			jsonObject.put("isAdmin", rs.getString(16));
			jsonObject.put("hasChildren", rs.getString(17));
			jsonObject.put("country", rs.getString(18));
			jsonObject.put("province", rs.getString(19));
			jsonObject.put("city", rs.getString(20));
			jsonObject.put("loginCount", rs.getString(21));
			jsonObject.put("logo", rs.getString(22));
			jsonObject.put("phone", rs.getString(23));
			jsonObject.put("qq", rs.getString(24));
			jsonObject.put("weChat", rs.getString(25));
			jsonObject.put("successCode",1);
			
			jsonArray.add(jsonObject);
		}
		if(flag!=0){
			
			jsonObject0.put("code", 1);
			jsonObject0.put("message", "登录用户的关注用户信息数据请求成功");
			jsonObject0.put("data", jsonArray);
			System.out.println("成功"+jsonObject0);
		}else{
			
			jsonObject0.put("code", 0);
			jsonObject0.put("message", "登录用户的关注用户信息数据请求失败，或者没有关注用户");
			jsonObject0.put("data", "");
			System.out.println("失败"+jsonObject0);

		}
		return jsonObject0;
		
	}
}
