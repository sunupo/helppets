package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class CommentDb
{
	public static int postCom(String user0, String user1, String content)
	{
		Connection postIn;
		
		int index = 0;
		int ban = 0;
				
		try
		{
			postIn = JdbcUtilUser.getConnection();
			
			PreparedStatement psBan = postIn.prepareStatement("select isBanned from user where UserId=?");
			psBan.setString(1, user1);
			ResultSet rsBan = psBan.executeQuery();
			while(rsBan.next())
			{
				ban = rsBan.getInt(1);
			}
			if(ban==1)
			{
				return -2;
			}
			else
			{
				PreparedStatement psCount = postIn.prepareStatement("select count(*) from comment");
				ResultSet rsCount = psCount.executeQuery();
				while(rsCount.next())
				{
					index = rsCount.getInt(1);
				}
				index+=1;
				
				String sql = "insert into comment(`index`,user0,user1,content) values(?,?,?,?)";
				PreparedStatement ps = postIn.prepareStatement(sql);
				ps.setInt(1, index);
				ps.setString(2, user0);
				ps.setString(3, user1);
				ps.setString(4, content);
				
				if (ps.executeUpdate()==1)
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

	public static String getCom(String user)
	{
		String resultCom = "";
		try
		{
			Connection check = JdbcUtilUser.getConnection();
			PreparedStatement ps = check.prepareStatement("select * from comment where User0=?");
			ps.setString(1, user);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) 
			{
				String user1 = rs.getString(3);
				String content = rs.getString(4);
				
				resultCom += user1+"��\t";
				resultCom += content+"\n";
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return resultCom;
	}
}
