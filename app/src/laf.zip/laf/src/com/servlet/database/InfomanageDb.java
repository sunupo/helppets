package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class InfomanageDb
{
	public static int infoDelete(int num) throws SQLException
	{
		Connection delete = JdbcUtilUser.getConnection();
			
		PreparedStatement ps = delete.prepareStatement("update context set isdelete=1 where num=?");
		ps.setInt(1, num);
		int result = ps.executeUpdate();

		return result;
	}
}
