package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class UsermanageDb
{
	public static int ugChange(String user) throws SQLException
	{
		int adminCode=1;
		
		Connection change = JdbcUtilUser.getConnection();
		PreparedStatement psGet = change.prepareStatement("select isAdmin from user where UserId=?");
		psGet.setString(1,user);
		ResultSet rsGet = psGet.executeQuery();
		while(rsGet.next())
		{
			adminCode = rsGet.getInt(1);
		}
		
		final int code = adminCode^1;
		
		PreparedStatement ps = change.prepareStatement("update user set isAdmin=? where UserId=?");
		ps.setInt(1, code);
		ps.setString(2, user);
		int result = ps.executeUpdate();
		if(result>0)
		{
			return code;
		}
		else
		{
			return -1;
		}
	}
	
	public static int userBan(String user) throws SQLException
	{
		int isBanCode=0;
		
		Connection change = JdbcUtilUser.getConnection();
		PreparedStatement psGet = change.prepareStatement("select isBanned from user where UserId=?");
		psGet.setString(1,user);
		ResultSet rsGet = psGet.executeQuery();
		while(rsGet.next())
		{
			isBanCode = rsGet.getInt(1);
		}
		
		final int code = isBanCode^1;
		
		PreparedStatement ps = change.prepareStatement("update user set isBanned=? where UserId=?");
		ps.setInt(1, code);
		ps.setString(2, user);
		int result = ps.executeUpdate();
		if(result>0)
		{
			return code;
		}
		else
		{
			return -1;
		}
	}
}
