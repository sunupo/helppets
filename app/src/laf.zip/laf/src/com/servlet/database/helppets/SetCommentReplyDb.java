package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class SetCommentReplyDb
{
//	fromUid,toUid,dynamicId,commentId,
//	commentContent,replyUid,replyId,replyContent,commentTime
	public static int postCom(int fromUid, int toUid, int dynamicId,int commentId
			,int replyUid,String replyContent,String replyTime)
	{
		Connection connection;
		
		String ban = "否";
		int replyId=0;
		String commentContent="";
				
		try
		{
			connection = JdbcUtilUser.getConnection();
			
			PreparedStatement psBan = connection.prepareStatement("select isBanned from userinfo where UserId=?");
			psBan.setInt(1, replyUid);
			ResultSet rsBan = psBan.executeQuery();
			while(rsBan.next())
			{
				ban = rsBan.getString(1);
			}
			if(ban=="是"||ban.equals("是"))
			{
				return -2;
			}
			else
			{
//				先获取commentcontent
				PreparedStatement psCommentContent = connection.prepareStatement(
						"select commentContent from comments where fromUid=? "
						+ "and toUid=? and dynamicId=? and commentId=?");
				psCommentContent.setInt(1, fromUid);
				psCommentContent.setInt(2, toUid);
				psCommentContent.setInt(3, dynamicId);
				psCommentContent.setInt(4, commentId);
				ResultSet rsCommentContent = psCommentContent.executeQuery();
				while(rsCommentContent.next())
				{
					commentContent = rsCommentContent.getString(1);
				}
				
//				获取replyId
				PreparedStatement psCount = connection.prepareStatement("select count(*) from reply where fromUid=? "
						+ "and toUid=? and dynamicId=? and commentId=? and replyUid=?");
				psCount.setInt(1, fromUid);
				psCount.setInt(2, toUid);
				psCount.setInt(3, dynamicId);
				psCount.setInt(4, commentId);
				psCount.setInt(5, replyUid);
				
				ResultSet rsCount = psCount.executeQuery();
				while(rsCount.next())
				{
					replyId = rsCount.getInt(1);
				}
				replyId+=1;
				
				
				String sql = "insert into reply values(?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = connection.prepareStatement(sql);
				ps.setInt(1, fromUid);
				ps.setInt(2, toUid);
				ps.setInt(3, dynamicId);
				ps.setInt(4, commentId);
				ps.setString(5, commentContent);
				ps.setInt(6, replyUid);
				ps.setInt(7, replyId);
				ps.setString(8, replyContent);
				ps.setString(9, replyTime);
				
				if (ps.executeUpdate()==1)
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

}
