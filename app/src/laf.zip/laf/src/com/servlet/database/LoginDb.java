package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.bean.Userinfo;
import com.servlet.utils.JdbcUtilUser;

import net.sf.json.JSONObject;

public class LoginDb
{
//	public static int checkId(String uid,String psw) throws SQLException
//	{
//		Connection check = JdbcUtilUser.getConnection();
//		PreparedStatement ps = check.prepareStatement("select * from user where UserId=?");
//		ps.setString(1, uid);
//		ResultSet rs = ps.executeQuery();
//		if(rs.next()&&psw.equals(rs.getString(2)))
//		{
//			String temp = "1";
//			if(temp.equals(rs.getString(3)))//如果是管理员（数据库中为1）返回2
//			{
//				return 2;
//			}
//			return 1;//如果是用户（数据库中为0）返回1
//		}
//		else
//		{
//			return -1;
//		}
//	}
	public static int checkId(String loginName,String password) throws SQLException
	{
		System.out.println(loginName+password);
		Connection check = JdbcUtilUser.getConnection();
		PreparedStatement ps = check.prepareStatement("select * from userinfo where loginname=?");
		ps.setString(1, loginName);
		ResultSet rs = ps.executeQuery();
		if(rs.next()&&password.equals(rs.getString(4)))
		{
			
			String temp = "是";
			if(temp.equals(rs.getString(16)))//如果是管理员 返回2
			{
				return 2;
			}
			return 1;//如果是用户  返回1
		}
		else
		{
			return -1;
		}
	}
	
	public static int changePsw(String uid,String psw,String newpsw)
	{
		try
		{
			if(checkId(uid,psw)>0)
			{
				Connection change = JdbcUtilUser.getConnection();
				PreparedStatement ps = change.prepareStatement("update userinfo set PassWord=? where loginName=?");
				ps.setString(1, newpsw);
				ps.setString(2, uid);
				int result = ps.executeUpdate();
				if(result>0)
				{
					return 1;
				}
			}
			else if(checkId(uid,psw)==-1)
			{
				return -2;
			}

		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return -1;
	}
}
