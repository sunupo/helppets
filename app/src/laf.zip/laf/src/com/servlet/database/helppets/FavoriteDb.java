package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.servlet.utils.JdbcUtilUser;

public class FavoriteDb
{


	public static  int  execute(int loginUserId, int dynamicUserId,int dynamicId,int favoriteFlag)
	{
		System.out.println("loginUserId="+loginUserId+" dynamicUserId="+dynamicUserId
				+" favoriteFlag="+favoriteFlag);
		Connection connection;
		int queryFlag=0;
		try{
			
			connection=JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);//---------------------特别重要---------------------

//			TODO 查询数据库是否有该条记录
			String sqlQuery="select * from collectfavorite where fromuid=? and touid = ? and dynamicId=?";
			PreparedStatement psQuery = connection.prepareStatement(sqlQuery);
			psQuery.setInt(1, loginUserId);
			psQuery.setInt(2, dynamicUserId);
			psQuery.setInt(3, dynamicId);
			ResultSet rsQuery=psQuery.executeQuery();
			while(rsQuery.next()){
				queryFlag=1;
				break;
			}
			switch(queryFlag){
			case 0://数据库没有记录，插入数据，isfavorite根据favoriteFlag设置值，iscollected设为="未收藏"
				if(favoriteFlag==0){//数据库没有记录，又是取消收藏操作不能同时存在，因为当数据没有记录是，肯定是没有收藏，所以第一次点击收藏按钮执行的是收藏操作
					String sqlCancelFavorite="update collectfavorite c set c.isFavorite='未点赞' where c.fromuid=? and c.touid=? and c.dynamicid=?";
					PreparedStatement psCancelFavorite = connection.prepareStatement(sqlCancelFavorite);
					psCancelFavorite.setInt(1, loginUserId);
					psCancelFavorite.setInt(2, dynamicUserId);
					psCancelFavorite.setInt(3, dynamicId);

					int i=psCancelFavorite.executeUpdate();
					if (i==1){		
//						dynamic表的favorite减1
						String sqlAddFavoriteNum = "update dynamic d set d.favorite=d.favorite-1 where d.userid=? and d.dynamicid=? and d.collected>0";
						PreparedStatement psAddFavoriteNum = connection.prepareStatement(sqlAddFavoriteNum);
						psAddFavoriteNum.setInt(1, dynamicUserId);
						psAddFavoriteNum.setInt(2, dynamicId);					
						psAddFavoriteNum.executeUpdate();
						return 21;//取消收藏成功
					}
					else{
						return 20;//取消收藏失败
					}
				}
				else if(favoriteFlag==1){
					String sqlInsert = "insert into collectfavorite values(?,?,?,?,?)";
					PreparedStatement psInsert = connection.prepareStatement(sqlInsert);
					psInsert.setInt(1, loginUserId);
					psInsert.setInt(2, dynamicUserId);
					psInsert.setInt(3, dynamicId);
					psInsert.setString(4, "未收藏");
					psInsert.setString(5, "已点赞");
					int i=psInsert.executeUpdate();
					if (i== 1) {	
//						dynamic表的favorite加1
						String sqlAddFavoriteNum = "update dynamic d set d.favorite=d.favorite+1 where d.userid=? and d.dynamicid=?";
						PreparedStatement psAddFavoriteNum = connection.prepareStatement(sqlAddFavoriteNum);
						psAddFavoriteNum.setInt(1, dynamicUserId);
						psAddFavoriteNum.setInt(2, dynamicId);					
						psAddFavoriteNum.executeUpdate();
						return 1;//收藏成功
					} else {							
						return 0;//收藏失败
					} 
				}
				break;
				
			case 1:
				if(favoriteFlag==0){
					String sqlCancelFavorite="update collectfavorite c set c.isFavorite='未点赞' where c.fromuid=? and c.touid=? and c.dynamicid=?";
					PreparedStatement psCancelFavorite = connection.prepareStatement(sqlCancelFavorite);
					psCancelFavorite.setInt(1, loginUserId);
					psCancelFavorite.setInt(2, dynamicUserId);
					psCancelFavorite.setInt(3, dynamicId);

					int i=psCancelFavorite.executeUpdate();
					if (i==1){		
//						dynamic表的favorite减1
						String sqlAddFavoriteNum = "update dynamic d set d.favorite=d.favorite-1 where d.userid=? and d.dynamicid=? and d.collected>0";
						PreparedStatement psAddFavoriteNum = connection.prepareStatement(sqlAddFavoriteNum);
						psAddFavoriteNum.setInt(1, dynamicUserId);
						psAddFavoriteNum.setInt(2, dynamicId);					
						psAddFavoriteNum.executeUpdate();
						return 21;//取消收藏成功
					}
					else{
						return 20;//取消收藏失败
					}
				}else if(favoriteFlag==1){
					String sqlFavorite="update collectfavorite c set c.isFavorite='已点赞' where c.fromuid=? and c.touid=? and c.dynamicid=?";
					PreparedStatement psFavorite = connection.prepareStatement(sqlFavorite);
					psFavorite.setInt(1, loginUserId);
					psFavorite.setInt(2, dynamicUserId);
					psFavorite.setInt(3, dynamicId);
					int i=psFavorite.executeUpdate();
					if (i== 1) {
//						dynamic表的collected加1
						String sqlAddFavoriteNum = "update dynamic d set d.favorite=d.favorite+1 where d.userid=? and d.dynamicid=?";
						PreparedStatement psAddFavoriteNum = connection.prepareStatement(sqlAddFavoriteNum);
						psAddFavoriteNum.setInt(1, dynamicUserId);
						psAddFavoriteNum.setInt(2, dynamicId);					
						psAddFavoriteNum.executeUpdate();
						return 1;//收藏成功
					} else {							
						return 0;//收藏失败
					} 
				}
				break;
			}
			connection.close();	
			
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("last 0");
		return 0;
	}

}
