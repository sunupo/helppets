package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class AddViewsDb
{
//	
	public static int add(int userId, int dynamicId)
	{
		Connection connection;
		
		int views=0;				
		try
		{
			connection = JdbcUtilUser.getConnection();
			String sqlViews="select views from dynamic where userid=? and dynamicId=?";

			PreparedStatement psCount = connection.prepareStatement(sqlViews);
			psCount.setInt(1, userId);
			psCount.setInt(2, dynamicId);
			
			ResultSet rsCount = psCount.executeQuery();
			while(rsCount.next())
			{
				views = rsCount.getInt(1);
			}
			views+=1;
			System.out.println("views="+views);
			
			String sqlUpdate = "update  dynamic d set d.views=? where d.userid=? and d.dynamicid=? ";
			PreparedStatement ps = connection.prepareStatement(sqlUpdate);
			ps.setInt(1, views);
			ps.setInt(2, userId);
			ps.setInt(3, dynamicId);

			
			if (ps.executeUpdate()==1)
			{
				return 1;
			}
			else
			{
				return -1;
			}
						
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

}
