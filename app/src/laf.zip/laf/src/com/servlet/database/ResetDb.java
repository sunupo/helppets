package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.servlet.utils.JdbcUtilUser;

public class ResetDb
{
	public static int resetUser(String uid, String psw) throws Exception
	{
		Connection check = JdbcUtilUser.getConnection();
		
		PreparedStatement psCheck = check.prepareStatement("select * from userinfo where loginName=?");
		psCheck.setString(1, uid);
		ResultSet rsCheck = psCheck.executeQuery();
		if(!(rsCheck.next()))
		{
			return -2;
		}
		
		PreparedStatement ps = check.prepareStatement("update userinfo set PassWord=? where loginName=?");
		ps.setString(1, psw);
		ps.setString(2, uid);
		if (ps.executeUpdate()==1)
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}
}
