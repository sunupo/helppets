package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.servlet.utils.JdbcUtilUser;

public class CollectDb
{
//若是collectFlag=1收藏，则插入一条数据写入收藏；若是collectFlag=0取消收藏，则删除记录

	public static  int  execute(int loginUserId, int dynamicUserId,int dynamicId,int collectFlag)
	{
		System.out.println("loginUserId="+loginUserId+" dynamicUserId="+dynamicUserId
				+" collectFlag="+collectFlag);
		Connection connection;
		int queryFlag=0;
		try{
			
			connection=JdbcUtilUser.getConnection();
			connection.setAutoCommit(true);//---------------------特别重要---------------------

//			TODO 查询数据库是否有该条记录
			String sqlQuery="select * from collectfavorite where fromuid=? and touid = ? and dynamicid=?";
			PreparedStatement psQuery = connection.prepareStatement(sqlQuery);
			psQuery.setInt(1, loginUserId);
			psQuery.setInt(2, dynamicUserId);
			psQuery.setInt(3, dynamicId);
			ResultSet rsQuery=psQuery.executeQuery();
			while(rsQuery.next()){
				queryFlag=1;
				break;
			}
			switch(queryFlag){
			case 0://数据库没有记录，插入数据，iscollected根据collectFlag设置值，isfavorite设为="未点赞"
				if(collectFlag==0){//数据库没有记录，又是取消收藏操作不能同时存在，因为当数据没有记录是，肯定是没有收藏，所以第一次点击收藏按钮执行的是收藏操作
					String sqlCancelCollect="update collectfavorite c set c.iscollected='未收藏' where c.fromuid=? and c.touid=? and c.dynamicid=?";
					PreparedStatement psCancelCollect = connection.prepareStatement(sqlCancelCollect);
					psCancelCollect.setInt(1, loginUserId);
					psCancelCollect.setInt(2, dynamicUserId);
					psCancelCollect.setInt(3, dynamicId);

					int i=psCancelCollect.executeUpdate();
					if (i==1){
//						dynamic表的collected减1
						String sqlAddCollectNum = "update dynamic d set d.collected=d.collected-1 where d.userid=? and d.dynamicid=? and d.collected>0";
						PreparedStatement psAddCollectNum = connection.prepareStatement(sqlAddCollectNum);
						psAddCollectNum.setInt(1, dynamicUserId);
						psAddCollectNum.setInt(2, dynamicId);					
						psAddCollectNum.executeUpdate();
						return 21;//取消收藏成功
					}
					else{
						return 20;//取消收藏失败
					}
				}else if(collectFlag==1){
					String sqlInsert = "insert into collectfavorite values(?,?,?,?,?)";
					PreparedStatement psInsert = connection.prepareStatement(sqlInsert);
					psInsert.setInt(1, loginUserId);
					psInsert.setInt(2, dynamicUserId);
					psInsert.setInt(3, dynamicId);
					psInsert.setString(4, "已收藏");
					psInsert.setString(5, "未点赞");
					int i=psInsert.executeUpdate();
					if (i== 1) {
//						dynamic表的collected加1
						String sqlAddCollectNum = "update dynamic d set d.collected=d.collected+1 where d.userid=? and d.dynamicid=?";
						PreparedStatement psAddCollectNum = connection.prepareStatement(sqlAddCollectNum);
						psAddCollectNum.setInt(1, dynamicUserId);
						psAddCollectNum.setInt(2, dynamicId);					
						psAddCollectNum.executeUpdate();
						return 1;//收藏成功
					} else {							
						return 0;//收藏失败
					} 
				}
				break;
				
			case 1:
				if(collectFlag==0){
					String sqlCancelCollect="update collectfavorite c set c.iscollected='未收藏' where c.fromuid=? and c.touid=? and c.dynamicid=?";
					PreparedStatement psCancelCollect = connection.prepareStatement(sqlCancelCollect);
					psCancelCollect.setInt(1, loginUserId);
					psCancelCollect.setInt(2, dynamicUserId);
					psCancelCollect.setInt(3, dynamicId);

					int i=psCancelCollect.executeUpdate();
					if (i==1){
//						dynamic表的collected减1
						String sqlAddCollectNum = "update dynamic d set d.collected=d.collected-1 where d.userid=? and d.dynamicid=? and d.collected>0";
						PreparedStatement psAddCollectNum = connection.prepareStatement(sqlAddCollectNum);
						psAddCollectNum.setInt(1, dynamicUserId);
						psAddCollectNum.setInt(2, dynamicId);					
						psAddCollectNum.executeUpdate();
						return 21;//取消收藏成功
					}
					else{
						return 20;//取消收藏失败
					}
				}else if(collectFlag==1){
					String sqlCollect="update collectfavorite c set c.iscollected='已收藏' where c.fromuid=? and c.touid=? and c.dynamicid=?";
					PreparedStatement psCollect = connection.prepareStatement(sqlCollect);
					psCollect.setInt(1, loginUserId);
					psCollect.setInt(2, dynamicUserId);
					psCollect.setInt(3, dynamicId);
					int i=psCollect.executeUpdate();
					if (i== 1) {
//						dynamic表的collected加1
						String sqlAddCollectNum = "update dynamic d set d.collected=d.collected+1 where d.userid=? and d.dynamicid=?";
						PreparedStatement psAddCollectNum = connection.prepareStatement(sqlAddCollectNum);
						psAddCollectNum.setInt(1, dynamicUserId);
						psAddCollectNum.setInt(2, dynamicId);					
						psAddCollectNum.executeUpdate();
						return 1;//收藏成功
					} else {							
						return 0;//收藏失败
					} 
				}
				break;
			}
			connection.close();	
			
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("last 0");
		return 0;
	}

}
