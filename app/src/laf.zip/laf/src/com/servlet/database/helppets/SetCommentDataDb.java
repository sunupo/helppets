package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class SetCommentDataDb
{
//	fromUid,toUid,dynamicId,commentContent,commentTime
	public static int postCom(int fromUid, int toUid, int dynamicId,String commentContent, String commentTime)
	{
		Connection connection;
		
		int commentId=0;
		String ban = "否";
				
		try
		{
			connection = JdbcUtilUser.getConnection();
			
			PreparedStatement psBan = connection.prepareStatement("select isBanned from userinfo where UserId=?");
			psBan.setInt(1, fromUid);
			ResultSet rsBan = psBan.executeQuery();
			while(rsBan.next())
			{
				ban = rsBan.getString(1);
			}
			if(ban=="是"||ban.equals("是"))
			{
				return -2;
			}
			else
			{
				PreparedStatement psCount = connection.prepareStatement("select count(*) from comments where fromUid=? and toUid=? and dynamicId=?");
				psCount.setInt(1, fromUid);
				psCount.setInt(2, toUid);
				psCount.setInt(3, dynamicId);
				
				ResultSet rsCount = psCount.executeQuery();
				while(rsCount.next())
				{
					commentId = rsCount.getInt(1);
				}
				commentId+=1;
				
				String sql = "insert into comments (fromuid,touid,dynamicid,commentid,commentContent,commentTime) values(?,?,?,?,?,?)";
				PreparedStatement ps = connection.prepareStatement(sql);
				ps.setInt(1, fromUid);
				ps.setInt(2, toUid);
				ps.setInt(3, dynamicId);
				ps.setInt(4, commentId);
				ps.setString(5, commentContent);
				ps.setString(6, commentTime);
				
				if (ps.executeUpdate()==1)
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

}
