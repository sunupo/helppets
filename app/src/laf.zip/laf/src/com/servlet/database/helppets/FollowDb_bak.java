package com.servlet.database.helppets;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class FollowDb_bak
{
//actionFlag=0，查询query，是否关注，没查询到记录，说明未关注,此时不关注followFlag的值
// actionFlag=1，更改update，若是followFlag=1关注，则插入一条数据写入关注；若是followFlag=0取消关注，则删除记录
//followFlag actionFlag
//	0,0  查询
//	1,0  查询
//	0,1 删除关注
//	1,1 添加关注
	public static  int  execute(String loginName, int dynamicUserId,String followFlag,String actionFlag)
	{
		
		System.out.println("loginName="+loginName+" dynamicUserId="+dynamicUserId
				+" followFlag="+followFlag+" actionFlag="+actionFlag);
		Connection connection;
		int userId=0;
		
		try{		
//		-------------------------------------------------------------------------	
			connection=JdbcUtilUser.getConnection();
			String sqlUserId="select userid from userInfo where loginName=? ";

			PreparedStatement psUserId = connection.prepareStatement(sqlUserId);
			psUserId.setString(1, loginName);
			
			System.out.println("psUserId.executeQuery() 1");
			ResultSet rsUserId = psUserId.executeQuery();
			System.out.println("psUserId.executeQuery() 2");

			while(rsUserId.next())
			{
				userId = rsUserId.getInt(1);//根据loginName得到userId
			}
			//打印输出当前的userid
			System.out.println("userId="+userId);
			System.out.println("Integer.parseInt(actionFlag)="+Integer.parseInt(actionFlag));
//	----------------------------------------------------------------------------------------------		
			
			if(Integer.parseInt(actionFlag)==0){
			
				String sqlQuery="select * from follow where fromUid=? and toUid=? ";

				
				PreparedStatement psQuery = connection.prepareStatement(sqlQuery);
				psQuery.setInt(1, userId);
				psQuery.setInt(1, dynamicUserId);
				
				System.out.println("psQuery.executeQuery(); 1");

				ResultSet rsQuery = psQuery.executeQuery();
				System.out.println("psQuery.executeQuery(); 2");

				try {
					while(rsQuery.next())
					{
						return 11;//表示已关注
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(loginName+"="+userId+"没有关注用户="+dynamicUserId);
				}
				
				return 10;
			}else if(Integer.parseInt(actionFlag)==1){
				if(Integer.parseInt(followFlag)==0){
					
					String sqlQuery2a="select * from follow where fromUid=? and toUid=? ";
					
					PreparedStatement psQuery2a = connection.prepareStatement(sqlQuery2a);
					psQuery2a.setInt(1, userId);
					psQuery2a.setInt(1, dynamicUserId);
					System.out.println("psQuery2a.executeQuery(); 1");

//					todo 走不下去
					ResultSet rsQuery2a = psQuery2a.executeQuery();
					System.out.println("psQuery2a.executeQuery(); 2");


				try {
					while(!rsQuery2a.next())
					{
						return 10;//你没有关注
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
					String sqlDelte="delete from table follow where fromuid=? touid = ?";
					PreparedStatement psDelte = connection.prepareStatement(sqlDelte);
					psDelte.setInt(1, userId);
					psDelte.setInt(2, dynamicUserId);
					
					if (psDelte.executeUpdate()==1)
					{
						

						return 21;//取消关注成功
					}
					else
					{
						return 20;//取消关注失败
					}
				}else if(Integer.parseInt(followFlag)==1){
					System.out.println("into followFlag=1");

					String sqlQuery2="select * from follow where fromUid=? and toUid=? ";
					System.out.println("into sqlQuery2");			
					
					PreparedStatement psQuery2 = connection.prepareStatement(sqlQuery2);
					psQuery2.setInt(1, userId);
					psQuery2.setInt(1, dynamicUserId);
					
					System.out.println("psQuery2.executeQuery(); 1" );
//					todo 走不下去，不知道为什么
					ResultSet rsQuery2 = psQuery2.executeQuery();
					System.out.println("psQuery2.executeQuery(); 2"  );

					try {
						System.out.println("into try");
						if(rsQuery2.next())
						{
							System.out.println("return");

							return 11;//你已经关注了
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					

					System.out.println(" end try");
					

					String sqlInsert = "insert into follow values(?,?)";
					PreparedStatement psInsert = connection.prepareStatement(sqlInsert);
					psInsert.setInt(1, userId);
					psInsert.setInt(2, dynamicUserId);
					
					System.out.println("userId="+userId+"dynamicUserId="+dynamicUserId);
					if (psInsert.executeUpdate() == 1) {
						

						return 1;//关注成功
					} else {							
						System.out.println("early 0");
						return 0;//关注失败
					} 
				}
				
			}	
			connection.close();
		}catch(Exception e){
			
		}
		System.out.println("last 0");
		return 0;
	}

}
