package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class PostDb
{
	public static int postInfo(String title, String text, String user, String islostStr)
	{
		System.out.println("postInfo");
		Connection postIn;
		int num = 0;
		int ban = 0;
		int islost = -1;
		
		if(islostStr.equals("1"))
		{
			islost = 1;
		}
		else if(islostStr.equals("0"))
		{
			islost = 0;
		}
		
		try
		{
			postIn = JdbcUtilUser.getConnection();
			
			PreparedStatement psBan = postIn.prepareStatement("select isBanned from user where UserId=?");
			psBan.setString(1, user);
			ResultSet rsBan = psBan.executeQuery();
			while(rsBan.next())
			{
				ban = rsBan.getInt(1);
			}
			if(ban==1)
			{
				return -2;
			}
			else
			{
				PreparedStatement psCount = postIn.prepareStatement("select count(*) from context");
				ResultSet rsCount = psCount.executeQuery();
				while(rsCount.next())
				{
					num = rsCount.getInt(1);
				}
				num += 1;
				
				String sql = "insert into context(num,title,text,user,islost,isdelete) values(?,?,?,?,?,0)";
				PreparedStatement ps = postIn.prepareStatement(sql);
				ps.setInt(1, num);
				ps.setString(2, title);
				ps.setString(3, text);
				ps.setString(4, user);
				ps.setInt(5, islost);
				
				if (ps.executeUpdate()==1)
				{
					return 1;
				}
				else
				{
					return -1;
				}	
			}
					
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
}
