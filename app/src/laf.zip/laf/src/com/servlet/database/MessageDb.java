package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.servlet.utils.JdbcUtilUser;

public class MessageDb
{
	public static int sendMessage(String sender, String recipient, String content)
	{
		try
		{
			int num=0;
			Connection postIn;
			postIn = JdbcUtilUser.getConnection();
			
			PreparedStatement isUser = postIn.prepareStatement("select count(*) from user where UserId=?");
			isUser.setString(1, recipient);
			ResultSet rsUser = isUser.executeQuery();
			while(rsUser.next())
			{
				if(rsUser.getInt(1)<1)
				{
					return -2;
				}
			}
			
			PreparedStatement psCount = postIn.prepareStatement("select count(*) from mailbox");
			ResultSet rsCount = psCount.executeQuery();
			while(rsCount.next())
			{
				num = rsCount.getInt(1);
			}
			num += 1;
			
			String sql = "insert into mailbox(num,sender,recipient,content) values(?,?,?,?)";
			PreparedStatement ps = postIn.prepareStatement(sql);
			ps.setInt(1, num);
			ps.setString(2, sender);
			ps.setString(3, recipient);
			ps.setString(4, content);
			
			if (ps.executeUpdate()==1)
			{
				return 1;
			}
			else
			{
				return -1;
			}
					
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
}
