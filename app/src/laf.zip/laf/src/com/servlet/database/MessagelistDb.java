package com.servlet.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.servlet.main.MessageBox;
import com.servlet.utils.JdbcUtilUser;

public class MessagelistDb
{
	public static List<MessageBox> getMaillist(String user, String mailType) throws SQLException
	{
		List<MessageBox> lists = new ArrayList<MessageBox>();
		Connection conn = JdbcUtilUser.getConnection();
		String sql = "select * from mailbox where recipient=?";	
		if(mailType.equals("1"))
		{
			sql = "select * from mailbox where recipient=?";	
		}
		else if(mailType.equals("2"))
		{
			sql = "select * from mailbox where sender=?";	
		}
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, user);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) 
		{
			int num = rs.getInt(1);
			String sender = rs.getString(2);
			String recipient = rs.getString(3);
			String content = rs.getString(4);
			MessageBox p = new MessageBox();
			p.setNum(num);
			p.setSender(sender);
			p.setRecipient(recipient);
			p.setContent(content);
			lists.add(p);
		}
		return lists;
	}
}
